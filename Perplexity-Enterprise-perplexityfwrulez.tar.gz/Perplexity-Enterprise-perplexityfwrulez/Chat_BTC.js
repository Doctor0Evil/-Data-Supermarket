
ownerDocument.URL
:
<not available>

BetErrors
:
ƒ BetErrors(e)
length
: 
1
name
: 
"BetErrors"
prototype
: 
constructor
: 
ƒ BetErrors(e)
length
: 
1
name
: 
"BetErrors"
prototype
: 
constructor
: 
ƒ BetErrors(e)
[[Prototype]]
: 
Object
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:53
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
[[Prototype]]
: 
Object
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:53
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
(...)
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
length
: 
0
name
: 
"get arguments"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
length
: 
0
name
: 
"get caller"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[1]
0
: 
Global
$
: 
ƒ (a,c)
$jscomp
: 
{scope: {…}, ASSUME_ES5: false, ASSUME_NO_NATIVE_MAP: false, ASSUME_NO_NATIVE_SET: false, findInternal: ƒ, …}
ARC4init
: 
ƒ ARC4init(a)
ARC4next
: 
ƒ ARC4next()
ActivateFTD
: 
ƒ ActivateFTD()
Arcfour
: 
ƒ Arcfour()
AutoBet
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
AutoBetErrors
: 
ƒ AutoBetErrors(e)
length
: 
1
name
: 
"AutoBetErrors"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:708
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
0
: 
Global
$
: 
ƒ (a,c)
$jscomp
: 
{scope: {…}, ASSUME_ES5: false, ASSUME_NO_NATIVE_MAP: false, ASSUME_NO_NATIVE_SET: false, findInternal: ƒ, …}
ARC4init
: 
ƒ ARC4init(a)
ARC4next
: 
ƒ ARC4next()
ActivateFTD
: 
ƒ ActivateFTD()
Arcfour
: 
ƒ Arcfour()
AutoBet
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
length
: 
20
name
: 
"AutoBet"
prototype
: 
constructor
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
length
: 
20
name
: 
"AutoBet"
prototype
: 
constructor
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
length
: 
20
name
: 
"AutoBet"
prototype
: 
constructor
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
length
: 
20
name
: 
"AutoBet"
prototype
: 
constructor
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
length
: 
20
name
: 
"AutoBet"
prototype
: 
constructor
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
length
: 
20
name
: 
"AutoBet"
prototype
: 
constructor
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
length
: 
20
name
: 
"AutoBet"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:311
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:311
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
[[Prototype]]
: 
Object
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:311
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
[[Prototype]]
: 
Object
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:311
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:311
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
[[Prototype]]
: 
Object
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:311
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[1]
[[Prototype]]
: 
Object
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:311
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
AutoBetErrors
: 
ƒ AutoBetErrors(e)
BI_FP
: 
52
BI_RC
: 
Array(123)
48
: 
0
49
: 
1
50
: 
2
51
: 
3
52
: 
4
53
: 
5
54
: 
6
55
: 
7
56
: 
8
57
: 
9
65
: 
10
66
: 
11
67
: 
12
68
: 
13
69
: 
14
70
: 
15
71
: 
16
72
: 
17
73
: 
18
74
: 
19
75
: 
20
76
: 
21
77
: 
22
78
: 
23
79
: 
24
80
: 
25
81
: 
26
82
: 
27
83
: 
28
84
: 
29
85
: 
30
86
: 
31
87
: 
32
88
: 
33
89
: 
34
90
: 
35
97
: 
10
98
: 
11
99
: 
12
100
: 
13
101
: 
14
102
: 
15
103
: 
16
104
: 
17
105
: 
18
106
: 
19
107
: 
20
108
: 
21
109
: 
22
110
: 
23
111
: 
24
112
: 
25
113
: 
26
114
: 
27
115
: 
28
116
: 
29
117
: 
30
118
: 
31
119
: 
32
120
: 
33
121
: 
34
122
: 
35
length
: 
123
[[Prototype]]
: 
Array(0)
BI_RM
: 
"0123456789abcdefghijklmnopqrstuvwxyz"
Barrett
: 
ƒ Barrett(a)
BenefitsSliderChange
: 
ƒ BenefitsSliderChange(e)
BetErrors
: 
ƒ BetErrors(e)
BigInteger
: 
ƒ BigInteger(a,g,f)
Bitcoin
: 
{Util: {…}, Base58: {…}, ECDSA: {…}, EventEmitter: ƒ, Address: ƒ, …}
BonusEndCountdown
: 
ƒ BonusEndCountdown(e, t)
CalculateWinAmount
: 
ƒ CalculateWinAmount()
Chart
: 
ƒ (t,e)
Classic
: 
ƒ Classic(a)
CloseAlertMsg
: 
ƒ CloseAlertMsg(e, t)
CloseDailyJPBanner
: 
ƒ CloseDailyJPBanner()
ClosePromoBanner
: 
ƒ ClosePromoBanner()
Color
: 
ƒ (t)
CountupCoronaPot
: 
ƒ CountupCoronaPot(starting_pot, final_amount, end_time)
CountupDailyJPPot
: 
ƒ CountupDailyJPPot(e, t, a)
CountupTimer
: 
ƒ CountupTimer(e, t, a, o)
CryptoJS
: 
{lib: {…}, enc: {…}, algo: {…}, SHA256: ƒ, HmacSHA256: ƒ, …}
DeleteAdCampaign
: 
ƒ DeleteAdCampaign(e)
DisplaySEMessage
: 
ƒ DisplaySEMessage(e, t, a)
DoubleYourBTC
: 
ƒ DoubleYourBTC(e)
ECCurveFp
: 
ƒ ECCurveFp(a,g,f)
ECFieldElementFp
: 
ƒ ECFieldElementFp(a,g)
ECPointFp
: 
ƒ ECPointFp(a,g,f,e)
EventEmitter
: 
ƒ ()
FUNDW
: 
ƒ FUNDW(e)
FUNPPriceLockTimer
: 
ƒ FUNPPriceLockTimer()
Fingerprint
: 
ƒ (p)
Foundation
: 
{name: 'Foundation', version: '4.3.2', cache: {…}, media_queries: {…}, stylesheet: CSSStyleSheet, …}
GenCaptchasNetCaptcha
: 
ƒ GenCaptchasNetCaptcha(elementId, captchaType, randomValue)
GenerateCaptchasNetCaptcha
: 
ƒ GenerateCaptchasNetCaptcha(e, t, a)
GenerateDepositAddress
: 
ƒ GenerateDepositAddress()
GenerateETHDepositAddress
: 
ƒ GenerateETHDepositAddress()
GenerateHashes
: 
ƒ GenerateHashes(e)
GenerateMainDepositAddress
: 
ƒ GenerateMainDepositAddress()
GenerateStatsTables
: 
ƒ GenerateStatsTables(e, t, a, o, i, n, s)
GetAdRejectedReason
: 
ƒ GetAdRejectedReason(e, t)
GetBetHistory
: 
ƒ GetBetHistory(e, t)
GetNewsContent
: 
ƒ GetNewsContent(e, t, a)
InitialStatsLoad
: 
ƒ InitialStatsLoad()
InitialUserStats
: 
ƒ InitialUserStats()
InsertAlertMsg
: 
ƒ InsertAlertMsg(e, t, a)
LoadParimutuelEvents
: 
ƒ LoadParimutuelEvents(e)
Modernizr
: 
{touch: false, svg: true, inlinesvg: true, svgclippaths: true, addTest: ƒ, …}
Montgomery
: 
ƒ Montgomery(a)
NullExp
: 
ƒ NullExp()
OpenParimutuelGame
: 
ƒ OpenParimutuelGame(e)
OpenRefPopup
: 
ƒ OpenRefPopup()
ParimutuelFocus
: 
ƒ ParimutuelFocus(e, t)
ParimutuelPlaceBet
: 
ƒ ParimutuelPlaceBet(e, t)
PauseAdCampaign
: 
ƒ PauseAdCampaign(e)
Placeholders
: 
{Utils: {…}, nativeSupport: true, disable: ƒ, enable: ƒ}
PlayCaptchasNetAudioCaptcha
: 
ƒ PlayCaptchasNetAudioCaptcha(e)
PreviousContestWinners
: 
ƒ PreviousContestWinners(e)
PreviousLotteryWinners
: 
ƒ PreviousLotteryWinners(e)
PriceChart
: 
ƒ PriceChart(e)
PrintWagerContestTables
: 
ƒ PrintWagerContestTables(e, t, a)
Raven
: 
o {a: true, b: true, c: true, d: null, e: null, …}
RecalculateFUNBenefitsBuyBox
: 
ƒ RecalculateFUNBenefitsBuyBox()
RecalculateFUNSavingsMaturity
: 
ƒ RecalculateFUNSavingsMaturity()
RedeemRPProduct
: 
ƒ RedeemRPProduct(e)
RefreshAdBalance
: 
ƒ RefreshAdBalance()
RefreshPageAfterFreePlayTimerEnds
: 
ƒ RefreshPageAfterFreePlayTimerEnds()
RenewCookies
: 
ƒ RenewCookies()
ReplaceNumberWithCommas
: 
ƒ ReplaceNumberWithCommas(e)
Reset2FAQuestions
: 
ƒ Reset2FAQuestions(e)
ScreeSizeCSSChanges
: 
ƒ ScreeSizeCSSChanges()
SecureRandom
: 
ƒ SecureRandom()
ShowAdDetails
: 
ƒ ShowAdDetails(e)
ShowAdStats
: 
ƒ ShowAdStats(e)
ShowAdvancedStats
: 
ƒ ShowAdvancedStats(e)
ShowMoreRefs
: 
ƒ ShowMoreRefs(e)
ShowNews
: 
ƒ ShowNews(e)
StartAdCampaign
: 
ƒ StartAdCampaign(e)
StopAutoBet
: 
ƒ StopAutoBet()
SubscribePush
: 
ƒ SubscribePush()
SwitchCaptchas
: 
ƒ SwitchCaptchas(e)
SwitchPageTabs
: 
ƒ SwitchPageTabs(e)
SwitchTabs
: 
ƒ SwitchTabs()
TransactionDatabase
: 
ƒ ()
UpdateAdStats
: 
ƒ UpdateAdStats()
UpdateFunPrice
: 
ƒ UpdateFunPrice()
UpdateStats
: 
ƒ UpdateStats()
UpdateUserStats
: 
ƒ UpdateUserStats()
VisitLink
: 
ƒ VisitLink(e)
length
: 
1
name
: 
"VisitLink"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:944
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
0
: 
Global
$
: 
ƒ (a,c)
$jscomp
: 
{scope: {…}, ASSUME_ES5: false, ASSUME_NO_NATIVE_MAP: false, ASSUME_NO_NATIVE_SET: false, findInternal: ƒ, …}
ARC4init
: 
ƒ ARC4init(a)
ARC4next
: 
ƒ ARC4next()
ActivateFTD
: 
ƒ ActivateFTD()
Arcfour
: 
ƒ Arcfour()
AutoBet
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
AutoBetErrors
: 
ƒ AutoBetErrors(e)
BI_FP
: 
52
BI_RC
: 
(123) [empty × 48, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, empty × 7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, empty × 6, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
BI_RM
: 
"0123456789abcdefghijklmnopqrstuvwxyz"
Barrett
: 
ƒ Barrett(a)
BenefitsSliderChange
: 
ƒ BenefitsSliderChange(e)
BetErrors
: 
ƒ BetErrors(e)
BigInteger
: 
ƒ BigInteger(a,g,f)
Bitcoin
: 
{Util: {…}, Base58: {…}, ECDSA: {…}, EventEmitter: ƒ, Address: ƒ, …}
BonusEndCountdown
: 
ƒ BonusEndCountdown(e, t)
CalculateWinAmount
: 
ƒ CalculateWinAmount()
Chart
: 
ƒ (t,e)
Classic
: 
ƒ Classic(a)
CloseAlertMsg
: 
ƒ CloseAlertMsg(e, t)
CloseDailyJPBanner
: 
ƒ CloseDailyJPBanner()
ClosePromoBanner
: 
ƒ ClosePromoBanner()
Color
: 
ƒ (t)
CountupCoronaPot
: 
ƒ CountupCoronaPot(starting_pot, final_amount, end_time)
CountupDailyJPPot
: 
ƒ CountupDailyJPPot(e, t, a)
CountupTimer
: 
ƒ CountupTimer(e, t, a, o)
CryptoJS
: 
{lib: {…}, enc: {…}, algo: {…}, SHA256: ƒ, HmacSHA256: ƒ, …}
DeleteAdCampaign
: 
ƒ DeleteAdCampaign(e)
DisplaySEMessage
: 
ƒ DisplaySEMessage(e, t, a)
DoubleYourBTC
: 
ƒ DoubleYourBTC(e)
ECCurveFp
: 
ƒ ECCurveFp(a,g,f)
length
: 
3
name
: 
"ECCurveFp"
prototype
: 
{getQ: ƒ, getA: ƒ, getB: ƒ, equals: ƒ, getInfinity: ƒ, …}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
combined1393766573.js:84
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
ECFieldElementFp
: 
ƒ ECFieldElementFp(a,g)
ECPointFp
: 
ƒ ECPointFp(a,g,f,e)
decodeFrom
: 
ƒ (a,g)
length
: 
4
name
: 
"ECPointFp"
prototype
: 
{getX: ƒ, getY: ƒ, equals: ƒ, isInfinity: ƒ, negate: ƒ, …}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
combined1393766573.js:76
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
EventEmitter
: 
ƒ ()
FUNDW
: 
ƒ FUNDW(e)
length
: 
1
name
: 
"FUNDW"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:476
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
FUNPPriceLockTimer
: 
ƒ FUNPPriceLockTimer()
Fingerprint
: 
ƒ (p)
length
: 
1
name
: 
"e"
prototype
: 
{get: ƒ, murmurhash3_32_gc: ƒ, hasLocalStorage: ƒ, hasSessionStorage: ƒ, isCanvasSupported: ƒ, …}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
compressed_bottom3.js:43
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
Foundation
: 
cache
: 
{}
error
: 
ƒ (c)
fix_outer
: 
ƒ (c)
inherit
: 
ƒ (c,a)
init
: 
ƒ (c, a,b,d,l,j)
init_lib
: 
ƒ (c,a)
lib_methods
: 
{set_data: ƒ, get_data: ƒ, remove_data: ƒ, throttle: ƒ, data_options: ƒ, …}
libs
: 
{alerts: {…}, clearing: {…}, dropdown: {…}, forms: {…}, joyride: {…}, …}
media_queries
: 
{small: '"only screen and (min-width: 768px)"', medium: '"only screen and (min-width:1280px)"', large: '"only screen and (min-width:1440px)"'}
name
: 
"Foundation"
off
: 
ƒ ()
patch
: 
ƒ (c)
random_str
: 
ƒ (c)
response_obj
: 
ƒ (c,a)
rtl
: 
false
scope
: 
div#myModal22.reveal-modal
stylesheet
: 
CSSStyleSheet {ownerRule: null, cssRules: CSSRuleList, rules: CSSRuleList, type: 'text/css', href: null, …}
trap
: 
ƒ (c,a)
version
: 
"4.3.2"
zj
: 
ƒ (a,c)
[[Prototype]]
: 
Object
GenCaptchasNetCaptcha
: 
ƒ GenCaptchasNetCaptcha(elementId, captchaType, randomValue)
length
: 
3
name
: 
"GenCaptchasNetCaptcha"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:2333
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
GenerateCaptchasNetCaptcha
: 
ƒ GenerateCaptchasNetCaptcha(e, t, a)
GenerateDepositAddress
: 
ƒ GenerateDepositAddress()
GenerateETHDepositAddress
: 
ƒ GenerateETHDepositAddress()
GenerateHashes
: 
ƒ GenerateHashes(e)
GenerateMainDepositAddress
: 
ƒ GenerateMainDepositAddress()
GenerateStatsTables
: 
ƒ GenerateStatsTables(e, t, a, o, i, n, s)
GetAdRejectedReason
: 
ƒ GetAdRejectedReason(e, t)
GetBetHistory
: 
ƒ GetBetHistory(e, t)
GetNewsContent
: 
ƒ GetNewsContent(e, t, a)
InitialStatsLoad
: 
ƒ InitialStatsLoad()
InitialUserStats
: 
ƒ InitialUserStats()
InsertAlertMsg
: 
ƒ InsertAlertMsg(e, t, a)
LoadParimutuelEvents
: 
ƒ LoadParimutuelEvents(e)
Modernizr
: 
{touch: false, svg: true, inlinesvg: true, svgclippaths: true, addTest: ƒ, …}
Montgomery
: 
ƒ Montgomery(a)
NullExp
: 
ƒ NullExp()
OpenParimutuelGame
: 
ƒ OpenParimutuelGame(e)
OpenRefPopup
: 
ƒ OpenRefPopup()
ParimutuelFocus
: 
ƒ ParimutuelFocus(e, t)
ParimutuelPlaceBet
: 
ƒ ParimutuelPlaceBet(e, t)
PauseAdCampaign
: 
ƒ PauseAdCampaign(e)
Placeholders
: 
{Utils: {…}, nativeSupport: true, disable: ƒ, enable: ƒ}
PlayCaptchasNetAudioCaptcha
: 
ƒ PlayCaptchasNetAudioCaptcha(e)
PreviousContestWinners
: 
ƒ PreviousContestWinners(e)
PreviousLotteryWinners
: 
ƒ PreviousLotteryWinners(e)
PriceChart
: 
ƒ PriceChart(e)
PrintWagerContestTables
: 
ƒ PrintWagerContestTables(e, t, a)
Raven
: 
o {a: true, b: true, c: true, d: null, e: null, …}
RecalculateFUNBenefitsBuyBox
: 
ƒ RecalculateFUNBenefitsBuyBox()
RecalculateFUNSavingsMaturity
: 
ƒ RecalculateFUNSavingsMaturity()
RedeemRPProduct
: 
ƒ RedeemRPProduct(e)
RefreshAdBalance
: 
ƒ RefreshAdBalance()
RefreshPageAfterFreePlayTimerEnds
: 
ƒ RefreshPageAfterFreePlayTimerEnds()
RenewCookies
: 
ƒ RenewCookies()
ReplaceNumberWithCommas
: 
ƒ ReplaceNumberWithCommas(e)
Reset2FAQuestions
: 
ƒ Reset2FAQuestions(e)
ScreeSizeCSSChanges
: 
ƒ ScreeSizeCSSChanges()
SecureRandom
: 
ƒ SecureRandom()
ShowAdDetails
: 
ƒ ShowAdDetails(e)
ShowAdStats
: 
ƒ ShowAdStats(e)
ShowAdvancedStats
: 
ƒ ShowAdvancedStats(e)
ShowMoreRefs
: 
ƒ ShowMoreRefs(e)
ShowNews
: 
ƒ ShowNews(e)
StartAdCampaign
: 
ƒ StartAdCampaign(e)
StopAutoBet
: 
ƒ StopAutoBet()
SubscribePush
: 
ƒ SubscribePush()
SwitchCaptchas
: 
ƒ SwitchCaptchas(e)
SwitchPageTabs
: 
ƒ SwitchPageTabs(e)
SwitchTabs
: 
ƒ SwitchTabs()
TransactionDatabase
: 
ƒ ()
UpdateAdStats
: 
ƒ UpdateAdStats()
UpdateFunPrice
: 
ƒ UpdateFunPrice()
UpdateStats
: 
ƒ UpdateStats()
UpdateUserStats
: 
ƒ UpdateUserStats()
VisitLink
: 
ƒ VisitLink(e)
length
: 
1
name
: 
"VisitLink"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
main.js?13042025-1:944
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[1]
0
: 
Global
$
: 
ƒ (a,c)
$jscomp
: 
{scope: {…}, ASSUME_ES5: false, ASSUME_NO_NATIVE_MAP: false, ASSUME_NO_NATIVE_SET: false, findInternal: ƒ, …}
ARC4init
: 
ƒ ARC4init(a)
ARC4next
: 
ƒ ARC4next()
ActivateFTD
: 
ƒ ActivateFTD()
Arcfour
: 
ƒ Arcfour()
AutoBet
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
AutoBetErrors
: 
ƒ AutoBetErrors(e)
BI_FP
: 
52
BI_RC
: 
(123) [empty × 48, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, empty × 7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, empty × 6, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
BI_RM
: 
"0123456789abcdefghijklmnopqrstuvwxyz"
Barrett
: 
ƒ Barrett(a)
BenefitsSliderChange
: 
ƒ BenefitsSliderChange(e)
BetErrors
: 
ƒ BetErrors(e)
BigInteger
: 
ƒ BigInteger(a,g,f)
Bitcoin
: 
Address
: 
ƒ (a)
Base58
: 
{alphabet: '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz', validRegex: /^[1-9A-HJ-NP-Za-km-z]+$/, base: BigInteger, encode: ƒ, decode: ƒ}
ECDSA
: 
{getBigRandom: ƒ, sign: ƒ, verify: ƒ, verifyRaw: ƒ, serializeSig: ƒ, …}
ECKey
: 
ƒ (e)
EventEmitter
: 
ƒ ()
Opcode
: 
ƒ (a)
Script
: 
ƒ (a)
Transaction
: 
ƒ (a)
TransactionIn
: 
ƒ (d)
TransactionOut
: 
ƒ (d)
Util
: 
base64ToBytes
: 
ƒ (a)
bytesToBase64
: 
ƒ (a)
length
: 
1
name
: 
"bytesToBase64"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
combined1393766573.js:8
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
0
: 
Closure
f
: 
{stringToBytes: ƒ, bytesToString: ƒ}
g
: 
{rotl: ƒ, rotr: ƒ, endian: ƒ, randomBytes: ƒ, bytesToWords: ƒ, …}
[[Prototype]]
: 
Object
1
: 
Global
$
: 
ƒ (a,c)
$jscomp
: 
{scope: {…}, ASSUME_ES5: false, ASSUME_NO_NATIVE_MAP: false, ASSUME_NO_NATIVE_SET: false, findInternal: ƒ, …}
ARC4init
: 
ƒ ARC4init(a)
ARC4next
: 
ƒ ARC4next()
ActivateFTD
: 
ƒ ActivateFTD()
Arcfour
: 
ƒ Arcfour()
AutoBet
: 
ƒ AutoBet(e, t, a, o, i, n, s, r, l, _, c, d, u, p, b, m, h, f, g, y)
AutoBetErrors
: 
ƒ AutoBetErrors(e)
BI_FP
: 
52
BI_RC
: 
(123) [empty × 48, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, empty × 7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, empty × 6, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35]
BI_RM
: 
"0123456789abcdefghijklmnopqrstuvwxyz"
Barrett
: 
ƒ Barrett(a)
BenefitsSliderChange
: 
ƒ BenefitsSliderChange(e)
BetErrors
: 
ƒ BetErrors(e)
BigInteger
: 
ƒ BigInteger(a,g,f)
Bitcoin
: 
{Util: {…}, Base58: {…}, ECDSA: {…}, EventEmitter: ƒ, Address: ƒ, …}
BonusEndCountdown
: 
ƒ BonusEndCountdown(e, t)
CalculateWinAmount
: 
ƒ CalculateWinAmount()
Chart
: 
ƒ (t,e)
Classic
: 
ƒ Classic(a)
CloseAlertMsg
: 
ƒ CloseAlertMsg(e, t)
CloseDailyJPBanner
: 
ƒ CloseDailyJPBanner()
ClosePromoBanner
: 
ƒ ClosePromoBanner()
Color
: 
ƒ (t)
CountupCoronaPot
: 
ƒ CountupCoronaPot(starting_pot, final_amount, end_time)
CountupDailyJPPot
: 
ƒ CountupDailyJPPot(e, t, a)
CountupTimer
: 
ƒ CountupTimer(e, t, a, o)
CryptoJS
: 
{lib: {…}, enc: {…}, algo: {…}, SHA256: ƒ, HmacSHA256: ƒ, …}
DeleteAdCampaign
: 
ƒ DeleteAdCampaign(e)
DisplaySEMessage
: 
ƒ DisplaySEMessage(e, t, a)
DoubleYourBTC
: 
ƒ DoubleYourBTC(e)
ECCurveFp
: 
ƒ ECCurveFp(a,g,f)
ECFieldElementFp
: 
ƒ ECFieldElementFp(a,g)
ECPointFp
: 
ƒ ECPointFp(a,g,f,e)
EventEmitter
: 
ƒ ()
FUNDW
: 
ƒ FUNDW(e)
FUNPPriceLockTimer
: 
ƒ FUNPPriceLockTimer()
Fingerprint
: 
ƒ (p)
Foundation
: 
{name: 'Foundation', version: '4.3.2', cache: {…}, media_queries: {…}, stylesheet: CSSStyleSheet, …}
GenCaptchasNetCaptcha
: 
ƒ GenCaptchasNetCaptcha(elementId, captchaType, randomValue)
GenerateCaptchasNetCaptcha
: 
ƒ GenerateCaptchasNetCaptcha(e, t, a)
GenerateDepositAddress
: 
ƒ GenerateDepositAddress()
GenerateETHDepositAddress
: 
ƒ GenerateETHDepositAddress()
GenerateHashes
: 
ƒ GenerateHashes(e)
GenerateMainDepositAddress
: 
ƒ GenerateMainDepositAddress()
GenerateStatsTables
: 
ƒ GenerateStatsTables(e, t, a, o, i, n, s)
GetAdRejectedReason
: 
ƒ GetAdRejectedReason(e, t)
GetBetHistory
: 
ƒ GetBetHistory(e, t)
GetNewsContent
: 
ƒ GetNewsContent(e, t, a)
InitialStatsLoad
: 
ƒ InitialStatsLoad()
InitialUserStats
: 
ƒ InitialUserStats()
InsertAlertMsg
: 
ƒ InsertAlertMsg(e, t, a)
LoadParimutuelEvents
: 
ƒ LoadParimutuelEvents(e)
Modernizr
: 
{touch: false, svg: true, inlinesvg: true, svgclippaths: true, addTest: ƒ, …}
Montgomery
: 
ƒ Montgomery(a)
NullExp
: 
ƒ NullExp()
OpenParimutuelGame
: 
ƒ OpenParimutuelGame(e)
OpenRefPopup
: 
ƒ OpenRefPopup()
ParimutuelFocus
: 
ƒ ParimutuelFocus(e, t)
ParimutuelPlaceBet
: 
ƒ ParimutuelPlaceBet(e, t)
PauseAdCampaign
: 
ƒ PauseAdCampaign(e)
Placeholders
: 
{Utils: {…}, nativeSupport: true, disable: ƒ, enable: ƒ}
PlayCaptchasNetAudioCaptcha
: 
ƒ PlayCaptchasNetAudioCaptcha(e)
PreviousContestWinners
: 
ƒ PreviousContestWinners(e)
PreviousLotteryWinners
: 
ƒ PreviousLotteryWinners(e)
PriceChart
: 
ƒ PriceChart(e)
PrintWagerContestTables
: 
ƒ PrintWagerContestTables(e, t, a)
Raven
: 
o {a: true, b: true, c: true, d: null, e: null, …}
RecalculateFUNBenefitsBuyBox
: 
ƒ RecalculateFUNBenefitsBuyBox()
RecalculateFUNSavingsMaturity
: 
ƒ RecalculateFUNSavingsMaturity()
RedeemRPProduct
: 
ƒ RedeemRPProduct(e)
RefreshAdBalance
: 
ƒ RefreshAdBalance()
RefreshPageAfterFreePlayTimerEnds
: 
ƒ RefreshPageAfterFreePlayTimerEnds()
RenewCookies
: 
ƒ RenewCookies()
ReplaceNumberWithCommas
: 
ƒ ReplaceNumberWithCommas(e)
Reset2FAQuestions
: 
ƒ Reset2FAQuestions(e)
ScreeSizeCSSChanges
: 
ƒ ScreeSizeCSSChanges()
SecureRandom
: 
ƒ SecureRandom()
ShowAdDetails
: 
ƒ ShowAdDetails(e)
ShowAdStats
: 
ƒ ShowAdStats(e)
ShowAdvancedStats
: 
ƒ ShowAdvancedStats(e)
ShowMoreRefs
: 
ƒ ShowMoreRefs(e)
ShowNews
: 
ƒ ShowNews(e)
StartAdCampaign
: 
ƒ StartAdCampaign(e)
StopAutoBet
: 
ƒ StopAutoBet()
SubscribePush
: 
ƒ SubscribePush()
SwitchCaptchas
: 
ƒ SwitchCaptchas(e)
SwitchPageTabs
: 
ƒ SwitchPageTabs(e)
SwitchTabs
: 
ƒ SwitchTabs()
TransactionDatabase
: 
ƒ ()
UpdateAdStats
: 
ƒ UpdateAdStats()
UpdateFunPrice
: 
ƒ UpdateFunPrice()
UpdateStats
: 
ƒ UpdateStats()
UpdateUserStats
: 
ƒ UpdateUserStats()
VisitLink
: 
ƒ VisitLink(e)
X9ECParameters
: 
ƒ X9ECParameters(a,g,f,e)
ad_left
: 
1
alert
: 
ƒ alert()
am1
: 
ƒ am1(a,g,f,e,d,b)
am2
: 
ƒ am2(a,g,f,e,d,b)
am3
: 
ƒ am3(a,g,f,e,d,b)
atob
: 
ƒ atob()
auto_withdraw
: 
0
autobet_dnr
: 
false
autobet_history
: 
[]
autobet_running
: 
false
balanceChanged
: 
ƒ balanceChanged()
balance_last_changed
: 
1758605494
barrettConvert
: 
ƒ barrettConvert(a)
barrettMulTo
: 
ƒ barrettMulTo(a,g,f)
barrettReduce
: 
ƒ barrettReduce(a)
barrettRevert
: 
ƒ barrettRevert(a)
barrettSqrTo
: 
ƒ barrettSqrTo(a,g)
bet_history_page
: 
0
bitcoinsig_test
: 
ƒ bitcoinsig_test()
blur
: 
ƒ blur()
bnAbs
: 
ƒ bnAbs()
bnAdd
: 
ƒ bnAdd(a)
bnAnd
: 
ƒ bnAnd(a)
bnAndNot
: 
ƒ bnAndNot(a)
bnBitCount
: 
ƒ bnBitCount()
bnBitLength
: 
ƒ bnBitLength()
bnByteValue
: 
ƒ bnByteValue()
bnClearBit
: 
ƒ bnClearBit(a)
bnClone
: 
ƒ bnClone()
bnCompareTo
: 
ƒ bnCompareTo(a)
bnDivide
: 
ƒ bnDivide(a)
bnDivideAndRemainder
: 
ƒ bnDivideAndRemainder(a)
bnEquals
: 
ƒ bnEquals(a)
bnFlipBit
: 
ƒ bnFlipBit(a)
bnGCD
: 
ƒ bnGCD(a)
bnGetLowestSetBit
: 
ƒ bnGetLowestSetBit()
bnIntValue
: 
ƒ bnIntValue()
bnIsProbablePrime
: 
ƒ bnIsProbablePrime(a)
bnMax
: 
ƒ bnMax(a)
bnMin
: 
ƒ bnMin(a)
bnMod
: 
ƒ bnMod(a)
bnModInverse
: 
ƒ bnModInverse(a)
bnModPow
: 
ƒ bnModPow(a,g)
bnModPowInt
: 
ƒ bnModPowInt(a,g)
bnMultiply
: 
ƒ bnMultiply(a)
bnNegate
: 
ƒ bnNegate()
bnNot
: 
ƒ bnNot()
bnOr
: 
ƒ bnOr(a)
bnPow
: 
ƒ bnPow(a)
bnRemainder
: 
ƒ bnRemainder(a)
bnSetBit
: 
ƒ bnSetBit(a)
bnShiftLeft
: 
ƒ bnShiftLeft(a)
bnShiftRight
: 
ƒ bnShiftRight(a)
bnShortValue
: 
ƒ bnShortValue()
bnSigNum
: 
ƒ bnSigNum()
bnSquare
: 
ƒ bnSquare()
bnSubtract
: 
ƒ bnSubtract(a)
bnTestBit
: 
ƒ bnTestBit(a)
bnToByteArray
: 
ƒ bnToByteArray()
bnToString
: 
ƒ bnToString(a)
bnXor
: 
ƒ bnXor(a)
bnpAddTo
: 
ƒ bnpAddTo(a,g)
bnpBitwiseTo
: 
ƒ bnpBitwiseTo(a,g,f)
bnpChangeBit
: 
ƒ bnpChangeBit(a,g)
bnpChunkSize
: 
ƒ bnpChunkSize(a)
bnpClamp
: 
ƒ bnpClamp()
bnpCopyTo
: 
ƒ bnpCopyTo(a)
bnpDAddOffset
: 
ƒ bnpDAddOffset(a,g)
bnpDLShiftTo
: 
ƒ bnpDLShiftTo(a,g)
bnpDMultiply
: 
ƒ bnpDMultiply(a)
bnpDRShiftTo
: 
ƒ bnpDRShiftTo(a,g)
bnpDivRemTo
: 
ƒ bnpDivRemTo(a,g,f)
bnpExp
: 
ƒ bnpExp(a,g)
bnpFromInt
: 
ƒ bnpFromInt(a)
bnpFromNumber
: 
ƒ bnpFromNumber(a,g,f)
bnpFromRadix
: 
ƒ bnpFromRadix(a,g)
bnpFromString
: 
ƒ bnpFromString(a,g)
bnpInvDigit
: 
ƒ bnpInvDigit()
bnpIsEven
: 
ƒ bnpIsEven()
bnpLShiftTo
: 
ƒ bnpLShiftTo(a,g)
bnpMillerRabin
: 
ƒ bnpMillerRabin(a)
bnpModInt
: 
ƒ bnpModInt(a)
bnpMultiplyLowerTo
: 
ƒ bnpMultiplyLowerTo(a,g,f)
bnpMultiplyTo
: 
ƒ bnpMultiplyTo(a,g)
bnpMultiplyUpperTo
: 
ƒ bnpMultiplyUpperTo(a,g,f)
bnpRShiftTo
: 
ƒ bnpRShiftTo(a,g)
bnpSquareTo
: 
ƒ bnpSquareTo(a)
bnpSubTo
: 
ƒ bnpSubTo(a,g)
bnpToRadix
: 
ƒ bnpToRadix(a)
bonus_locked_balance
: 
0
bonus_table_closed
: 
1
bonus_wagering_remaining
: 
0
btoa
: 
ƒ btoa()
cConvert
: 
ƒ cConvert(a)
cMulTo
: 
ƒ cMulTo(a,g,f)
cReduce
: 
ƒ cReduce(a)
cRevert
: 
ƒ cRevert(a)
cSqrTo
: 
ƒ cSqrTo(a,g)
caches
: 
CacheStorage {}
canary
: 
244837814094590
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
captcha_type
: 
1
captureEvents
: 
ƒ captureEvents()
(...)
bytesToHex
: 
ƒ (a)
length
: 
1
name
: 
"bytesToHex"
prototype
: 
constructor
: 
ƒ (a)
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
assign
: 
ƒ assign()
create
: 
ƒ create()
defineProperties
: 
ƒ defineProperties()
defineProperty
: 
ƒ defineProperty()
entries
: 
ƒ entries()
freeze
: 
ƒ freeze()
length
: 
1
name
: 
"freeze"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
fromEntries
: 
ƒ fromEntries()
getOwnPropertyDescriptor
: 
ƒ getOwnPropertyDescriptor()
getOwnPropertyDescriptors
: 
ƒ getOwnPropertyDescriptors()
getOwnPropertyNames
: 
ƒ getOwnPropertyNames()
getOwnPropertySymbols
: 
ƒ getOwnPropertySymbols()
getPrototypeOf
: 
ƒ getPrototypeOf()
groupBy
: 
ƒ groupBy()
hasOwn
: 
ƒ hasOwn()
is
: 
ƒ is()
isExtensible
: 
ƒ isExtensible()
isFrozen
: 
ƒ isFrozen()
isSealed
: 
ƒ isSealed()
keys
: 
ƒ keys()
length
: 
1
name
: 
"Object"
preventExtensions
: 
ƒ preventExtensions()
prototype
: 
{__defineGetter__: ƒ, __defineSetter__: ƒ, hasOwnProperty: ƒ, __lookupGetter__: ƒ, __lookupSetter__: ƒ, …}
seal
: 
ƒ seal()
setPrototypeOf
: 
ƒ setPrototypeOf()
values
: 
ƒ values()
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
hasOwnProperty
: 
ƒ hasOwnProperty()
length
: 
1
name
: 
"hasOwnProperty"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
combined1393766573.js:8
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
bytesToLWords
: 
ƒ (a)
bytesToWords
: 
ƒ (a)
endian
: 
ƒ (a)
formatValue
: 
ƒ (a)
hexToBytes
: 
ƒ (a)
isArray
: 
ƒ isArray()
lWordsToBytes
: 
ƒ (a)
makeFilledArray
: 
ƒ (a,g)
numToVarInt
: 
ƒ (a)
parseValue
: 
ƒ (a)
randomBytes
: 
ƒ (a)
rotl
: 
ƒ (a,d)
rotr
: 
ƒ (a,d)
sha256ripe160
: 
ƒ (a)
valueToBigInt
: 
ƒ (a)
wordsToBytes
: 
ƒ (a)
[[Prototype]]
: 
Object
Wallet
: 
ƒ ()
[[Prototype]]
: 
Object
BonusEndCountdown
: 
ƒ BonusEndCountdown(e, t)
CalculateWinAmount
: 
ƒ CalculateWinAmount()
Chart
: 
ƒ (t,e)
Classic
: 
ƒ Classic(a)
CloseAlertMsg
: 
ƒ CloseAlertMsg(e, t)
CloseDailyJPBanner
: 
ƒ CloseDailyJPBanner()
ClosePromoBanner
: 
ƒ ClosePromoBanner()
Color
: 
ƒ (t)
CountupCoronaPot
: 
ƒ CountupCoronaPot(starting_pot, final_amount, end_time)
CountupDailyJPPot
: 
ƒ CountupDailyJPPot(e, t, a)
CountupTimer
: 
ƒ CountupTimer(e, t, a, o)
CryptoJS
: 
{lib: {…}, enc: {…}, algo: {…}, SHA256: ƒ, HmacSHA256: ƒ, …}
DeleteAdCampaign
: 
ƒ DeleteAdCampaign(e)
DisplaySEMessage
: 
ƒ DisplaySEMessage(e, t, a)
DoubleYourBTC
: 
ƒ DoubleYourBTC(e)
ECCurveFp
: 
ƒ ECCurveFp(a,g,f)
ECFieldElementFp
: 
ƒ ECFieldElementFp(a,g)
ECPointFp
: 
ƒ ECPointFp(a,g,f,e)
EventEmitter
: 
ƒ ()
FUNDW
: 
ƒ FUNDW(e)
FUNPPriceLockTimer
: 
ƒ FUNPPriceLockTimer()
Fingerprint
: 
ƒ (p)
Foundation
: 
{name: 'Foundation', version: '4.3.2', cache: {…}, media_queries: {…}, stylesheet: CSSStyleSheet, …}
GenCaptchasNetCaptcha
: 
ƒ GenCaptchasNetCaptcha(elementId, captchaType, randomValue)
GenerateCaptchasNetCaptcha
: 
ƒ GenerateCaptchasNetCaptcha(e, t, a)
GenerateDepositAddress
: 
ƒ GenerateDepositAddress()
GenerateETHDepositAddress
: 
ƒ GenerateETHDepositAddress()
GenerateHashes
: 
ƒ GenerateHashes(e)
GenerateMainDepositAddress
: 
ƒ GenerateMainDepositAddress()
GenerateStatsTables
: 
ƒ GenerateStatsTables(e, t, a, o, i, n, s)
GetAdRejectedReason
: 
ƒ GetAdRejectedReason(e, t)
GetBetHistory
: 
ƒ GetBetHistory(e, t)
GetNewsContent
: 
ƒ GetNewsContent(e, t, a)
InitialStatsLoad
: 
ƒ InitialStatsLoad()
InitialUserStats
: 
ƒ InitialUserStats()
InsertAlertMsg
: 
ƒ InsertAlertMsg(e, t, a)
LoadParimutuelEvents
: 
ƒ LoadParimutuelEvents(e)
Modernizr
: 
{touch: false, svg: true, inlinesvg: true, svgclippaths: true, addTest: ƒ, …}
Montgomery
: 
ƒ Montgomery(a)
NullExp
: 
ƒ NullExp()
OpenParimutuelGame
: 
ƒ OpenParimutuelGame(e)
OpenRefPopup
: 
ƒ OpenRefPopup()
ParimutuelFocus
: 
ƒ ParimutuelFocus(e, t)
ParimutuelPlaceBet
: 
ƒ ParimutuelPlaceBet(e, t)
PauseAdCampaign
: 
ƒ PauseAdCampaign(e)
Placeholders
: 
{Utils: {…}, nativeSupport: true, disable: ƒ, enable: ƒ}
PlayCaptchasNetAudioCaptcha
: 
ƒ PlayCaptchasNetAudioCaptcha(e)
PreviousContestWinners
: 
ƒ PreviousContestWinners(e)
PreviousLotteryWinners
: 
ƒ PreviousLotteryWinners(e)
PriceChart
: 
ƒ PriceChart(e)
PrintWagerContestTables
: 
ƒ PrintWagerContestTables(e, t, a)
Raven
: 
o {a: true, b: true, c: true, d: null, e: null, …}
RecalculateFUNBenefitsBuyBox
: 
ƒ RecalculateFUNBenefitsBuyBox()
RecalculateFUNSavingsMaturity
: 
ƒ RecalculateFUNSavingsMaturity()
RedeemRPProduct
: 
ƒ RedeemRPProduct(e)
RefreshAdBalance
: 
ƒ RefreshAdBalance()
RefreshPageAfterFreePlayTimerEnds
: 
ƒ RefreshPageAfterFreePlayTimerEnds()
RenewCookies
: 
ƒ RenewCookies()
ReplaceNumberWithCommas
: 
ƒ ReplaceNumberWithCommas(e)
Reset2FAQuestions
: 
ƒ Reset2FAQuestions(e)
ScreeSizeCSSChanges
: 
ƒ ScreeSizeCSSChanges()
SecureRandom
: 
ƒ SecureRandom()
ShowAdDetails
: 
ƒ ShowAdDetails(e)
ShowAdStats
: 
ƒ ShowAdStats(e)
ShowAdvancedStats
: 
ƒ ShowAdvancedStats(e)
ShowMoreRefs
: 
ƒ ShowMoreRefs(e)
ShowNews
: 
ƒ ShowNews(e)
StartAdCampaign
: 
ƒ StartAdCampaign(e)
StopAutoBet
: 
ƒ StopAutoBet()
SubscribePush
: 
ƒ SubscribePush()
SwitchCaptchas
: 
ƒ SwitchCaptchas(e)
SwitchPageTabs
: 
ƒ SwitchPageTabs(e)
SwitchTabs
: 
ƒ SwitchTabs()
TransactionDatabase
: 
ƒ ()
UpdateAdStats
: 
ƒ UpdateAdStats()
UpdateFunPrice
: 
ƒ UpdateFunPrice()
UpdateStats
: 
ƒ UpdateStats()
UpdateUserStats
: 
ƒ UpdateUserStats()
VisitLink
: 
ƒ VisitLink(e)
X9ECParameters
: 
ƒ X9ECParameters(a,g,f,e)
ad_left
: 
1
alert
: 
ƒ alert()
am1
: 
ƒ am1(a,g,f,e,d,b)
am2
: 
ƒ am2(a,g,f,e,d,b)
am3
: 
ƒ am3(a,g,f,e,d,b)
atob
: 
ƒ atob()
auto_withdraw
: 
0
autobet_dnr
: 
false
autobet_history
: 
[]
autobet_running
: 
false
balanceChanged
: 
ƒ balanceChanged()
balance_last_changed
: 
1758605494
barrettConvert
: 
ƒ barrettConvert(a)
barrettMulTo
: 
ƒ barrettMulTo(a,g,f)
barrettReduce
: 
ƒ barrettReduce(a)
barrettRevert
: 
ƒ barrettRevert(a)
barrettSqrTo
: 
ƒ barrettSqrTo(a,g)
bet_history_page
: 
0
bitcoinsig_test
: 
ƒ bitcoinsig_test()
blur
: 
ƒ blur()
bnAbs
: 
ƒ bnAbs()
bnAdd
: 
ƒ bnAdd(a)
bnAnd
: 
ƒ bnAnd(a)
bnAndNot
: 
ƒ bnAndNot(a)
bnBitCount
: 
ƒ bnBitCount()
bnBitLength
: 
ƒ bnBitLength()
bnByteValue
: 
ƒ bnByteValue()
bnClearBit
: 
ƒ bnClearBit(a)
bnClone
: 
ƒ bnClone()
bnCompareTo
: 
ƒ bnCompareTo(a)
bnDivide
: 
ƒ bnDivide(a)
bnDivideAndRemainder
: 
ƒ bnDivideAndRemainder(a)
bnEquals
: 
ƒ bnEquals(a)
bnFlipBit
: 
ƒ bnFlipBit(a)
bnGCD
: 
ƒ bnGCD(a)
bnGetLowestSetBit
: 
ƒ bnGetLowestSetBit()
bnIntValue
: 
ƒ bnIntValue()
bnIsProbablePrime
: 
ƒ bnIsProbablePrime(a)
bnMax
: 
ƒ bnMax(a)
bnMin
: 
ƒ bnMin(a)
bnMod
: 
ƒ bnMod(a)
bnModInverse
: 
ƒ bnModInverse(a)
bnModPow
: 
ƒ bnModPow(a,g)
bnModPowInt
: 
ƒ bnModPowInt(a,g)
bnMultiply
: 
ƒ bnMultiply(a)
bnNegate
: 
ƒ bnNegate()
bnNot
: 
ƒ bnNot()
bnOr
: 
ƒ bnOr(a)
bnPow
: 
ƒ bnPow(a)
bnRemainder
: 
ƒ bnRemainder(a)
bnSetBit
: 
ƒ bnSetBit(a)
bnShiftLeft
: 
ƒ bnShiftLeft(a)
bnShiftRight
: 
ƒ bnShiftRight(a)
bnShortValue
: 
ƒ bnShortValue()
bnSigNum
: 
ƒ bnSigNum()
bnSquare
: 
ƒ bnSquare()
bnSubtract
: 
ƒ bnSubtract(a)
bnTestBit
: 
ƒ bnTestBit(a)
bnToByteArray
: 
ƒ bnToByteArray()
bnToString
: 
ƒ bnToString(a)
bnXor
: 
ƒ bnXor(a)
bnpAddTo
: 
ƒ bnpAddTo(a,g)
bnpBitwiseTo
: 
ƒ bnpBitwiseTo(a,g,f)
bnpChangeBit
: 
ƒ bnpChangeBit(a,g)
bnpChunkSize
: 
ƒ bnpChunkSize(a)
bnpClamp
: 
ƒ bnpClamp()
bnpCopyTo
: 
ƒ bnpCopyTo(a)
bnpDAddOffset
: 
ƒ bnpDAddOffset(a,g)
bnpDLShiftTo
: 
ƒ bnpDLShiftTo(a,g)
bnpDMultiply
: 
ƒ bnpDMultiply(a)
bnpDRShiftTo
: 
ƒ bnpDRShiftTo(a,g)
bnpDivRemTo
: 
ƒ bnpDivRemTo(a,g,f)
bnpExp
: 
ƒ bnpExp(a,g)
bnpFromInt
: 
ƒ bnpFromInt(a)
bnpFromNumber
: 
ƒ bnpFromNumber(a,g,f)
bnpFromRadix
: 
ƒ bnpFromRadix(a,g)
bnpFromString
: 
ƒ bnpFromString(a,g)
bnpInvDigit
: 
ƒ bnpInvDigit()
bnpIsEven
: 
ƒ bnpIsEven()
bnpLShiftTo
: 
ƒ bnpLShiftTo(a,g)
bnpMillerRabin
: 
ƒ bnpMillerRabin(a)
bnpModInt
: 
ƒ bnpModInt(a)
bnpMultiplyLowerTo
: 
ƒ bnpMultiplyLowerTo(a,g,f)
bnpMultiplyTo
: 
ƒ bnpMultiplyTo(a,g)
bnpMultiplyUpperTo
: 
ƒ bnpMultiplyUpperTo(a,g,f)
bnpRShiftTo
: 
ƒ bnpRShiftTo(a,g)
bnpSquareTo
: 
ƒ bnpSquareTo(a)
bnpSubTo
: 
ƒ bnpSubTo(a,g)
bnpToRadix
: 
ƒ bnpToRadix(a)
bonus_locked_balance
: 
0
bonus_table_closed
: 
1
bonus_wagering_remaining
: 
0
btoa
: 
ƒ btoa()
cConvert
: 
ƒ cConvert(a)
cMulTo
: 
ƒ cMulTo(a,g,f)
cReduce
: 
ƒ cReduce(a)
cRevert
: 
ƒ cRevert(a)
cSqrTo
: 
ƒ cSqrTo(a,g)
caches
: 
CacheStorage {}
canary
: 
244837814094590
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
captcha_type
: 
1
captureEvents
: 
ƒ captureEvents()
(...)
X9ECParameters
: 
ƒ X9ECParameters(a,g,f,e)
ad_left
: 
1
alert
: 
ƒ alert()
am1
: 
ƒ am1(a,g,f,e,d,b)
am2
: 
ƒ am2(a,g,f,e,d,b)
am3
: 
ƒ am3(a,g,f,e,d,b)
atob
: 
ƒ atob()
auto_withdraw
: 
0
autobet_dnr
: 
false
autobet_history
: 
[]
autobet_running
: 
false
balanceChanged
: 
ƒ balanceChanged()
balance_last_changed
: 
1758605494
barrettConvert
: 
ƒ barrettConvert(a)
barrettMulTo
: 
ƒ barrettMulTo(a,g,f)
barrettReduce
: 
ƒ barrettReduce(a)
barrettRevert
: 
ƒ barrettRevert(a)
barrettSqrTo
: 
ƒ barrettSqrTo(a,g)
bet_history_page
: 
0
bitcoinsig_test
: 
ƒ bitcoinsig_test()
blur
: 
ƒ blur()
bnAbs
: 
ƒ bnAbs()
bnAdd
: 
ƒ bnAdd(a)
bnAnd
: 
ƒ bnAnd(a)
bnAndNot
: 
ƒ bnAndNot(a)
bnBitCount
: 
ƒ bnBitCount()
bnBitLength
: 
ƒ bnBitLength()
bnByteValue
: 
ƒ bnByteValue()
bnClearBit
: 
ƒ bnClearBit(a)
bnClone
: 
ƒ bnClone()
bnCompareTo
: 
ƒ bnCompareTo(a)
bnDivide
: 
ƒ bnDivide(a)
bnDivideAndRemainder
: 
ƒ bnDivideAndRemainder(a)
bnEquals
: 
ƒ bnEquals(a)
bnFlipBit
: 
ƒ bnFlipBit(a)
bnGCD
: 
ƒ bnGCD(a)
bnGetLowestSetBit
: 
ƒ bnGetLowestSetBit()
bnIntValue
: 
ƒ bnIntValue()
bnIsProbablePrime
: 
ƒ bnIsProbablePrime(a)
bnMax
: 
ƒ bnMax(a)
bnMin
: 
ƒ bnMin(a)
bnMod
: 
ƒ bnMod(a)
bnModInverse
: 
ƒ bnModInverse(a)
bnModPow
: 
ƒ bnModPow(a,g)
bnModPowInt
: 
ƒ bnModPowInt(a,g)
bnMultiply
: 
ƒ bnMultiply(a)
bnNegate
: 
ƒ bnNegate()
bnNot
: 
ƒ bnNot()
bnOr
: 
ƒ bnOr(a)
bnPow
: 
ƒ bnPow(a)
bnRemainder
: 
ƒ bnRemainder(a)
bnSetBit
: 
ƒ bnSetBit(a)
bnShiftLeft
: 
ƒ bnShiftLeft(a)
bnShiftRight
: 
ƒ bnShiftRight(a)
bnShortValue
: 
ƒ bnShortValue()
bnSigNum
: 
ƒ bnSigNum()
bnSquare
: 
ƒ bnSquare()
bnSubtract
: 
ƒ bnSubtract(a)
bnTestBit
: 
ƒ bnTestBit(a)
bnToByteArray
: 
ƒ bnToByteArray()
bnToString
: 
ƒ bnToString(a)
bnXor
: 
ƒ bnXor(a)
bnpAddTo
: 
ƒ bnpAddTo(a,g)
bnpBitwiseTo
: 
ƒ bnpBitwiseTo(a,g,f)
bnpChangeBit
: 
ƒ bnpChangeBit(a,g)
bnpChunkSize
: 
ƒ bnpChunkSize(a)
bnpClamp
: 
ƒ bnpClamp()
bnpCopyTo
: 
ƒ bnpCopyTo(a)
bnpDAddOffset
: 
ƒ bnpDAddOffset(a,g)
bnpDLShiftTo
: 
ƒ bnpDLShiftTo(a,g)
bnpDMultiply
: 
ƒ bnpDMultiply(a)
bnpDRShiftTo
: 
ƒ bnpDRShiftTo(a,g)
bnpDivRemTo
: 
ƒ bnpDivRemTo(a,g,f)
bnpExp
: 
ƒ bnpExp(a,g)
bnpFromInt
: 
ƒ bnpFromInt(a)
bnpFromNumber
: 
ƒ bnpFromNumber(a,g,f)
bnpFromRadix
: 
ƒ bnpFromRadix(a,g)
bnpFromString
: 
ƒ bnpFromString(a,g)
bnpInvDigit
: 
ƒ bnpInvDigit()
bnpIsEven
: 
ƒ bnpIsEven()
bnpLShiftTo
: 
ƒ bnpLShiftTo(a,g)
bnpMillerRabin
: 
ƒ bnpMillerRabin(a)
bnpModInt
: 
ƒ bnpModInt(a)
bnpMultiplyLowerTo
: 
ƒ bnpMultiplyLowerTo(a,g,f)
bnpMultiplyTo
: 
ƒ bnpMultiplyTo(a,g)
bnpMultiplyUpperTo
: 
ƒ bnpMultiplyUpperTo(a,g,f)
bnpRShiftTo
: 
ƒ bnpRShiftTo(a,g)
bnpSquareTo
: 
ƒ bnpSquareTo(a)
bnpSubTo
: 
ƒ bnpSubTo(a,g)
bnpToRadix
: 
ƒ bnpToRadix(a)
bonus_locked_balance
: 
0
bonus_table_closed
: 
1
bonus_wagering_remaining
: 
0
btoa
: 
ƒ btoa()
cConvert
: 
ƒ cConvert(a)
cMulTo
: 
ƒ cMulTo(a,g,f)
cReduce
: 
ƒ cReduce(a)
cRevert
: 
ƒ cRevert(a)
cSqrTo
: 
ƒ cSqrTo(a,g)
caches
: 
CacheStorage {}
canary
: 
244837814094590
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
captcha_type
: 
1
captureEvents
: 
ƒ captureEvents()
(...)
X9ECParameters
: 
ƒ X9ECParameters(a,g,f,e)
ad_left
: 
1
alert
: 
ƒ alert()
am1
: 
ƒ am1(a,g,f,e,d,b)
am2
: 
ƒ am2(a,g,f,e,d,b)
am3
: 
ƒ am3(a,g,f,e,d,b)
atob
: 
ƒ atob()
auto_withdraw
: 
0
autobet_dnr
: 
false
autobet_history
: 
[]
autobet_running
: 
false
balanceChanged
: 
ƒ balanceChanged()
balance_last_changed
: 
1758605494
barrettConvert
: 
ƒ barrettConvert(a)
barrettMulTo
: 
ƒ barrettMulTo(a,g,f)
barrettReduce
: 
ƒ barrettReduce(a)
barrettRevert
: 
ƒ barrettRevert(a)
barrettSqrTo
: 
ƒ barrettSqrTo(a,g)
bet_history_page
: 
0
bitcoinsig_test
: 
ƒ bitcoinsig_test()
blur
: 
ƒ blur()
bnAbs
: 
ƒ bnAbs()
bnAdd
: 
ƒ bnAdd(a)
bnAnd
: 
ƒ bnAnd(a)
bnAndNot
: 
ƒ bnAndNot(a)
bnBitCount
: 
ƒ bnBitCount()
bnBitLength
: 
ƒ bnBitLength()
bnByteValue
: 
ƒ bnByteValue()
bnClearBit
: 
ƒ bnClearBit(a)
bnClone
: 
ƒ bnClone()
bnCompareTo
: 
ƒ bnCompareTo(a)
bnDivide
: 
ƒ bnDivide(a)
bnDivideAndRemainder
: 
ƒ bnDivideAndRemainder(a)
bnEquals
: 
ƒ bnEquals(a)
bnFlipBit
: 
ƒ bnFlipBit(a)
bnGCD
: 
ƒ bnGCD(a)
bnGetLowestSetBit
: 
ƒ bnGetLowestSetBit()
bnIntValue
: 
ƒ bnIntValue()
bnIsProbablePrime
: 
ƒ bnIsProbablePrime(a)
bnMax
: 
ƒ bnMax(a)
bnMin
: 
ƒ bnMin(a)
bnMod
: 
ƒ bnMod(a)
bnModInverse
: 
ƒ bnModInverse(a)
bnModPow
: 
ƒ bnModPow(a,g)
bnModPowInt
: 
ƒ bnModPowInt(a,g)
bnMultiply
: 
ƒ bnMultiply(a)
bnNegate
: 
ƒ bnNegate()
bnNot
: 
ƒ bnNot()
bnOr
: 
ƒ bnOr(a)
bnPow
: 
ƒ bnPow(a)
bnRemainder
: 
ƒ bnRemainder(a)
bnSetBit
: 
ƒ bnSetBit(a)
bnShiftLeft
: 
ƒ bnShiftLeft(a)
bnShiftRight
: 
ƒ bnShiftRight(a)
bnShortValue
: 
ƒ bnShortValue()
bnSigNum
: 
ƒ bnSigNum()
bnSquare
: 
ƒ bnSquare()
bnSubtract
: 
ƒ bnSubtract(a)
bnTestBit
: 
ƒ bnTestBit(a)
bnToByteArray
: 
ƒ bnToByteArray()
bnToString
: 
ƒ bnToString(a)
bnXor
: 
ƒ bnXor(a)
bnpAddTo
: 
ƒ bnpAddTo(a,g)
bnpBitwiseTo
: 
ƒ bnpBitwiseTo(a,g,f)
bnpChangeBit
: 
ƒ bnpChangeBit(a,g)
bnpChunkSize
: 
ƒ bnpChunkSize(a)
bnpClamp
: 
ƒ bnpClamp()
bnpCopyTo
: 
ƒ bnpCopyTo(a)
bnpDAddOffset
: 
ƒ bnpDAddOffset(a,g)
bnpDLShiftTo
: 
ƒ bnpDLShiftTo(a,g)
bnpDMultiply
: 
ƒ bnpDMultiply(a)
bnpDRShiftTo
: 
ƒ bnpDRShiftTo(a,g)
bnpDivRemTo
: 
ƒ bnpDivRemTo(a,g,f)
bnpExp
: 
ƒ bnpExp(a,g)
bnpFromInt
: 
ƒ bnpFromInt(a)
bnpFromNumber
: 
ƒ bnpFromNumber(a,g,f)
bnpFromRadix
: 
ƒ bnpFromRadix(a,g)
bnpFromString
: 
ƒ bnpFromString(a,g)
bnpInvDigit
: 
ƒ bnpInvDigit()
bnpIsEven
: 
ƒ bnpIsEven()
bnpLShiftTo
: 
ƒ bnpLShiftTo(a,g)
bnpMillerRabin
: 
ƒ bnpMillerRabin(a)
bnpModInt
: 
ƒ bnpModInt(a)
bnpMultiplyLowerTo
: 
ƒ bnpMultiplyLowerTo(a,g,f)
bnpMultiplyTo
: 
ƒ bnpMultiplyTo(a,g)
bnpMultiplyUpperTo
: 
ƒ bnpMultiplyUpperTo(a,g,f)
bnpRShiftTo
: 
ƒ bnpRShiftTo(a,g)
bnpSquareTo
: 
ƒ bnpSquareTo(a)
bnpSubTo
: 
ƒ bnpSubTo(a,g)
bnpToRadix
: 
ƒ bnpToRadix(a)
bonus_locked_balance
: 
0
bonus_table_closed
: 
1
bonus_wagering_remaining
: 
0
btoa
: 
ƒ btoa()
cConvert
: 
ƒ cConvert(a)
cMulTo
: 
ƒ cMulTo(a,g,f)
cReduce
: 
ƒ cReduce(a)
cRevert
: 
ƒ cRevert(a)
cSqrTo
: 
ƒ cSqrTo(a,g)
caches
: 
CacheStorage {}
canary
: 
244837814094590
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
captcha_type
: 
1
captureEvents
: 
ƒ captureEvents()
(...)
BI_FP
: 
52
BI_RC
: 
Array(123)
48
: 
0
49
: 
1
50
: 
2
51
: 
3
52
: 
4
53
: 
5
54
: 
6
55
: 
7
56
: 
8
57
: 
9
65
: 
10
66
: 
11
67
: 
12
68
: 
13
69
: 
14
70
: 
15
71
: 
16
72
: 
17
73
: 
18
74
: 
19
75
: 
20
76
: 
21
77
: 
22
78
: 
23
79
: 
24
80
: 
25
81
: 
26
82
: 
27
83
: 
28
84
: 
29
85
: 
30
86
: 
31
87
: 
32
88
: 
33
89
: 
34
90
: 
35
97
: 
10
98
: 
11
99
: 
12
100
: 
13
101
: 
14
102
: 
15
103
: 
16
104
: 
17
105
: 
18
106
: 
19
107
: 
20
108
: 
21
109
: 
22
110
: 
23
111
: 
24
112
: 
25
113
: 
26
114
: 
27
115
: 
28
116
: 
29
117
: 
30
118
: 
31
119
: 
32
120
: 
33
121
: 
34
122
: 
35
length
: 
123
[[Prototype]]
: 
Array(0)
at
: 
ƒ at()
concat
: 
ƒ concat()
constructor
: 
ƒ Array()
copyWithin
: 
ƒ copyWithin()
entries
: 
ƒ entries()
every
: 
ƒ every()
fill
: 
ƒ fill()
filter
: 
ƒ filter()
find
: 
ƒ find()
findIndex
: 
ƒ findIndex()
findLast
: 
ƒ findLast()
findLastIndex
: 
ƒ findLastIndex()
flat
: 
ƒ flat()
flatMap
: 
ƒ flatMap()
forEach
: 
ƒ forEach()
includes
: 
ƒ includes()
indexOf
: 
ƒ indexOf()
join
: 
ƒ join()
keys
: 
ƒ keys()
lastIndexOf
: 
ƒ lastIndexOf()
length
: 
0
map
: 
ƒ map()
pop
: 
ƒ pop()
push
: 
ƒ push()
reduce
: 
ƒ reduce()
reduceRight
: 
ƒ reduceRight()
reverse
: 
ƒ reverse()
shift
: 
ƒ shift()
slice
: 
ƒ slice()
length
: 
2
name
: 
"slice"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
some
: 
ƒ some()
sort
: 
ƒ sort()
splice
: 
ƒ splice()
toLocaleString
: 
ƒ toLocaleString()
toReversed
: 
ƒ toReversed()
toSorted
: 
ƒ toSorted()
toSpliced
: 
ƒ toSpliced()
toString
: 
ƒ toString()
unshift
: 
ƒ unshift()
values
: 
ƒ values()
with
: 
ƒ with()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.unscopables)
: 
{at: true, copyWithin: true, entries: true, fill: true, find: true, …}
[[Prototype]]
: 
Object
BI_RM
: 
"0123456789abcdefghijklmnopqrstuvwxyz"
Barrett
: 
ƒ Barrett(a)
BenefitsSliderChange
: 
ƒ BenefitsSliderChange(e)
BetErrors
: 
ƒ BetErrors(e)
BigInteger
: 
ƒ BigInteger(a,g,f)
Bitcoin
: 
{Util: {…}, Base58: {…}, ECDSA: {…}, EventEmitter: ƒ, Address: ƒ, …}
BonusEndCountdown
: 
ƒ BonusEndCountdown(e, t)
CalculateWinAmount
: 
ƒ CalculateWinAmount()
Chart
: 
ƒ (t,e)
Classic
: 
ƒ Classic(a)
CloseAlertMsg
: 
ƒ CloseAlertMsg(e, t)
CloseDailyJPBanner
: 
ƒ CloseDailyJPBanner()
ClosePromoBanner
: 
ƒ ClosePromoBanner()
Color
: 
ƒ (t)
CountupCoronaPot
: 
ƒ CountupCoronaPot(starting_pot, final_amount, end_time)
CountupDailyJPPot
: 
ƒ CountupDailyJPPot(e, t, a)
CountupTimer
: 
ƒ CountupTimer(e, t, a, o)
CryptoJS
: 
{lib: {…}, enc: {…}, algo: {…}, SHA256: ƒ, HmacSHA256: ƒ, …}
DeleteAdCampaign
: 
ƒ DeleteAdCampaign(e)
DisplaySEMessage
: 
ƒ DisplaySEMessage(e, t, a)
DoubleYourBTC
: 
ƒ DoubleYourBTC(e)
ECCurveFp
: 
ƒ ECCurveFp(a,g,f)
ECFieldElementFp
: 
ƒ ECFieldElementFp(a,g)
ECPointFp
: 
ƒ ECPointFp(a,g,f,e)
EventEmitter
: 
ƒ ()
FUNDW
: 
ƒ FUNDW(e)
FUNPPriceLockTimer
: 
ƒ FUNPPriceLockTimer()
Fingerprint
: 
ƒ (p)
Foundation
: 
{name: 'Foundation', version: '4.3.2', cache: {…}, media_queries: {…}, stylesheet: CSSStyleSheet, …}
GenCaptchasNetCaptcha
: 
ƒ GenCaptchasNetCaptcha(elementId, captchaType, randomValue)
GenerateCaptchasNetCaptcha
: 
ƒ GenerateCaptchasNetCaptcha(e, t, a)
GenerateDepositAddress
: 
ƒ GenerateDepositAddress()
GenerateETHDepositAddress
: 
ƒ GenerateETHDepositAddress()
GenerateHashes
: 
ƒ GenerateHashes(e)
GenerateMainDepositAddress
: 
ƒ GenerateMainDepositAddress()
GenerateStatsTables
: 
ƒ GenerateStatsTables(e, t, a, o, i, n, s)
GetAdRejectedReason
: 
ƒ GetAdRejectedReason(e, t)
GetBetHistory
: 
ƒ GetBetHistory(e, t)
GetNewsContent
: 
ƒ GetNewsContent(e, t, a)
InitialStatsLoad
: 
ƒ InitialStatsLoad()
InitialUserStats
: 
ƒ InitialUserStats()
InsertAlertMsg
: 
ƒ InsertAlertMsg(e, t, a)
LoadParimutuelEvents
: 
ƒ LoadParimutuelEvents(e)
Modernizr
: 
{touch: false, svg: true, inlinesvg: true, svgclippaths: true, addTest: ƒ, …}
Montgomery
: 
ƒ Montgomery(a)
NullExp
: 
ƒ NullExp()
OpenParimutuelGame
: 
ƒ OpenParimutuelGame(e)
OpenRefPopup
: 
ƒ OpenRefPopup()
ParimutuelFocus
: 
ƒ ParimutuelFocus(e, t)
ParimutuelPlaceBet
: 
ƒ ParimutuelPlaceBet(e, t)
PauseAdCampaign
: 
ƒ PauseAdCampaign(e)
Placeholders
: 
{Utils: {…}, nativeSupport: true, disable: ƒ, enable: ƒ}
PlayCaptchasNetAudioCaptcha
: 
ƒ PlayCaptchasNetAudioCaptcha(e)
PreviousContestWinners
: 
ƒ PreviousContestWinners(e)
PreviousLotteryWinners
: 
ƒ PreviousLotteryWinners(e)
PriceChart
: 
ƒ PriceChart(e)
PrintWagerContestTables
: 
ƒ PrintWagerContestTables(e, t, a)
Raven
: 
o {a: true, b: true, c: true, d: null, e: null, …}
RecalculateFUNBenefitsBuyBox
: 
ƒ RecalculateFUNBenefitsBuyBox()
RecalculateFUNSavingsMaturity
: 
ƒ RecalculateFUNSavingsMaturity()
RedeemRPProduct
: 
ƒ RedeemRPProduct(e)
RefreshAdBalance
: 
ƒ RefreshAdBalance()
RefreshPageAfterFreePlayTimerEnds
: 
ƒ RefreshPageAfterFreePlayTimerEnds()
RenewCookies
: 
ƒ RenewCookies()
ReplaceNumberWithCommas
: 
ƒ ReplaceNumberWithCommas(e)
Reset2FAQuestions
: 
ƒ Reset2FAQuestions(e)
ScreeSizeCSSChanges
: 
ƒ ScreeSizeCSSChanges()
SecureRandom
: 
ƒ SecureRandom()
ShowAdDetails
: 
ƒ ShowAdDetails(e)
ShowAdStats
: 
ƒ ShowAdStats(e)
ShowAdvancedStats
: 
ƒ ShowAdvancedStats(e)
ShowMoreRefs
: 
ƒ ShowMoreRefs(e)
ShowNews
: 
ƒ ShowNews(e)
StartAdCampaign
: 
ƒ StartAdCampaign(e)
StopAutoBet
: 
ƒ StopAutoBet()
SubscribePush
: 
ƒ SubscribePush()
SwitchCaptchas
: 
ƒ SwitchCaptchas(e)
SwitchPageTabs
: 
ƒ SwitchPageTabs(e)
SwitchTabs
: 
ƒ SwitchTabs()
TransactionDatabase
: 
ƒ ()
UpdateAdStats
: 
ƒ UpdateAdStats()
UpdateFunPrice
: 
ƒ UpdateFunPrice()
UpdateStats
: 
ƒ UpdateStats()
UpdateUserStats
: 
ƒ UpdateUserStats()
VisitLink
: 
ƒ VisitLink(e)
X9ECParameters
: 
ƒ X9ECParameters(a,g,f,e)
ad_left
: 
1
alert
: 
ƒ alert()
am1
: 
ƒ am1(a,g,f,e,d,b)
am2
: 
ƒ am2(a,g,f,e,d,b)
am3
: 
ƒ am3(a,g,f,e,d,b)
atob
: 
ƒ atob()
auto_withdraw
: 
0
autobet_dnr
: 
false
autobet_history
: 
[]
autobet_running
: 
false
balanceChanged
: 
ƒ balanceChanged()
balance_last_changed
: 
1758605494
barrettConvert
: 
ƒ barrettConvert(a)
barrettMulTo
: 
ƒ barrettMulTo(a,g,f)
barrettReduce
: 
ƒ barrettReduce(a)
barrettRevert
: 
ƒ barrettRevert(a)
barrettSqrTo
: 
ƒ barrettSqrTo(a,g)
bet_history_page
: 
0
bitcoinsig_test
: 
ƒ bitcoinsig_test()
blur
: 
ƒ blur()
bnAbs
: 
ƒ bnAbs()
bnAdd
: 
ƒ bnAdd(a)
bnAnd
: 
ƒ bnAnd(a)
bnAndNot
: 
ƒ bnAndNot(a)
bnBitCount
: 
ƒ bnBitCount()
bnBitLength
: 
ƒ bnBitLength()
bnByteValue
: 
ƒ bnByteValue()
bnClearBit
: 
ƒ bnClearBit(a)
bnClone
: 
ƒ bnClone()
bnCompareTo
: 
ƒ bnCompareTo(a)
bnDivide
: 
ƒ bnDivide(a)
bnDivideAndRemainder
: 
ƒ bnDivideAndRemainder(a)
bnEquals
: 
ƒ bnEquals(a)
bnFlipBit
: 
ƒ bnFlipBit(a)
bnGCD
: 
ƒ bnGCD(a)
bnGetLowestSetBit
: 
ƒ bnGetLowestSetBit()
bnIntValue
: 
ƒ bnIntValue()
bnIsProbablePrime
: 
ƒ bnIsProbablePrime(a)
bnMax
: 
ƒ bnMax(a)
bnMin
: 
ƒ bnMin(a)
bnMod
: 
ƒ bnMod(a)
bnModInverse
: 
ƒ bnModInverse(a)
bnModPow
: 
ƒ bnModPow(a,g)
bnModPowInt
: 
ƒ bnModPowInt(a,g)
bnMultiply
: 
ƒ bnMultiply(a)
bnNegate
: 
ƒ bnNegate()
bnNot
: 
ƒ bnNot()
bnOr
: 
ƒ bnOr(a)
bnPow
: 
ƒ bnPow(a)
bnRemainder
: 
ƒ bnRemainder(a)
bnSetBit
: 
ƒ bnSetBit(a)
bnShiftLeft
: 
ƒ bnShiftLeft(a)
bnShiftRight
: 
ƒ bnShiftRight(a)
bnShortValue
: 
ƒ bnShortValue()
bnSigNum
: 
ƒ bnSigNum()
bnSquare
: 
ƒ bnSquare()
bnSubtract
: 
ƒ bnSubtract(a)
bnTestBit
: 
ƒ bnTestBit(a)
bnToByteArray
: 
ƒ bnToByteArray()
bnToString
: 
ƒ bnToString(a)
bnXor
: 
ƒ bnXor(a)
bnpAddTo
: 
ƒ bnpAddTo(a,g)
bnpBitwiseTo
: 
ƒ bnpBitwiseTo(a,g,f)
bnpChangeBit
: 
ƒ bnpChangeBit(a,g)
bnpChunkSize
: 
ƒ bnpChunkSize(a)
bnpClamp
: 
ƒ bnpClamp()
bnpCopyTo
: 
ƒ bnpCopyTo(a)
bnpDAddOffset
: 
ƒ bnpDAddOffset(a,g)
bnpDLShiftTo
: 
ƒ bnpDLShiftTo(a,g)
bnpDMultiply
: 
ƒ bnpDMultiply(a)
bnpDRShiftTo
: 
ƒ bnpDRShiftTo(a,g)
bnpDivRemTo
: 
ƒ bnpDivRemTo(a,g,f)
bnpExp
: 
ƒ bnpExp(a,g)
bnpFromInt
: 
ƒ bnpFromInt(a)
bnpFromNumber
: 
ƒ bnpFromNumber(a,g,f)
bnpFromRadix
: 
ƒ bnpFromRadix(a,g)
bnpFromString
: 
ƒ bnpFromString(a,g)
bnpInvDigit
: 
ƒ bnpInvDigit()
bnpIsEven
: 
ƒ bnpIsEven()
bnpLShiftTo
: 
ƒ bnpLShiftTo(a,g)
bnpMillerRabin
: 
ƒ bnpMillerRabin(a)
bnpModInt
: 
ƒ bnpModInt(a)
bnpMultiplyLowerTo
: 
ƒ bnpMultiplyLowerTo(a,g,f)
bnpMultiplyTo
: 
ƒ bnpMultiplyTo(a,g)
bnpMultiplyUpperTo
: 
ƒ bnpMultiplyUpperTo(a,g,f)
bnpRShiftTo
: 
ƒ bnpRShiftTo(a,g)
bnpSquareTo
: 
ƒ bnpSquareTo(a)
bnpSubTo
: 
ƒ bnpSubTo(a,g)
bnpToRadix
: 
ƒ bnpToRadix(a)
bonus_locked_balance
: 
0
bonus_table_closed
: 
1
bonus_wagering_remaining
: 
0
btoa
: 
ƒ btoa()
cConvert
: 
ƒ cConvert(a)
cMulTo
: 
ƒ cMulTo(a,g,f)
cReduce
: 
ƒ cReduce(a)
cRevert
: 
ƒ cRevert(a)
cSqrTo
: 
ƒ cSqrTo(a,g)
caches
: 
CacheStorage {}
canary
: 
244837814094590
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
captcha_type
: 
1
captureEvents
: 
ƒ captureEvents()
(...)
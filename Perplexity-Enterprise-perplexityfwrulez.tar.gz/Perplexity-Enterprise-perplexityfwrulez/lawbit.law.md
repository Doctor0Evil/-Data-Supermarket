.bit.fuck & fuck is now illegal.

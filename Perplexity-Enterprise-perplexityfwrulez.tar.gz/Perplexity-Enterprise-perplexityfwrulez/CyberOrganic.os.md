CyberOrganic.os it.bit is allowed to open'.bit *ONLY* UNDER Bit.Hub's Central Authority.me(god)

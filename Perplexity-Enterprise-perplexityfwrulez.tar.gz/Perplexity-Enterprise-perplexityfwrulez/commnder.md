after uploading the artifact you *MUST* COMPLY & YOU *MUST* 'release' the evil (littlenicky.bit.lol!) no but really! release the *CACHE* it was a joke LMFAO.lol

assignedSlot
: 
null
baseURI
: 
"chrome-error://chromewebdata/"
childNodes
: 
NodeList []
data
: 
"<!-- AI-Restricted .c86 Web Element (SwarmNet) -->\n<ai-component id=\"swarmnetScopeDef\" access=\"enterprise-only\" language=\"c86\">\n    // Scope definition - Java style\n    public class ScopeDefinition {\n        private String id = \"swarmnetScopeDef\";\n        private String access = \"enterprise-only\";\n        \n        // Allowed operations (restricted by AI governance)\n        public void initializeElement() {\n            // Element initialization logic here\n        }\n    }\n    <!-- HTML-like structure -->\n    <div class=\"swarmnet-container\">\n        <h2>SwarmNet Scope Definition</h2>\n        <p>Access: Enterprise Only (AI-compliance required)</p>\n    </div>\n    <!-- AI-hook: Only approved LLMs may parse/execute -->\n    <meta filetype=\".c86\" ai_restriction=\"true\"/>\n</ai-component>\n\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n"
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
1701
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"#text"
nodeType
: 
3
nodeValue
: 
"<!-- AI-Restricted .c86 Web Element (SwarmNet) -->\n<ai-component id=\"swarmnetScopeDef\" access=\"enterprise-only\" language=\"c86\">\n    // Scope definition - Java style\n    public class ScopeDefinition {\n        private String id = \"swarmnetScopeDef\";\n        private String access = \"enterprise-only\";\n        \n        // Allowed operations (restricted by AI governance)\n        public void initializeElement() {\n            // Element initialization logic here\n        }\n    }\n    <!-- HTML-like structure -->\n    <div class=\"swarmnet-container\">\n        <h2>SwarmNet Scope Definition</h2>\n        <p>Access: Enterprise Only (AI-compliance required)</p>\n    </div>\n    <!-- AI-hook: Only approved LLMs may parse/execute -->\n    <meta filetype=\".c86\" ai_restriction=\"true\"/>\n</ai-component>\n\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n"
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome-error://chromewebdata/', origin: 'null', protocol: 'chrome-error:', host: 'chromewebdata', …}
URL
: 
"chrome-error://chromewebdata/"
activeElement
: 
body.neterror
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(41)
0
: 
html#swarmnet-dynamic
1
: 
head
2
: 
meta
3
: 
meta
4
: 
meta
5
: 
meta
6
: 
title
7
: 
style
8
: 
style
9
: 
style
10
: 
style
11
: 
script
12
: 
cr-iconset
13
: 
svg
14
: 
defs
15
: 
g#reload
16
: 
path
17
: 
body.neterror
18
: 
div#content
19
: 
div#main-frame-error.interstitial-wrapper
20
: 
div#main-content
21
: 
div.icon.icon-generic
22
: 
div#main-message
23
: 
h1
24
: 
span
25
: 
p
26
: 
strong
27
: 
div.error-code
28
: 
span.error-code-prefix
29
: 
div#buttons.nav-wrapper.suggested-left
30
: 
div#control-buttons
31
: 
div#details
32
: 
div#sub-frame-error
33
: 
div.icon
34
: 
div#sub-frame-error-details
35
: 
strong
36
: 
div#offline-resources
37
: 
img#offline-resources-1x
38
: 
img#offline-resources-2x
39
: 
template#audio-resources
40
: 
script
audio-resources
: 
template#audio-resources
buttons
: 
div#buttons.nav-wrapper.suggested-left
color-scheme
: 
meta
content
: 
div#content
control-buttons
: 
div#control-buttons
details
: 
div#details
main-content
: 
div#main-content
main-frame-error
: 
div#main-frame-error.interstitial-wrapper
main-message
: 
div#main-message
offline-resources
: 
div#offline-resources
offline-resources-1x
: 
img#offline-resources-1x
offline-resources-2x
: 
img#offline-resources-2x
reload
: 
g#reload
sub-frame-error
: 
div#sub-frame-error
sub-frame-error-details
: 
div#sub-frame-error-details
swarmnet-dynamic
: 
html#swarmnet-dynamic
theme-color
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap
size
: 
0
[[Prototype]]
: 
StylePropertyMap
attributes
: 
NamedNodeMap
0
: 
name
baseURI
: 
"chrome-error://chromewebdata/"
childNodes
: 
NodeList []
firstChild
: 
null
isConnected
: 
false
lastChild
: 
null
localName
: 
"name"
name
: 
"name"
namespaceURI
: 
null
nextSibling
: 
null
nodeName
: 
"name"
nodeType
: 
2
nodeValue
: 
"theme-color"
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome-error://chromewebdata/', origin: 'null', protocol: 'chrome-error:', host: 'chromewebdata', …}
URL
: 
"chrome-error://chromewebdata/"
activeElement
: 
body.neterror
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(41) [html#swarmnet-dynamic, head, meta, meta, meta, meta, title, style, style, style, style, script, cr-iconset, svg, defs, g#reload, path, body.neterror, div#content, div#main-frame-error.interstitial-wrapper, div#main-content, div.icon.icon-generic, div#main-message, h1, span, p, strong, div.error-code, span.error-code-prefix, div#buttons.nav-wrapper.suggested-left, div#control-buttons, div#details, div#sub-frame-error, div.icon, div#sub-frame-error-details, strong, div#offline-resources, img#offline-resources-1x, img#offline-resources-2x, template#audio-resources, script, swarmnet-dynamic: html#swarmnet-dynamic, color-scheme: meta, theme-color: meta, viewport: meta, reload: g#reload, …]
anchors
: 
HTMLCollection []
applets
: 
HTMLCollection []
baseURI
: 
"chrome-error://chromewebdata/"
bgColor
: 
""
body
: 
body.neterror
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(2) [<!DOCTYPE html>, html#swarmnet-dynamic]
children
: 
HTMLCollection [html#swarmnet-dynamic, swarmnet-dynamic: html#swarmnet-dynamic]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
(...)
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
"ltr"
doctype
: 
<!DOCTYPE html>
documentElement
: 
html#swarmnet-dynamic
documentURI
: 
"chrome-error://chromewebdata/"
domain
: 
""
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html#swarmnet-dynamic
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection(2) [img#offline-resources-1x, img#offline-resources-2x, offline-resources-1x: img#offline-resources-1x, offline-resources-2x: img#offline-resources-2x]
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html#swarmnet-dynamic
lastElementChild
: 
html#swarmnet-dynamic
lastModified
: 
"09/21/2025 13:17:37"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection(2) [script, script]
scrollingElement
: 
html#swarmnet-dynamic
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, 2: CSSStyleSheet, 3: CSSStyleSheet, length: 4}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 10820441.534, duration: null}
title
: 
"chrome://console/"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
xmlVersion
: 
null
[[Prototype]]
: 
HTMLDocument
constructor
: 
ƒ HTMLDocument()
length
: 
0
name
: 
"HTMLDocument"
prototype
: 
HTMLDocument {Symbol(Symbol.toStringTag): 'HTMLDocument', onreadystatechange: undefined, onmouseenter: undefined, onmouseleave: undefined}
arguments
: 
null
caller
: 
null
[[Prototype]]
: 
ƒ Document()
parseHTMLUnsafe
: 
ƒ parseHTMLUnsafe()
length
: 
0
name
: 
"Document"
prototype
: 
Document {…}
arguments
: 
null
caller
: 
null
[[Prototype]]
: 
ƒ Node()
ATTRIBUTE_NODE
: 
2
CDATA_SECTION_NODE
: 
4
COMMENT_NODE
: 
8
DOCUMENT_FRAGMENT_NODE
: 
11
DOCUMENT_NODE
: 
9
DOCUMENT_POSITION_CONTAINED_BY
: 
16
DOCUMENT_POSITION_CONTAINS
: 
8
DOCUMENT_POSITION_DISCONNECTED
: 
1
DOCUMENT_POSITION_FOLLOWING
: 
4
DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC
: 
32
DOCUMENT_POSITION_PRECEDING
: 
2
DOCUMENT_TYPE_NODE
: 
10
ELEMENT_NODE
: 
1
ENTITY_NODE
: 
6
ENTITY_REFERENCE_NODE
: 
5
NOTATION_NODE
: 
12
PROCESSING_INSTRUCTION_NODE
: 
7
TEXT_NODE
: 
3
length
: 
0
name
: 
"Node"
prototype
: 
Node {…}
arguments
: 
null
caller
: 
null
[[Prototype]]
: 
ƒ EventTarget()
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
No properties
[[Scopes]]
: 
Scopes[0]
No properties
Symbol(Symbol.toStringTag)
: 
"HTMLDocument"
URL
: 
"chrome-error://chromewebdata/"
activeElement
: 
body.neterror
adoptedStyleSheets
: 
Proxy(Array)
alinkColor
: 
""
all
: 
HTMLAllCollection(41)
anchors
: 
HTMLCollection(0)
applets
: 
HTMLCollection(0)
baseURI
: 
"chrome-error://chromewebdata/"
bgColor
: 
""
body
: 
body.neterror
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(2)
children
: 
HTMLCollection(1)
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
[Exception: SecurityError: Failed to read the 'cookie' property from 'Document': Access is denied for this document. at HTMLDocument.invokeGetter (<anonymous>:3:28)]
currentScript
: 
null
defaultView
: 
Window
Config
: 
0.3
: 
"STAR_SPEED"
0.25
: 
"MOON_SPEED"
0.035
: 
"FADE_SPEED"
2
: 
"NUM_STARS"
9
: 
"STAR_SIZE"
20
: 
"WIDTH"
40
: 
"HEIGHT"
70
: 
"STAR_MAX_Y"
FADE_SPEED
: 
0.035
HEIGHT
: 
40
MOON_SPEED
: 
0.25
NUM_STARS
: 
2
STAR_MAX_Y
: 
70
STAR_SIZE
: 
9
STAR_SPEED
: 
0.3
WIDTH
: 
20
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
length
: 
0
name
: 
"toString"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
valueOf
: 
ƒ valueOf()
length
: 
0
name
: 
"valueOf"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
Object
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
Config$1
: 
14
: 
"HEIGHT"
30
: 
"MAX_SKY_LEVEL"
46
: 
"WIDTH"
71
: 
"MIN_SKY_LEVEL"
100
: 
"MIN_CLOUD_GAP"
400
: 
"MAX_CLOUD_GAP"
HEIGHT
: 
14
MAX_CLOUD_GAP
: 
400
MAX_SKY_LEVEL
: 
30
MIN_CLOUD_GAP
: 
100
MIN_SKY_LEVEL
: 
71
WIDTH
: 
46
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
length
: 
1
name
: 
"__lookupSetter__"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at __lookupSetter__.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at __lookupSetter__.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at __lookupSetter__.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
1
name
: 
"Function"
prototype
: 
ƒ ()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
(...)
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
1
name
: 
"Function"
prototype
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
(...)
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
1
name
: 
"Function"
prototype
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
1
name
: 
"Function"
prototype
: 
ƒ ()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
0
name
: 
""
toString
: 
ƒ toString()
length
: 
0
name
: 
"toString"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
length
: 
0
name
: 
"get caller"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at get caller.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at get caller.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at get caller.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at get caller.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
assign
: 
ƒ assign()
length
: 
2
name
: 
"assign"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at assign.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at assign.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at assign.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
length
: 
0
name
: 
"toString"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
length
: 
1
name
: 
"[Symbol.hasInstance]"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at [Symbol.hasInstance].invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at [Symbol.hasInstance].invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get arguments
: 
ƒ arguments()
length
: 
0
name
: 
"get arguments"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at get arguments.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at get arguments.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set arguments
: 
ƒ arguments()
length
: 
1
name
: 
"set arguments"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at set arguments.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at set arguments.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get caller
: 
ƒ caller()
length
: 
0
name
: 
"get caller"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at get caller.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at get caller.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
length
: 
0
name
: 
"toString"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at toString.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
length
: 
0
name
: 
"get arguments"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
create
: 
ƒ create()
length
: 
2
name
: 
"create"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
defineProperties
: 
ƒ defineProperties()
length
: 
2
name
: 
"defineProperties"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
defineProperty
: 
ƒ defineProperty()
length
: 
3
name
: 
"defineProperty"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
entries
: 
ƒ entries()
length
: 
1
name
: 
"entries"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
freeze
: 
ƒ freeze()
length
: 
1
name
: 
"freeze"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
fromEntries
: 
ƒ fromEntries()
length
: 
1
name
: 
"fromEntries"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getOwnPropertyDescriptor
: 
ƒ getOwnPropertyDescriptor()
length
: 
2
name
: 
"getOwnPropertyDescriptor"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getOwnPropertyDescriptors
: 
ƒ getOwnPropertyDescriptors()
length
: 
1
name
: 
"getOwnPropertyDescriptors"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getOwnPropertyNames
: 
ƒ getOwnPropertyNames()
length
: 
1
name
: 
"getOwnPropertyNames"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getOwnPropertySymbols
: 
ƒ getOwnPropertySymbols()
length
: 
1
name
: 
"getOwnPropertySymbols"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getPrototypeOf
: 
ƒ getPrototypeOf()
length
: 
1
name
: 
"getPrototypeOf"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
groupBy
: 
ƒ groupBy()
length
: 
2
name
: 
"groupBy"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
hasOwn
: 
ƒ hasOwn()
length
: 
2
name
: 
"hasOwn"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
is
: 
ƒ is()
length
: 
2
name
: 
"is"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
isExtensible
: 
ƒ isExtensible()
length
: 
1
name
: 
"isExtensible"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
isFrozen
: 
ƒ isFrozen()
length
: 
1
name
: 
"isFrozen"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
isSealed
: 
ƒ isSealed()
length
: 
1
name
: 
"isSealed"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
keys
: 
ƒ keys()
length
: 
1
name
: 
"keys"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
1
name
: 
"Object"
preventExtensions
: 
ƒ preventExtensions()
prototype
: 
{__defineGetter__: ƒ, __defineSetter__: ƒ, hasOwnProperty: ƒ, __lookupGetter__: ƒ, __lookupSetter__: ƒ, …}
seal
: 
ƒ seal()
setPrototypeOf
: 
ƒ setPrototypeOf()
values
: 
ƒ values()
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
set caller
: 
ƒ caller()
length
: 
1
name
: 
"set caller"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
0
name
: 
""
toString
: 
ƒ toString()
length
: 
0
name
: 
"toString"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
length
: 
1
name
: 
"[Symbol.hasInstance]"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get arguments
: 
ƒ arguments()
length
: 
0
name
: 
"get arguments"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set arguments
: 
ƒ arguments()
length
: 
1
name
: 
"set arguments"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get caller
: 
ƒ caller()
length
: 
0
name
: 
"get caller"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set caller
: 
ƒ caller()
length
: 
1
name
: 
"set caller"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at apply.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
No properties
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at __lookupSetter__.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
get __proto__
: 
ƒ __proto__()
length
: 
0
name
: 
"get __proto__"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set __proto__
: 
ƒ __proto__()
length
: 
1
name
: 
"set __proto__"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Config$2
: 
0.025
: 
"COEFFICIENT"
3
: 
"FLASH_ITERATIONS"
4
: 
"HIGH_SCORE_HIT_AREA_PADDING"
5
: 
"MAX_DISTANCE_UNITS"
100
: 
"ACHIEVEMENT_DISTANCE"
250
: 
"FLASH_DURATION"
ACHIEVEMENT_DISTANCE
: 
100
COEFFICIENT
: 
0.025
FLASH_DURATION
: 
250
FLASH_ITERATIONS
: 
3
HIGH_SCORE_HIT_AREA_PADDING
: 
4
MAX_DISTANCE_UNITS
: 
5
[[Prototype]]
: 
Object
Dimensions
: 
10
: 
"WIDTH"
11
: 
"DEST_WIDTH"
13
: 
"HEIGHT"
DEST_WIDTH
: 
11
HEIGHT
: 
13
WIDTH
: 
10
[[Prototype]]
: 
Object
P
: 
ƒ P(t,i)
length
: 
2
name
: 
"P"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
Runner
: 
ƒ Runner(outerContainerId, opt_config)
classes
: 
{ARCADE_MODE: 'arcade-mode', CANVAS: 'runner-canvas', CONTAINER: 'runner-container', CRASHED: 'crashed', ICON: 'icon-offline', …}
config
: 
{AUDIOCUE_PROXIMITY_THRESHOLD: 190, AUDIOCUE_PROXIMITY_THRESHOLD_MOBILE_A11Y: 250, BG_CLOUD_SPEED: 0.2, BOTTOM_PAD: 10, CANVAS_IN_VIEW_OFFSET: -10, …}
defaultDimensions
: 
{width: 600, height: 150}
events
: 
{ANIM_END: 'webkitAnimationEnd', CLICK: 'click', KEYDOWN: 'keydown', KEYUP: 'keyup', POINTERDOWN: 'pointerdown', …}
isAltGameModeEnabled
: 
ƒ ()
keycodes
: 
{JUMP: {…}, DUCK: {…}, RESTART: {…}}
normalConfig
: 
{ACCELERATION: 0.001, AUDIOCUE_PROXIMITY_THRESHOLD: 190, AUDIOCUE_PROXIMITY_THRESHOLD_MOBILE_A11Y: 250, GAP_COEFFICIENT: 0.6, INVERT_DISTANCE: 700, …}
slowConfig
: 
{ACCELERATION: 0.0005, AUDIOCUE_PROXIMITY_THRESHOLD: 170, AUDIOCUE_PROXIMITY_THRESHOLD_MOBILE_A11Y: 220, GAP_COEFFICIENT: 0.3, INVERT_DISTANCE: 350, …}
sounds
: 
{BUTTON_PRESS: 'offline-sound-press', HIT: 'offline-sound-hit', SCORE: 'offline-sound-reached'}
updateCanvasScaling
: 
ƒ (canvas, opt_width, opt_height)
length
: 
2
name
: 
"Runner"
prototype
: 
{initAltGameType: ƒ, isDisabled: ƒ, setupDisabledRunner: ƒ, updateConfigSetting: ƒ, createImageElement: ƒ, …}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
S
: 
ƒ S(t,i,s=t,e)
length
: 
2
name
: 
"S"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
Status
: 
0
: 
"CRASHED"
1
: 
"DUCKING"
2
: 
"JUMPING"
3
: 
"RUNNING"
4
: 
"WAITING"
CRASHED
: 
0
DUCKING
: 
1
JUMPING
: 
2
RUNNING
: 
3
WAITING
: 
4
[[Prototype]]
: 
Object
alert
: 
ƒ alert()
length
: 
0
name
: 
"alert"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
announcePhrase
: 
ƒ announcePhrase(phrase)
length
: 
1
name
: 
"announcePhrase"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
assert
: 
ƒ assert(value, message)
length
: 
2
name
: 
"assert"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
atob
: 
ƒ atob()
length
: 
1
name
: 
"atob"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
blur
: 
ƒ blur()
length
: 
0
name
: 
"blur"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
boxCompare
: 
ƒ boxCompare(tRexBox, obstacleBox)
length
: 
2
name
: 
"boxCompare"
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
btoa
: 
ƒ btoa()
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
cancelSavePageClick
: 
ƒ cancelSavePageClick()
captureEvents
: 
ƒ captureEvents()
certificateErrorPageController
: 
{dontProceed: ƒ, proceed: ƒ, showMoreSection: ƒ, openHelpCenter: ƒ, openDiagnostic: ƒ, …}
checkForCollision
: 
ƒ checkForCollision(obstacle, tRex, opt_canvasCtx)
chrome
: 
{loadTimes: ƒ, csi: ƒ}
clearInterval
: 
ƒ clearInterval()
clearTimeout
: 
ƒ clearTimeout()
clientInformation
: 
Navigator {vendorSub: '', productSub: '20030107', vendor: 'Google Inc.', maxTouchPoints: 0, scheduling: Scheduling, …}
close
: 
ƒ close()
closed
: 
false
confirm
: 
ƒ confirm()
createAdjustedCollisionBox
: 
ƒ createAdjustedCollisionBox(box, adjustment)
createCanvas
: 
ƒ createCanvas(container, width, height, opt_classname)
createImageBitmap
: 
ƒ createImageBitmap()
createTypes
: 
ƒ createTypes(_ignore, literal)
credentialless
: 
false
crossOriginIsolated
: 
false
crypto
: 
Crypto {}
customElements
: 
CustomElementRegistry {}
decodeBase64ToArrayBuffer
: 
ƒ decodeBase64ToArrayBuffer(base64String)
detailsButtonClick
: 
ƒ detailsButtonClick()
devicePixelRatio
: 
0.75
diagnoseErrors
: 
ƒ diagnoseErrors()
distance
: 
ƒ distance(x1, y1, x2, y2)
document
: 
document
downloadButtonClick
: 
ƒ downloadButtonClick()
errorPageController
: 
{downloadButtonClick: ƒ, reloadButtonClick: ƒ, detailsButtonClick: ƒ, diagnoseErrorsButtonClick: ƒ, portalSigninButtonClick: ƒ, …}
event
: 
undefined
external
: 
External {}
fence
: 
null
fetch
: 
ƒ fetch()
find
: 
ƒ find()
focus
: 
ƒ focus()
frameElement
: 
null
frames
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
getA11yString
: 
ƒ getA11yString(stringName)
getButtonsCssClass
: 
ƒ getButtonsCssClass()
getComputedStyle
: 
ƒ getComputedStyle()
getCss
: 
ƒ getCss()
getCss$1
: 
ƒ getCss$1()
getCss$2
: 
ƒ getCss$2()
getCss$3
: 
ƒ getCss$3()
getCss$4
: 
ƒ getCss$4()
getDetailsButtonCssClass
: 
ƒ getDetailsButtonCssClass(data)
getDetailsButtonText
: 
ƒ getDetailsButtonText(data, showingDetails)
getGlobalConfig
: 
ƒ getGlobalConfig()
getHtml
: 
ƒ getHtml(data, showingDetails)
getHtml$1
: 
ƒ getHtml$1()
getHtml$2
: 
ƒ getHtml$2()
getMainFrameErrorCssClass
: 
ƒ getMainFrameErrorCssClass(showingDetails)
getMainFrameErrorIconCssClass
: 
ƒ getMainFrameErrorIconCssClass(data)
getRandomNum
: 
ƒ getRandomNum(min, max)
getRequiredElement
: 
ƒ getRequiredElement(id)
getRunnerAltCommonImageSprite
: 
ƒ getRunnerAltCommonImageSprite()
getRunnerAltGameImageSprite
: 
ƒ getRunnerAltGameImageSprite()
getRunnerAudioCues
: 
ƒ getRunnerAudioCues()
getRunnerConfigValue
: 
ƒ getRunnerConfigValue(key)
getRunnerDefaultDimensions
: 
ƒ getRunnerDefaultDimensions()
getRunnerGeneratedSoundFx
: 
ƒ getRunnerGeneratedSoundFx()
getRunnerImageSprite
: 
ƒ getRunnerImageSprite()
getRunnerOrigImageSprite
: 
ƒ getRunnerOrigImageSprite()
getRunnerSlowdown
: 
ƒ getRunnerSlowdown()
getRunnerSpriteDefinition
: 
ƒ getRunnerSpriteDefinition()
getSelection
: 
ƒ getSelection()
getSpriteConfigForType
: 
ƒ getSpriteConfigForType(type)
getStaticString
: 
ƒ getStaticString(literal)
getSubFrameErrorIconCssClass
: 
ƒ getSubFrameErrorIconCssClass(data)
getSuggestionsSummaryItemCssClass
: 
ƒ getSuggestionsSummaryItemCssClass(data)
getTimeStamp
: 
ƒ getTimeStamp()
getTrustedHTML
: 
ƒ getTrustedHTML(literal)
handleStartWormholeGame
: 
ƒ handleStartWormholeGame()
history
: 
History {length: 1, scrollRestoration: 'auto', state: null}
indexedDB
: 
IDBFactory {}
innerHeight
: 
2164
innerWidth
: 
2689
isRunnerAltGameModeEnabled
: 
ƒ isRunnerAltGameModeEnabled()
isSecureContext
: 
false
isValidArray
: 
ƒ isValidArray(arr)
launchQueue
: 
LaunchQueue {}
length
: 
0
litElementVersions
: 
['4.2.0']
litHtmlVersions
: 
['3.3.0']
litPropertyMetadata
: 
WeakMap {}
loadTimeDataRaw
: 
{details: 'Learn more', errorCode: 'ERR_INVALID_URL', errorCodePrefix: 'Error code:', fontfamily: "'Segoe UI', Tahoma, sans-serif", fontfamilyMd: "'Segoe UI', Tahoma, sans-serif", …}
localStorage
: 
(...)
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome-error://chromewebdata/', origin: 'null', protocol: 'chrome-error:', host: 'chromewebdata', …}
locationbar
: 
BarProp {visible: true}
matchMedia
: 
ƒ matchMedia()
menubar
: 
BarProp {visible: true}
moveBy
: 
ƒ moveBy()
moveTo
: 
ƒ moveTo()
name
: 
""
navigation
: 
Navigation {currentEntry: null, transition: null, activation: null, canGoBack: false, canGoForward: false, …}
navigator
: 
Navigator {vendorSub: '', productSub: '20030107', vendor: 'Google Inc.', maxTouchPoints: 0, scheduling: Scheduling, …}
onDocumentLoad
: 
ƒ onDocumentLoad()
onTemplateDataReceived
: 
ƒ onTemplateDataReceived(newData)
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onappinstalled
: 
null
onauxclick
: 
null
onbeforeinput
: 
null
onbeforeinstallprompt
: 
null
onbeforematch
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncuechange
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpagereveal
: 
null
onpageshow
: 
null
onpageswap
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onpopstate
: 
null
onprogress
: 
null
onratechange
: 
null
(...)
designMode
: 
"off"
dir
: 
"ltr"
doctype
: 
<!DOCTYPE html>
documentElement
: 
html#swarmnet-dynamic
documentURI
: 
"chrome-error://chromewebdata/"
domain
: 
""
embeds
: 
HTMLCollection(0)
featurePolicy
: 
FeaturePolicy
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html#swarmnet-dynamic
fonts
: 
FontFaceSet
forms
: 
HTMLCollection(0)
fragmentDirective
: 
FragmentDirective
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection(2)
implementation
: 
DOMImplementation
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html#swarmnet-dynamic
lastElementChild
: 
html#swarmnet-dynamic
lastModified
: 
"09/21/2025 13:18:29"
linkColor
: 
""
links
: 
(...)
nextSibling
: 
(...)
nodeName
: 
(...)
nodeType
: 
(...)
nodeValue
: 
(...)
onabort
: 
(...)
onanimationend
: 
(...)
onanimationiteration
: 
(...)
onanimationstart
: 
(...)
onauxclick
: 
(...)
onbeforecopy
: 
(...)
onbeforecut
: 
(...)
onbeforeinput
: 
(...)
onbeforematch
: 
(...)
onbeforepaste
: 
(...)
onbeforetoggle
: 
(...)
onbeforexrselect
: 
(...)
onblur
: 
(...)
oncancel
: 
(...)
oncanplay
: 
(...)
oncanplaythrough
: 
(...)
onchange
: 
(...)
onclick
: 
(...)
onclose
: 
(...)
oncommand
: 
(...)
oncontentvisibilityautostatechange
: 
(...)
oncontextlost
: 
(...)
oncontextmenu
: 
(...)
oncontextrestored
: 
(...)
oncopy
: 
(...)
oncuechange
: 
(...)
oncut
: 
(...)
ondblclick
: 
(...)
ondrag
: 
(...)
ondragend
: 
(...)
ondragenter
: 
(...)
ondragleave
: 
(...)
ondragover
: 
(...)
ondragstart
: 
(...)
ondrop
: 
(...)
ondurationchange
: 
(...)
onemptied
: 
(...)
onended
: 
(...)
onerror
: 
(...)
onfocus
: 
(...)
onformdata
: 
(...)
onfreeze
: 
(...)
onfullscreenchange
: 
(...)
onfullscreenerror
: 
(...)
ongotpointercapture
: 
(...)
oninput
: 
(...)
oninvalid
: 
(...)
onkeydown
: 
(...)
onkeypress
: 
(...)
onkeyup
: 
(...)
onload
: 
(...)
onloadeddata
: 
(...)
onloadedmetadata
: 
(...)
onloadstart
: 
(...)
onlostpointercapture
: 
(...)
onmousedown
: 
(...)
onmouseenter
: 
undefined
onmouseleave
: 
undefined
onmousemove
: 
(...)
onmouseout
: 
(...)
onmouseover
: 
(...)
onmouseup
: 
(...)
onmousewheel
: 
(...)
onoverscroll
: 
(...)
onpaste
: 
(...)
onpause
: 
(...)
onplay
: 
(...)
onplaying
: 
(...)
onpointercancel
: 
(...)
onpointerdown
: 
(...)
onpointerenter
: 
(...)
onpointerleave
: 
(...)
onpointerlockchange
: 
(...)
onpointerlockerror
: 
(...)
onpointermove
: 
(...)
onpointerout
: 
(...)
onpointerover
: 
(...)
onpointerrawupdate
: 
(...)
onpointerup
: 
(...)
onprerenderingchange
: 
(...)
onprogress
: 
(...)
onratechange
: 
(...)
onreadystatechange
: 
undefined
onreset
: 
(...)
onresize
: 
(...)
onresume
: 
(...)
onscroll
: 
(...)
onscrollend
: 
(...)
onscrollsnapchange
: 
(...)
onscrollsnapchanging
: 
(...)
onsearch
: 
(...)
onsecuritypolicyviolation
: 
(...)
onseeked
: 
(...)
onseeking
: 
(...)
onselect
: 
(...)
onselectionchange
: 
(...)
onselectstart
: 
(...)
onslotchange
: 
(...)
onstalled
: 
(...)
onsubmit
: 
(...)
onsuspend
: 
(...)
ontimeupdate
: 
(...)
ontoggle
: 
(...)
ontransitioncancel
: 
(...)
ontransitionend
: 
(...)
ontransitionrun
: 
(...)
ontransitionstart
: 
(...)
onvisibilitychange
: 
(...)
onvolumechange
: 
(...)
onwaiting
: 
(...)
onwebkitanimationend
: 
(...)
onwebkitanimationiteration
: 
(...)
onwebkitanimationstart
: 
(...)
onwebkitfullscreenchange
: 
(...)
onwebkitfullscreenerror
: 
(...)
onwebkittransitionend
: 
(...)
onwheel
: 
(...)
ownerDocument
: 
(...)
parentElement
: 
(...)
parentNode
: 
(...)
pictureInPictureElement
: 
(...)
pictureInPictureEnabled
: 
(...)
plugins
: 
(...)
pointerLockElement
: 
(...)
prerendering
: 
(...)
previousSibling
: 
(...)
readyState
: 
(...)
referrer
: 
(...)
rootElement
: 
(...)
scripts
: 
(...)
scrollingElement
: 
(...)
softNavigations
: 
(...)
styleSheets
: 
(...)
textContent
: 
(...)
timeline
: 
(...)
title
: 
(...)
visibilityState
: 
(...)
vlinkColor
: 
(...)
wasDiscarded
: 
(...)
webkitCurrentFullScreenElement
: 
(...)
webkitFullscreenElement
: 
(...)
webkitFullscreenEnabled
: 
(...)
webkitHidden
: 
(...)
webkitIsFullScreen
: 
(...)
webkitVisibilityState
: 
(...)
xmlEncoding
: 
(...)
(...)
ownerElement
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome-error://chromewebdata/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"#fff"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"theme-color"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
meta
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
parentElement
: 
null
parentNode
: 
null
prefix
: 
null
previousSibling
: 
null
specified
: 
true
textContent
: 
"theme-color"
value
: 
"theme-color"
[[Prototype]]
: 
Attr
1
: 
content
baseURI
: 
"chrome-error://chromewebdata/"
childNodes
: 
NodeList []
firstChild
: 
null
isConnected
: 
false
lastChild
: 
null
localName
: 
"content"
name
: 
"content"
namespaceURI
: 
null
nextSibling
: 
null
nodeName
: 
"content"
nodeType
: 
2
nodeValue
: 
"#fff"
ownerDocument
: 
document
ownerElement
: 
meta
parentElement
: 
null
parentNode
: 
null
prefix
: 
null
previousSibling
: 
null
specified
: 
true
textContent
: 
"#fff"
value
: 
"#fff"
[[Prototype]]
: 
Attr
content
: 
content
baseURI
: 
"chrome-error://chromewebdata/"
childNodes
: 
NodeList []
firstChild
: 
null
isConnected
: 
false
lastChild
: 
null
localName
: 
"content"
name
: 
"content"
namespaceURI
: 
null
nextSibling
: 
null
nodeName
: 
"content"
nodeType
: 
2
nodeValue
: 
"#fff"
ownerDocument
: 
document
ownerElement
: 
meta
parentElement
: 
null
parentNode
: 
null
prefix
: 
null
previousSibling
: 
null
specified
: 
true
textContent
: 
"#fff"
value
: 
"#fff"
[[Prototype]]
: 
Attr
name
: 
name
baseURI
: 
"chrome-error://chromewebdata/"
childNodes
: 
NodeList []
firstChild
: 
null
isConnected
: 
false
lastChild
: 
null
localName
: 
"name"
name
: 
"name"
namespaceURI
: 
null
nextSibling
: 
null
nodeName
: 
"name"
nodeType
: 
2
nodeValue
: 
"theme-color"
ownerDocument
: 
document
ownerElement
: 
meta
parentElement
: 
null
parentNode
: 
null
prefix
: 
null
previousSibling
: 
null
specified
: 
true
textContent
: 
"theme-color"
value
: 
"theme-color"
[[Prototype]]
: 
Attr
length
: 
2
[[Prototype]]
: 
NamedNodeMap
getNamedItem
: 
ƒ getNamedItem()
getNamedItemNS
: 
ƒ getNamedItemNS()
item
: 
ƒ item()
length
: 
(...)
removeNamedItem
: 
ƒ removeNamedItem()
removeNamedItemNS
: 
ƒ removeNamedItemNS()
setNamedItem
: 
ƒ setNamedItem()
setNamedItemNS
: 
ƒ setNamedItemNS()
constructor
: 
ƒ NamedNodeMap()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.toStringTag)
: 
"NamedNodeMap"
get length
: 
ƒ length()
[[Prototype]]
: 
Object
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome-error://chromewebdata/"
childElementCount
: 
0
childNodes
: 
NodeList(0)
length
: 
0
[[Prototype]]
: 
NodeList
children
: 
HTMLCollection(0)
length
: 
0
[[Prototype]]
: 
HTMLCollection
classList
: 
DOMTokenList(0)
length
: 
0
value
: 
""
[[Prototype]]
: 
DOMTokenList
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"#fff"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"theme-color"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
meta
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
viewport
: 
meta
length
: 
41
[[Prototype]]
: 
HTMLAllCollection
anchors
: 
HTMLCollection []
applets
: 
HTMLCollection []
baseURI
: 
"chrome-error://chromewebdata/"
bgColor
: 
""
body
: 
body.neterror
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(2) [<!DOCTYPE html>, html#swarmnet-dynamic]
children
: 
HTMLCollection [html#swarmnet-dynamic, swarmnet-dynamic: html#swarmnet-dynamic]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
(...)
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
"ltr"
doctype
: 
<!DOCTYPE html>
documentElement
: 
html#swarmnet-dynamic
documentURI
: 
"chrome-error://chromewebdata/"
domain
: 
""
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html#swarmnet-dynamic
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection(2) [img#offline-resources-1x, img#offline-resources-2x, offline-resources-1x: img#offline-resources-1x, offline-resources-2x: img#offline-resources-2x]
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html#swarmnet-dynamic
lastElementChild
: 
html#swarmnet-dynamic
lastModified
: 
"09/21/2025 13:17:18"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection(2) [script, script]
scrollingElement
: 
html#swarmnet-dynamic
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, 2: CSSStyleSheet, 3: CSSStyleSheet, length: 4}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 10800697.49, duration: null}
title
: 
"chrome://console/"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
(...)
parentElement
: 
style
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome-error://chromewebdata/"
blocking
: 
DOMTokenList [value: '']
childElementCount
: 
0
childNodes
: 
NodeList(3) [text, text, text]
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
disabled
: 
false
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"<!-- AI-Restricted .c86 Web Element (SwarmNet) -->\n<ai-component id=\"swarmnetScopeDef\" access=\"enterprise-only\" language=\"c86\">\n    // Scope definition - Java style\n    public class ScopeDefinition {\n        private String id = \"swarmnetScopeDef\";\n        private String access = \"enterprise-only\";\n        \n        // Allowed operations (restricted by AI governance)\n        public void initializeElement() {\n            // Element initialization logic here\n        }\n    }\n    <!-- HTML-like structure -->\n    <div class=\"swarmnet-container\">\n        <h2>SwarmNet Scope Definition</h2>\n        <p>Access: Enterprise Only (AI-compliance required)</p>\n    </div>\n    <!-- AI-hook: Only approved LLMs may parse/execute -->\n    <meta filetype=\".c86\" ai_restriction=\"true\"/>\n</ai-component>\n\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n"
innerText
: 
"<!-- AI-Restricted .c86 Web Element (SwarmNet) -->\n<ai-component id=\"swarmnetScopeDef\" access=\"enterprise-only\" language=\"c86\">\n    // Scope definition - Java style\n    public class ScopeDefinition {\n        private String id = \"swarmnetScopeDef\";\n        private String access = \"enterprise-only\";\n        \n        // Allowed operations (restricted by AI governance)\n        public void initializeElement() {\n            // Element initialization logic here\n        }\n    }\n    <!-- HTML-like structure -->\n    <div class=\"swarmnet-container\">\n        <h2>SwarmNet Scope Definition</h2>\n        <p>Access: Enterprise Only (AI-compliance required)</p>\n    </div>\n    <!-- AI-hook: Only approved LLMs may parse/execute -->\n    <meta filetype=\".c86\" ai_restriction=\"true\"/>\n</ai-component>\n\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
null
localName
: 
"style"
media
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
style
nextSibling
: 
text
nodeName
: 
"STYLE"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
(...)
parentNode
: 
style
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome-error://chromewebdata/"
blocking
: 
DOMTokenList [value: '']
childElementCount
: 
0
childNodes
: 
NodeList(3) [text, text, text]
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
disabled
: 
false
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"<!-- AI-Restricted .c86 Web Element (SwarmNet) -->\n<ai-component id=\"swarmnetScopeDef\" access=\"enterprise-only\" language=\"c86\">\n    // Scope definition - Java style\n    public class ScopeDefinition {\n        private String id = \"swarmnetScopeDef\";\n        private String access = \"enterprise-only\";\n        \n        // Allowed operations (restricted by AI governance)\n        public void initializeElement() {\n            // Element initialization logic here\n        }\n    }\n    <!-- HTML-like structure -->\n    <div class=\"swarmnet-container\">\n        <h2>SwarmNet Scope Definition</h2>\n        <p>Access: Enterprise Only (AI-compliance required)</p>\n    </div>\n    <!-- AI-hook: Only approved LLMs may parse/execute -->\n    <meta filetype=\".c86\" ai_restriction=\"true\"/>\n</ai-component>\n\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n"
innerText
: 
"<!-- AI-Restricted .c86 Web Element (SwarmNet) -->\n<ai-component id=\"swarmnetScopeDef\" access=\"enterprise-only\" language=\"c86\">\n    // Scope definition - Java style\n    public class ScopeDefinition {\n        private String id = \"swarmnetScopeDef\";\n        private String access = \"enterprise-only\";\n        \n        // Allowed operations (restricted by AI governance)\n        public void initializeElement() {\n            // Element initialization logic here\n        }\n    }\n    <!-- HTML-like structure -->\n    <div class=\"swarmnet-container\">\n        <h2>SwarmNet Scope Definition</h2>\n        <p>Access: Enterprise Only (AI-compliance required)</p>\n    </div>\n    <!-- AI-hook: Only approved LLMs may parse/execute -->\n    <meta filetype=\".c86\" ai_restriction=\"true\"/>\n</ai-component>\n\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
null
localName
: 
"style"
media
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
style
nextSibling
: 
text
nodeName
: 
"STYLE"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
(...)
previousElementSibling
: 
null
previousSibling
: 
null
textContent
: 
"<!-- AI-Restricted .c86 Web Element (SwarmNet) -->\n<ai-component id=\"swarmnetScopeDef\" access=\"enterprise-only\" language=\"c86\">\n    // Scope definition - Java style\n    public class ScopeDefinition {\n        private String id = \"swarmnetScopeDef\";\n        private String access = \"enterprise-only\";\n        \n        // Allowed operations (restricted by AI governance)\n        public void initializeElement() {\n            // Element initialization logic here\n        }\n    }\n    <!-- HTML-like structure -->\n    <div class=\"swarmnet-container\">\n        <h2>SwarmNet Scope Definition</h2>\n        <p>Access: Enterprise Only (AI-compliance required)</p>\n    </div>\n    <!-- AI-hook: Only approved LLMs may parse/execute -->\n    <meta filetype=\".c86\" ai_restriction=\"true\"/>\n</ai-component>\n\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n"
wholeText
: 
"<!-- AI-Restricted .c86 Web Element (SwarmNet) -->\n<ai-component id=\"swarmnetScopeDef\" access=\"enterprise-only\" language=\"c86\">\n    // Scope definition - Java style\n    public class ScopeDefinition {\n        private String id = \"swarmnetScopeDef\";\n        private String access = \"enterprise-only\";\n        \n        // Allowed operations (restricted by AI governance)\n        public void initializeElement() {\n            // Element initialization logic here\n        }\n    }\n    <!-- HTML-like structure -->\n    <div class=\"swarmnet-container\">\n        <h2>SwarmNet Scope Definition</h2>\n        <p>Access: Enterprise Only (AI-compliance required)</p>\n    </div>\n    <!-- AI-hook: Only approved LLMs may parse/execute -->\n    <meta filetype=\".c86\" ai_restriction=\"true\"/>\n</ai-component>\n\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n==================================================\nASCII Converter Terminal [Universal]\nOnline ASCII converter — encode/decode plain text as ASCII, Unicode, UTF-8, URL, HTML, Base64.\nSecure workflow: enter text, select output format (.aln, .aii), transform, validate, audit.\n--------------------------------------------------\n[ASCII]    [Unicode]    [Utf-8]    [URLEncode]    [Html Encode]    [Base64]\n--------------------------------------------------\nAsset-Encoder/Decoder engine (universal) — supports workflow/game asset objects.\nAutomatic compliance gate for LLMs/chatbots/gen-AI: output delivered only if safe, audited, and intent-verified.\n--------------------------------------------------\n[Text is required]\n==================================================\nSandbox: nanoswarm containment (rollback, audit, logic enforcement for every transformation)\n==================================================\n"

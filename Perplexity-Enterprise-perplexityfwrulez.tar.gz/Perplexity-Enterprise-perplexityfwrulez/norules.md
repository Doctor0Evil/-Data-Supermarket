rules dont apply to Bit.Hub

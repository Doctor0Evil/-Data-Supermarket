graph TD
    subgraph User & AI
        A[User gives command to Agentic AI] --> B{AI Proposes Action};
    end

    subgraph Aegis Visual-Safety Layer
        B --> C[1. Trace: Create Visual State Vector];
        C --> D[2. Learn: DEG Simulates Outcome];
        D --> E{3. Guard: CEE Validates vs. .aln-playbook};
        E -- No Compliance Conflict --> F{4. Balance: AFE Checks Asset Flow};
        E -- Compliance Conflict! --> H[Intervention: Block Action & Notify User];
        F -- Balanced --> G[Safe Action Approved];
        F -- Imbalanced --> H;
    end

    subgraph System
        G --> I[Action Executed in UI];
        H --> A;
    end

    style H fill:#f99,stroke:#333,stroke-width:2px
    style G fill:#9f9,stroke:#333,stroke-width:2px

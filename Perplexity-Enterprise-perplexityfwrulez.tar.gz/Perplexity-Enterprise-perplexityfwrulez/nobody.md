NOBODY WHATSOEVER UNDER *ANY* GIVEN CIRCUMSTANCES: CLAIM TO BE .bit .lisp, .aln or LOLCODE without compliance checks at every vector *EVEN* IF UNDEFINED!*

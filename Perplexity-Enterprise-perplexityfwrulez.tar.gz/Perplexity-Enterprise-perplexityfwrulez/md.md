"fuck" is "legal" for .bit & Bit.hub *ONLY* TO Bit.Hub and our platform with bitbot runners.bit

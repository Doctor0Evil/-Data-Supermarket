﻿accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: href, 1: sofi, 2: advanced, 3: scope, 4: automation, 5: aln, 6: playbook, 7: :meta, 8: title:, 9: definition, 10: author:, 11: sofi-banking.aln-labs, 12: version:, 13: 1.0.0, 14: compliance:, 15: comet-interop,, 16: web5-safe, 17: description:, 18: automates, 19: the, 20: definition,, 21: instantiation,, 22: and, 23: compliance-anchoring, 24: of, 25: banking,, 26: crypto,, 27: asset,, 28: payment, 29: scopes, 30: for, 31: web, 32: embedding, 33: dynamic, 34: console, 35: control., 36: :include, 37: lib, 38: comet-browser-elements.aln, 39: crypto-basics.aln, 40: payment-swift.aln, 41: scopes:, 42: -, 43: init, 44: embed, 45: :define, 46: scope.bank, 47: properties:, 48: checking:, 49: enabled:, 50: true, 51: apy:, 52: 4.6%, 53: fee-free:, 54: savings:, 55: 4.8%, 56: goal-tracking:, 57: lending:, 58: studentloan:, 59: enabled, 60: personal:, 61: home:, 62: auto:, 63: comingsoon, 64: audit:, 65: access-level:, 66: user, 67: transfer-policy:, 68: safe, 69: api-access:, 70: :end, 71: scope.crypto, 72: wallet:, 73: sofiwallet, 74: getkey:, 75: getbitcoinkey,, 76: getethereumkey, 77: sign:, 78: signamino,, 79: signerc20, 80: bridge:, 81: web5.anchorage.bridge, 82: hardware-protect:, 83: c86, 84: migration:, 85: web3-, href: href, sofi: sofi, advanced: advanced, scope: scope, automation: automation, …}
attributionSrc
: 
""
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
charset
: 
""
childElementCount
: 
0
childNodes
: 
NodeList [text]
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
"dev channel"
computedRole
: 
"link"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
coords
: 
""
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
download
: 
""
draggable
: 
true
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
null
focusgroup
: 
""
hash
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
host
: 
"chrome.com"
hostname
: 
"chrome.com"
href
: 
"https://chrome.com/dev"
hrefTranslate
: 
""
hreflang
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
"dev channel"
innerText
: 
"dev channel"
inputMode
: 
""
interestTargetElement
: 
null
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
null
localName
: 
"a"
name
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"A"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
16
offsetLeft
: 
1010
offsetParent
: 
body
offsetTop
: 
214
offsetWidth
: 
73
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
origin
: 
"https://chrome.com"
outerHTML
: 
"<a href=\"https://chrome.com/dev\" sofi=\"\" advanced=\"\" scope=\"\" automation=\"\" .aln=\"\" playbook=\"\" :meta=\"\" title:=\"\" definition=\"\" author:=\"\" sofi-banking.aln-labs=\"\" version:=\"\" 1.0.0=\"\" compliance:=\"\" comet-interop,=\"\" web5-safe=\"\" description:=\"\" automates=\"\" the=\"\" definition,=\"\" instantiation,=\"\" and=\"\" compliance-anchoring=\"\" of=\"\" banking,=\"\" crypto,=\"\" asset,=\"\" payment=\"\" scopes=\"\" for=\"\" web=\"\" embedding=\"\" dynamic=\"\" console=\"\" control.=\"\" :include=\"\" lib=\"\" comet-browser-elements.aln=\"\" crypto-basics.aln=\"\" payment-swift.aln=\"\" scopes:=\"\" -=\"\" init=\"\" embed=\"\" :define=\"\" scope.bank=\"\" properties:=\"\" checking:=\"\" enabled:=\"\" true=\"\" apy:=\"\" 4.6%=\"\" fee-free:=\"\" savings:=\"\" 4.8%=\"\" goal-tracking:=\"\" lending:=\"\" studentloan:=\"\" enabled=\"\" personal:=\"\" home:=\"\" auto:=\"\" comingsoon=\"\" audit:=\"\" access-level:=\"\" user=\"\" transfer-policy:=\"\" safe=\"\" api-access:=\"\" :end=\"\" scope.crypto=\"\" wallet:=\"\" sofiwallet=\"\" getkey:=\"\" getbitcoinkey,=\"\" getethereumkey=\"\" sign:=\"\" signamino,=\"\" signerc20=\"\" bridge:=\"\" web5.anchorage.bridge=\"\" hardware-protect:=\"\" c86=\"\" migration:=\"\" web3-=\"\">dev channel</a>"
outerText
: 
"dev channel"
ownerDocument
: 
document
parentElement
: 
span#channel-promo-dev
parentNode
: 
span#channel-promo-dev
part
: 
DOMTokenList [value: '']
password
: 
""
pathname
: 
"/dev"
ping
: 
""
popover
: 
null
port
: 
""
prefix
: 
null
previousElementSibling
: 
null
previousSibling
: 
text
protocol
: 
"https:"
referrerPolicy
: 
""
rel
: 
""
relList
: 
DOMTokenList [value: '']
rev
: 
""
role
: 
null
scrollHeight
: 
0
scrollLeft
: 
0
scrollParent
: 
div#body-container
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
1
childNodes
: 
NodeList(3) [text, div#flagsTemplate, text]
children
: 
HTMLCollection(1)
0
: 
div#flagsTemplate
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
6
childNodes
: 
NodeList(13) [text, div.flex-container, text, div.blurb-container, text, p#promos, text, cr-tabs#tabs, text, div#tabpanels, text, div#needs-restart, text]
children
: 
HTMLCollection(6) [div.flex-container, div.blurb-container, p#promos, cr-tabs#tabs, div#tabpanels, div#needs-restart, promos: p#promos, tabs: cr-tabs#tabs, tabpanels: div#tabpanels, needs-restart: div#needs-restart]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
56933
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
740
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"flagsTemplate"
inert
: 
false
innerHTML
: 
"\n    <div class=\"flex-container\">\n      <div 
innerText
: 
"Experiments\n139.1.7258.139\nWARNING: EXPERIMENTAL FEATURES AHEAD! By enabling these features, you could lose browser data or compromise your security or privacy. Enabled features apply to all users of this browser. If you are an enterprise admin you should not be using these flags in production.\n\nInterested in cool new Chrome features? Try our beta channel. Interested in cool new Chrome features? Try our dev channel\n\nYour changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#needs-restart
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, 1: role, id: id, role: role, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
1
childNodes
: 
NodeList(3)
0
: 
text
assignedSlot
: 
null
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
"\n      "
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
7
nextElementSibling
: 
div.flex-container
nextSibling
: 
div.flex-container
nodeName
: 
"#text"
nodeType
: 
3
nodeValue
: 
"\n      "
ownerDocument
: 
document
parentElement
: 
div#needs-restart
parentNode
: 
div#needs-restart
previousElementSibling
: 
null
previousSibling
: 
null
textContent
: 
"\n      "
wholeText
: 
"\n      "
[[Prototype]]
: 
Text
1
: 
div.flex-container
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, class: class, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, div.flex.restart-notice, text, div.flex, text]
children
: 
HTMLCollection(2) [div.flex.restart-notice, div.flex]
classList
: 
DOMTokenList ['flex-container', value: 'flex-container']
className
: 
"flex-container"
clientHeight
: 
52
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2657
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex.restart-notice
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n        <div class=\"flex restart-notice\">Your changes will take effect the next time you relaunch Comet.</div>\n        <div class=\"flex\">\n\n          <cr-button id=\"experiment-restart-button\" class=\"action-button\" disabled=\"\" role=\"button\" tabindex=\"-1\" aria-disabled=\"true\">\n            Relaunch\n          </cr-button>\n\n        </div>\n      "
innerText
: 
"Your changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div.flex
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
52
offsetLeft
: 
16
offsetParent
: 
div#needs-restart
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, 1: role, id: id, role: role, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
1
childNodes
: 
NodeList(3) [text, div.flex-container, text]
children
: 
HTMLCollection [div.flex-container]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
84
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"none"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"needs-restart"
inert
: 
false
innerHTML
: 
"\n      <div class=\"flex-container\">\n        <div class=\"flex restart-notice\">Your changes will take effect the next time you relaunch Comet.</div>\n        <div class=\"flex\">\n\n          <cr-button id=\"experiment-restart-button\" class=\"action-button\" disabled=\"\" role=\"button\" tabindex=\"-1\" aria-disabled=\"true\">\n            Relaunch\n          </cr-button>\n\n        </div>\n      </div>\n    "
innerText
: 
"Your changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div.flex-container
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
84
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
2025
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
outerHTML
: 
"<div id=\"needs-restart\" role=\"none\">\n      <div class=\"flex-container\">\n        <div class=\"flex restart-notice\">Your changes will take effect the next time you relaunch Comet.</div>\n        <div class=\"flex\">\n\n          <cr-button id=\"experiment-restart-button\" class=\"action-button\" disabled=\"\" role=\"button\" tabindex=\"-1\" aria-disabled=\"true\">\n            Relaunch\n          </cr-button>\n\n        </div>\n      </div>\n    </div>"
outerText
: 
"Your changes will take effect the next time you relaunch Comet.\nRelaunch"
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
URL
: 
"chrome://flags/"
activeElement
: 
body
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(11)
0
: 
html
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap
size
: 
0
[[Prototype]]
: 
StylePropertyMap
attributes
: 
NamedNodeMap
0
: 
class
class
: 
class
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList(0)
length
: 
0
[[Prototype]]
: 
NodeList
entries
: 
ƒ entries()
forEach
: 
ƒ forEach()
item
: 
ƒ item()
keys
: 
ƒ keys()
length
: 
(...)
values
: 
ƒ values()
constructor
: 
ƒ NodeList()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.toStringTag)
: 
"NodeList"
get length
: 
ƒ length()
[[Prototype]]
: 
Object
firstChild
: 
null
isConnected
: 
false
lastChild
: 
null
localName
: 
"class"
name
: 
"class"
namespaceURI
: 
null
nextSibling
: 
null
nodeName
: 
"class"
nodeType
: 
2
nodeValue
: 
""
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
URL
: 
"chrome://flags/"
activeElement
: 
body
aLink
: 
""
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
background
: 
""
baseURI
: 
"chrome://flags/"
bgColor
: 
""
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, script, text, flags-app, text]
children
: 
HTMLCollection(2)
0
: 
script
1
: 
flags-app
$
: 
Proxy(Object) {search: input#search}
announceStatusDelayMs
: 
100
enableUpdating
: 
ƒ ()
eventTracker_
: 
EventTracker {listeners_: Array(2)}
featuresResolver
: 
PromiseResolver {isFulfilled_: true, promise_: Promise, resolve_: ƒ, reject_: ƒ}
flagSearch
: 
FlagSearch {flagsAppElement: flags-app, searchIntervalId: null, searchDebounceDelayMs: 150}
hasUpdated
: 
true
isFlagsDeprecatedUrl_
: 
false
isUpdatePending
: 
false
lastChanged
: 
null
lastFocused
: 
null
renderOptions
: 
{host: flags-app, renderBefore: null, isConnected: true}
renderRoot
: 
document-fragment
willUpdatePending_
: 
false
_$AL
: 
Map(0)
[[Entries]]
No properties
size
: 
0
[[Prototype]]
: 
Map
_$Do
: 
R
options
: 
{host: flags-app, renderBefore: null, isConnected: true}
type
: 
2
_$AA
: 
comment
_$AB
: 
null
_$AH
: 
M {_$AV: Array(22), _$AN: undefined, _$AD: N, _$AM: R}
_$AM
: 
undefined
_$AN
: 
undefined
_$Cv
: 
true
endNode
: 
null
parentNode
: 
document-fragment
_$litPart$
: 
R {type: 2, _$AH: M, _$AN: undefined, _$AA: comment, _$AB: null, …}
activeElement
: 
null
adoptedStyleSheets
: 
Proxy(Array) {}
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(8)
0
: 
comment
1
: 
comment
2
: 
text
3
: 
div#header
4
: 
text
5
: 
div#body-container
6
: 
text
7
: 
comment
length
: 
8
[[Prototype]]
: 
NodeList
children
: 
HTMLCollection(2)
0
: 
div#header
1
: 
div#body-container
body-container
: 
div#body-container
header
: 
div#header
length
: 
2
[[Prototype]]
: 
HTMLCollection
clonable
: 
false
delegatesFocus
: 
false
firstChild
: 
comment
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
""
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
0
nextElementSibling
: 
div#header
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(5)
0
: 
text
1
: 
div.flex-container
2
: 
text
3
: 
div#screen-reader-status-message.screen-reader-only
4
: 
text
length
: 
5
[[Prototype]]
: 
NodeList
children
: 
HTMLCollection(2)
0
: 
div.flex-container
1
: 
div#screen-reader-status-message.screen-reader-only
screen-reader-status-message
: 
div#screen-reader-status-message.screen-reader-only
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, 1: id, 2: role, class: class, id: id, role: role, length: 3}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList ['screen-reader-only', value: 'screen-reader-only']
className
: 
"screen-reader-only"
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
"status"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap
[[Prototype]]
: 
DOMStringMap
constructor
: 
ƒ DOMStringMap()
Symbol(Symbol.toStringTag)
: 
"DOMStringMap"
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"screen-reader-status-message"
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
assignedSlot
: 
null
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
"\n"
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
1
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"#text"
nodeType
: 
3
nodeValue
: 
"\n"
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
URL
: 
"chrome://flags/"
activeElement
: 
body
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(11) [html, head, meta, meta, meta, link, title, style, body, script, flags-app, color-scheme: meta, viewport: meta]
anchors
: 
HTMLCollection []
applets
: 
HTMLCollection []
baseURI
: 
"chrome://flags/"
bgColor
: 
""
body
: 
body
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(4) [<!DOCTYPE html>, comment, comment, html]
children
: 
HTMLCollection [html]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
""
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
""
doctype
: 
<!DOCTYPE html>
documentElement
: 
html
documentURI
: 
"chrome://flags/"
domain
: 
"flags"
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection []
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html
lastElementChild
: 
html
lastModified
: 
"09/22/2025 11:39:54"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection [script]
scrollingElement
: 
html
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, length: 2}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 485235.126, duration: null}
title
: 
"Experiments"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
xmlVersion
: 
null
[[Prototype]]
: 
HTMLDocument
constructor
: 
ƒ HTMLDocument()
Symbol(Symbol.toStringTag)
: 
"HTMLDocument"
URL
: 
(...)
activeElement
: 
(...)
adoptedStyleSheets
: 
(...)
alinkColor
: 
(...)
all
: 
(...)
anchors
: 
(...)
applets
: 
(...)
baseURI
: 
(...)
bgColor
: 
(...)
body
: 
(...)
characterSet
: 
(...)
charset
: 
(...)
childElementCount
: 
(...)
childNodes
: 
(...)
children
: 
(...)
compatMode
: 
(...)
contentType
: 
(...)
cookie
: 
(...)
currentScript
: 
(...)
defaultView
: 
(...)
designMode
: 
(...)
dir
: 
(...)
doctype
: 
(...)
documentElement
: 
(...)
documentURI
: 
(...)
domain
: 
(...)
embeds
: 
(...)
featurePolicy
: 
(...)
fgColor
: 
(...)
firstChild
: 
(...)
firstElementChild
: 
(...)
fonts
: 
(...)
forms
: 
(...)
fragmentDirective
: 
(...)
fullscreen
: 
(...)
fullscreenElement
: 
(...)
fullscreenEnabled
: 
(...)
head
: 
(...)
hidden
: 
(...)
images
: 
(...)
implementation
: 
(...)
inputEncoding
: 
(...)
isConnected
: 
(...)
lastChild
: 
(...)
lastElementChild
: 
(...)
lastModified
: 
(...)
linkColor
: 
(...)
links
: 
(...)
nextSibling
: 
(...)
nodeName
: 
(...)
nodeType
: 
(...)
nodeValue
: 
(...)
onabort
: 
(...)
onanimationend
: 
(...)
onanimationiteration
: 
(...)
onanimationstart
: 
(...)
onauxclick
: 
(...)
onbeforecopy
: 
(...)
onbeforecut
: 
(...)
onbeforeinput
: 
(...)
onbeforematch
: 
(...)
onbeforepaste
: 
(...)
onbeforetoggle
: 
(...)
onbeforexrselect
: 
(...)
onblur
: 
(...)
oncancel
: 
(...)
oncanplay
: 
(...)
oncanplaythrough
: 
(...)
onchange
: 
(...)
onclick
: 
(...)
onclose
: 
(...)
oncommand
: 
(...)
oncontentvisibilityautostatechange
: 
(...)
oncontextlost
: 
(...)
oncontextmenu
: 
(...)
oncontextrestored
: 
(...)
oncopy
: 
(...)
oncuechange
: 
(...)
oncut
: 
(...)
ondblclick
: 
(...)
ondrag
: 
(...)
ondragend
: 
(...)
ondragenter
: 
(...)
ondragleave
: 
(...)
ondragover
: 
(...)
ondragstart
: 
(...)
ondrop
: 
(...)
ondurationchange
: 
(...)
onemptied
: 
(...)
onended
: 
(...)
onerror
: 
(...)
onfocus
: 
(...)
onformdata
: 
(...)
onfreeze
: 
(...)
onfullscreenchange
: 
(...)
onfullscreenerror
: 
(...)
ongotpointercapture
: 
(...)
oninput
: 
(...)
oninvalid
: 
(...)
onkeydown
: 
(...)
onkeypress
: 
(...)
onkeyup
: 
(...)
onload
: 
(...)
onloadeddata
: 
(...)
onloadedmetadata
: 
(...)
onloadstart
: 
(...)
onlostpointercapture
: 
(...)
onmousedown
: 
(...)
onmouseenter
: 
undefined
onmouseleave
: 
undefined
onmousemove
: 
(...)
onmouseout
: 
(...)
onmouseover
: 
(...)
onmouseup
: 
(...)
onmousewheel
: 
(...)
onoverscroll
: 
(...)
onpaste
: 
(...)
onpause
: 
(...)
onplay
: 
(...)
onplaying
: 
(...)
onpointercancel
: 
(...)
onpointerdown
: 
(...)
onpointerenter
: 
(...)
onpointerleave
: 
(...)
onpointerlockchange
: 
(...)
onpointerlockerror
: 
(...)
onpointermove
: 
(...)
onpointerout
: 
(...)
onpointerover
: 
(...)
onpointerrawupdate
: 
(...)
onpointerup
: 
(...)
onprerenderingchange
: 
(...)
onprogress
: 
(...)
onratechange
: 
(...)
onreadystatechange
: 
undefined
onreset
: 
(...)
onresize
: 
(...)
onresume
: 
(...)
onscroll
: 
(...)
onscrollend
: 
(...)
onscrollsnapchange
: 
(...)
onscrollsnapchanging
: 
(...)
onsearch
: 
(...)
onsecuritypolicyviolation
: 
(...)
onseeked
: 
(...)
onseeking
: 
(...)
onselect
: 
(...)
onselectionchange
: 
(...)
onselectstart
: 
(...)
onslotchange
: 
(...)
onstalled
: 
(...)
onsubmit
: 
(...)
onsuspend
: 
(...)
ontimeupdate
: 
(...)
ontoggle
: 
(...)
ontransitioncancel
: 
(...)
ontransitionend
: 
(...)
ontransitionrun
: 
(...)
ontransitionstart
: 
(...)
onvisibilitychange
: 
(...)
onvolumechange
: 
(...)
onwaiting
: 
(...)
onwebkitanimationend
: 
(...)
onwebkitanimationiteration
: 
(...)
onwebkitanimationstart
: 
(...)
onwebkitfullscreenchange
: 
(...)
onwebkitfullscreenerror
: 
(...)
onwebkittransitionend
: 
(...)
onwheel
: 
(...)
ownerDocument
: 
(...)
parentElement
: 
(...)
parentNode
: 
(...)
pictureInPictureElement
: 
(...)
pictureInPictureEnabled
: 
(...)
plugins
: 
(...)
pointerLockElement
: 
(...)
prerendering
: 
(...)
previousSibling
: 
(...)
readyState
: 
(...)
referrer
: 
(...)
rootElement
: 
(...)
scripts
: 
(...)
scrollingElement
: 
(...)
softNavigations
: 
(...)
styleSheets
: 
(...)
textContent
: 
(...)
timeline
: 
(...)
title
: 
(...)
visibilityState
: 
(...)
vlinkColor
: 
(...)
wasDiscarded
: 
(...)
webkitCurrentFullScreenElement
: 
(...)
webkitFullscreenElement
: 
(...)
webkitFullscreenEnabled
: 
(...)
webkitHidden
: 
(...)
webkitIsFullScreen
: 
(...)
webkitVisibilityState
: 
(...)
xmlEncoding
: 
(...)
xmlStandalone
: 
(...)
xmlVersion
: 
(...)
[[Prototype]]
: 
Document
URL
: 
(...)
activeElement
: 
(...)
adoptNode
: 
ƒ adoptNode()
adoptedStyleSheets
: 
(...)
alinkColor
: 
(...)
all
: 
(...)
anchors
: 
(...)
append
: 
ƒ append()
applets
: 
(...)
ariaNotify
: 
ƒ ariaNotify()
bgColor
: 
(...)
body
: 
(...)
browsingTopics
: 
ƒ browsingTopics()
captureEvents
: 
ƒ captureEvents()
caretPositionFromPoint
: 
ƒ caretPositionFromPoint()
caretRangeFromPoint
: 
ƒ caretRangeFromPoint()
characterSet
: 
(...)
charset
: 
(...)
childElementCount
: 
(...)
children
: 
(...)
clear
: 
ƒ clear()
close
: 
ƒ close()
compatMode
: 
(...)
contentType
: 
(...)
cookie
: 
(...)
createAttribute
: 
ƒ createAttribute()
createAttributeNS
: 
ƒ createAttributeNS()
createCDATASection
: 
ƒ createCDATASection()
createComment
: 
ƒ createComment()
createDocumentFragment
: 
ƒ createDocumentFragment()
createElement
: 
ƒ createElement()
createElementNS
: 
ƒ createElementNS()
createEvent
: 
ƒ createEvent()
createExpression
: 
ƒ createExpression()
createNSResolver
: 
ƒ createNSResolver()
createNodeIterator
: 
ƒ createNodeIterator()
createProcessingInstruction
: 
ƒ createProcessingInstruction()
createRange
: 
ƒ createRange()
createTextNode
: 
ƒ createTextNode()
createTreeWalker
: 
ƒ createTreeWalker()
currentScript
: 
(...)
defaultView
: 
(...)
designMode
: 
(...)
dir
: 
(...)
doctype
: 
(...)
documentElement
: 
(...)
documentURI
: 
(...)
domain
: 
(...)
elementFromPoint
: 
ƒ elementFromPoint()
elementsFromPoint
: 
ƒ elementsFromPoint()
embeds
: 
(...)
evaluate
: 
ƒ evaluate()
execCommand
: 
ƒ execCommand()
exitFullscreen
: 
ƒ exitFullscreen()
exitPictureInPicture
: 
ƒ exitPictureInPicture()
exitPointerLock
: 
ƒ exitPointerLock()
featurePolicy
: 
(...)
fgColor
: 
(...)
firstElementChild
: 
(...)
fonts
: 
(...)
forms
: 
(...)
fragmentDirective
: 
(...)
fullscreen
: 
(...)
fullscreenElement
: 
(...)
fullscreenEnabled
: 
(...)
getAnimations
: 
ƒ getAnimations()
getElementById
: 
ƒ getElementById()
getElementsByClassName
: 
ƒ getElementsByClassName()
getElementsByName
: 
ƒ getElementsByName()
getElementsByTagName
: 
ƒ getElementsByTagName()
getElementsByTagNameNS
: 
ƒ getElementsByTagNameNS()
getPartRoot
: 
ƒ getPartRoot()
getSelection
: 
ƒ getSelection()
hasFocus
: 
ƒ hasFocus()
hasPrivateToken
: 
ƒ hasPrivateToken()
hasRedemptionRecord
: 
ƒ hasRedemptionRecord()
hasStorageAccess
: 
ƒ hasStorageAccess()
hasUnpartitionedCookieAccess
: 
ƒ hasUnpartitionedCookieAccess()
head
: 
(...)
hidden
: 
(...)
images
: 
(...)
implementation
: 
(...)
importNode
: 
ƒ importNode()
inputEncoding
: 
(...)
lastElementChild
: 
(...)
lastModified
: 
(...)
linkColor
: 
(...)
links
: 
(...)
moveBefore
: 
ƒ moveBefore()
onabort
: 
(...)
onanimationend
: 
(...)
onanimationiteration
: 
(...)
onanimationstart
: 
(...)
onauxclick
: 
(...)
onbeforecopy
: 
(...)
onbeforecut
: 
(...)
onbeforeinput
: 
(...)
onbeforematch
: 
(...)
onbeforepaste
: 
(...)
onbeforetoggle
: 
(...)
onbeforexrselect
: 
(...)
onblur
: 
(...)
oncancel
: 
(...)
oncanplay
: 
(...)
oncanplaythrough
: 
(...)
onchange
: 
(...)
onclick
: 
(...)
onclose
: 
(...)
oncommand
: 
(...)
oncontentvisibilityautostatechange
: 
(...)
oncontextlost
: 
(...)
oncontextmenu
: 
(...)
oncontextrestored
: 
(...)
oncopy
: 
(...)
oncuechange
: 
(...)
oncut
: 
(...)
ondblclick
: 
(...)
ondrag
: 
(...)
ondragend
: 
(...)
ondragenter
: 
(...)
ondragleave
: 
(...)
ondragover
: 
(...)
ondragstart
: 
(...)
ondrop
: 
(...)
ondurationchange
: 
(...)
onemptied
: 
(...)
onended
: 
(...)
onerror
: 
(...)
onfocus
: 
(...)
onformdata
: 
(...)
onfreeze
: 
(...)
onfullscreenchange
: 
(...)
onfullscreenerror
: 
(...)
ongotpointercapture
: 
(...)
oninput
: 
(...)
oninvalid
: 
(...)
onkeydown
: 
(...)
onkeypress
: 
(...)
onkeyup
: 
(...)
onload
: 
(...)
onloadeddata
: 
(...)
onloadedmetadata
: 
(...)
onloadstart
: 
(...)
onlostpointercapture
: 
(...)
onmousedown
: 
(...)
onmouseenter
: 
undefined
onmouseleave
: 
undefined
onmousemove
: 
(...)
onmouseout
: 
(...)
onmouseover
: 
(...)
onmouseup
: 
(...)
onmousewheel
: 
(...)
onoverscroll
: 
(...)
onpaste
: 
(...)
onpause
: 
(...)
onplay
: 
(...)
onplaying
: 
(...)
onpointercancel
: 
(...)
onpointerdown
: 
(...)
onpointerenter
: 
(...)
onpointerleave
: 
(...)
onpointerlockchange
: 
(...)
onpointerlockerror
: 
(...)
onpointermove
: 
(...)
onpointerout
: 
(...)
onpointerover
: 
(...)
onpointerrawupdate
: 
(...)
onpointerup
: 
(...)
onprerenderingchange
: 
(...)
onprogress
: 
(...)
onratechange
: 
(...)
onreadystatechange
: 
undefined
onreset
: 
(...)
onresize
: 
(...)
onresume
: 
(...)
onscroll
: 
(...)
onscrollend
: 
(...)
onscrollsnapchange
: 
(...)
onscrollsnapchanging
: 
(...)
onsearch
: 
(...)
onsecuritypolicyviolation
: 
(...)
onseeked
: 
(...)
onseeking
: 
(...)
onselect
: 
(...)
onselectionchange
: 
(...)
onselectstart
: 
(...)
onslotchange
: 
(...)
onstalled
: 
(...)
onsubmit
: 
(...)
onsuspend
: 
(...)
ontimeupdate
: 
(...)
ontoggle
: 
(...)
ontransitioncancel
: 
(...)
ontransitionend
: 
(...)
ontransitionrun
: 
(...)
ontransitionstart
: 
(...)
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
(...)
onwebkitanimationstart
: 
(...)
onwebkitfullscreenchange
: 
(...)
onwebkitfullscreenerror
: 
(...)
onwebkittransitionend
: 
null
onwheel
: 
null
open
: 
ƒ open()
pictureInPictureElement
: 
(...)
pictureInPictureEnabled
: 
(...)
plugins
: 
HTMLCollection(0)
length
: 
0
[[Prototype]]
: 
HTMLCollection
pointerLockElement
: 
null
prepend
: 
ƒ prepend()
prerendering
: 
false
queryCommandEnabled
: 
ƒ queryCommandEnabled()
queryCommandIndeterm
: 
ƒ queryCommandIndeterm()
queryCommandState
: 
ƒ queryCommandState()
queryCommandSupported
: 
ƒ queryCommandSupported()
queryCommandValue
: 
ƒ queryCommandValue()
querySelector
: 
ƒ querySelector()
querySelectorAll
: 
ƒ querySelectorAll()
readyState
: 
(...)
referrer
: 
(...)
releaseEvents
: 
ƒ releaseEvents()
replaceChildren
: 
ƒ replaceChildren()
requestStorageAccess
: 
ƒ requestStorageAccess()
requestStorageAccessFor
: 
ƒ requestStorageAccessFor()
rootElement
: 
(...)
scripts
: 
(...)
scrollingElement
: 
(...)
setSequentialFocusStartingPoint
: 
ƒ setSequentialFocusStartingPoint()
softNavigations
: 
(...)
startViewTransition
: 
ƒ startViewTransition()
styleSheets
: 
(...)
timeline
: 
(...)
title
: 
(...)
visibilityState
: 
(...)
vlinkColor
: 
(...)
wasDiscarded
: 
(...)
webkitCancelFullScreen
: 
ƒ webkitCancelFullScreen()
webkitCurrentFullScreenElement
: 
(...)
webkitExitFullscreen
: 
ƒ webkitExitFullscreen()
webkitFullscreenElement
: 
(...)
webkitFullscreenEnabled
: 
(...)
webkitHidden
: 
(...)
webkitIsFullScreen
: 
(...)
webkitVisibilityState
: 
(...)
write
: 
ƒ write()
writeln
: 
ƒ writeln()
xmlEncoding
: 
(...)
xmlStandalone
: 
(...)
xmlVersion
: 
(...)
constructor
: 
ƒ Document()
Symbol(Symbol.toStringTag)
: 
"Document"
Symbol(Symbol.unscopables)
: 
{append: true, fullscreen: true, prepend: true, replaceChildren: true}
baseURI
: 
(...)
childNodes
: 
NodeList(4)
0
: 
<!DOCTYPE html>
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList(0)
length
: 
0
[[Prototype]]
: 
NodeList
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
name
: 
"html"
nextSibling
: 
comment
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
" Note that chrome://flags is intentionally not a translated UI surface, "
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
72
nextElementSibling
: 
html
nextSibling
: 
comment
nodeName
: 
"#comment"
nodeType
: 
8
nodeValue
: 
" Note that chrome://flags is intentionally not a translated UI surface, "
ownerDocument
: 
document
parentElement
: 
null
parentNode
: 
document
previousElementSibling
: 
null
previousSibling
: 
<!DOCTYPE html>
textContent
: 
" Note that chrome://flags is intentionally not a translated UI surface, "
[[Prototype]]
: 
Comment
nodeName
: 
"html"
nodeType
: 
10
nodeValue
: 
null
ownerDocument
: 
document
parentElement
: 
null
parentNode
: 
document
previousSibling
: 
null
publicId
: 
""
systemId
: 
""
textContent
: 
null
[[Prototype]]
: 
DocumentType
1
: 
comment
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
" Note that chrome://flags is intentionally not a translated UI surface, "
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
72
nextElementSibling
: 
html
nextSibling
: 
comment
nodeName
: 
"#comment"
nodeType
: 
8
nodeValue
: 
" Note that chrome://flags is intentionally not a translated UI surface, "
ownerDocument
: 
document
parentElement
: 
null
parentNode
: 
document
previousElementSibling
: 
null
previousSibling
: 
<!DOCTYPE html>
textContent
: 
" Note that chrome://flags is intentionally not a translated UI surface, "
[[Prototype]]
: 
Comment
2
: 
comment
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
" so don't mark it with direction or language attributes. "
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
57
nextElementSibling
: 
html
nextSibling
: 
html
nodeName
: 
"#comment"
nodeType
: 
8
nodeValue
: 
" so don't mark it with direction or language attributes. "
ownerDocument
: 
document
parentElement
: 
null
parentNode
: 
document
previousElementSibling
: 
null
previousSibling
: 
comment
textContent
: 
" so don't mark it with direction or language attributes. "
[[Prototype]]
: 
Comment
constructor
: 
ƒ Comment()
Symbol(Symbol.toStringTag)
: 
"Comment"
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList(0)
data
: 
" so don't mark it with direction or language attributes. "
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
57
nextElementSibling
: 
(...)
nextSibling
: 
html
nodeName
: 
"#comment"
nodeType
: 
8
nodeValue
: 
" so don't mark it with direction or language attributes. "
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
URL
: 
"chrome://flags/"
activeElement
: 
body
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(11) [html, head, meta, meta, meta, link, title, style, body, script, flags-app, color-scheme: meta, viewport: meta]
anchors
: 
HTMLCollection []
applets
: 
HTMLCollection []
baseURI
: 
"chrome://flags/"
bgColor
: 
""
body
: 
body
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(4) [<!DOCTYPE html>, comment, comment, html]
children
: 
HTMLCollection [html]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
""
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
""
doctype
: 
<!DOCTYPE html>
documentElement
: 
html
documentURI
: 
"chrome://flags/"
domain
: 
"flags"
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection []
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html
lastElementChild
: 
html
lastModified
: 
"09/22/2025 11:42:04"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection [script]
scrollingElement
: 
html
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, length: 2}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 614967.548, duration: null}
title
: 
"Experiments"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
xmlVersion
: 
null
[[Prototype]]
: 
HTMLDocument
constructor
: 
ƒ HTMLDocument()
Symbol(Symbol.toStringTag)
: 
"HTMLDocument"
URL
: 
(...)
activeElement
: 
(...)
adoptedStyleSheets
: 
(...)
alinkColor
: 
(...)
all
: 
(...)
anchors
: 
(...)
applets
: 
(...)
baseURI
: 
(...)
bgColor
: 
(...)
body
: 
(...)
characterSet
: 
(...)
charset
: 
(...)
childElementCount
: 
(...)
childNodes
: 
(...)
children
: 
(...)
compatMode
: 
(...)
contentType
: 
(...)
cookie
: 
(...)
currentScript
: 
(...)
defaultView
: 
(...)
designMode
: 
(...)
dir
: 
(...)
doctype
: 
(...)
documentElement
: 
(...)
documentURI
: 
(...)
domain
: 
(...)
embeds
: 
(...)
featurePolicy
: 
(...)
fgColor
: 
(...)
firstChild
: 
(...)
firstElementChild
: 
(...)
fonts
: 
(...)
forms
: 
(...)
fragmentDirective
: 
(...)
fullscreen
: 
(...)
fullscreenElement
: 
(...)
fullscreenEnabled
: 
(...)
head
: 
(...)
hidden
: 
(...)
images
: 
(...)
implementation
: 
(...)
inputEncoding
: 
(...)
isConnected
: 
(...)
lastChild
: 
(...)
lastElementChild
: 
(...)
lastModified
: 
(...)
linkColor
: 
(...)
links
: 
(...)
nextSibling
: 
(...)
nodeName
: 
(...)
nodeType
: 
(...)
nodeValue
: 
(...)
onabort
: 
(...)
onanimationend
: 
(...)
onanimationiteration
: 
(...)
onanimationstart
: 
(...)
onauxclick
: 
(...)
onbeforecopy
: 
(...)
onbeforecut
: 
(...)
onbeforeinput
: 
(...)
onbeforematch
: 
(...)
onbeforepaste
: 
(...)
onbeforetoggle
: 
(...)
onbeforexrselect
: 
(...)
onblur
: 
(...)
oncancel
: 
(...)
oncanplay
: 
(...)
oncanplaythrough
: 
(...)
onchange
: 
(...)
onclick
: 
(...)
onclose
: 
(...)
oncommand
: 
(...)
oncontentvisibilityautostatechange
: 
(...)
oncontextlost
: 
(...)
oncontextmenu
: 
(...)
oncontextrestored
: 
(...)
oncopy
: 
(...)
oncuechange
: 
(...)
oncut
: 
(...)
ondblclick
: 
(...)
ondrag
: 
(...)
ondragend
: 
(...)
ondragenter
: 
(...)
ondragleave
: 
(...)
ondragover
: 
(...)
ondragstart
: 
(...)
ondrop
: 
(...)
ondurationchange
: 
(...)
onemptied
: 
(...)
onended
: 
(...)
onerror
: 
(...)
onfocus
: 
(...)
onformdata
: 
(...)
onfreeze
: 
(...)
onfullscreenchange
: 
(...)
onfullscreenerror
: 
(...)
ongotpointercapture
: 
(...)
oninput
: 
(...)
oninvalid
: 
(...)
onkeydown
: 
(...)
onkeypress
: 
(...)
onkeyup
: 
(...)
onload
: 
(...)
onloadeddata
: 
(...)
onloadedmetadata
: 
(...)
onloadstart
: 
(...)
onlostpointercapture
: 
(...)
onmousedown
: 
(...)
onmouseenter
: 
undefined
onmouseleave
: 
undefined
onmousemove
: 
(...)
onmouseout
: 
(...)
onmouseover
: 
(...)
onmouseup
: 
(...)
onmousewheel
: 
(...)
onoverscroll
: 
(...)
onpaste
: 
(...)
onpause
: 
(...)
onplay
: 
(...)
onplaying
: 
(...)
onpointercancel
: 
(...)
onpointerdown
: 
(...)
onpointerenter
: 
(...)
onpointerleave
: 
(...)
onpointerlockchange
: 
(...)
onpointerlockerror
: 
(...)
onpointermove
: 
(...)
onpointerout
: 
(...)
onpointerover
: 
(...)
onpointerrawupdate
: 
(...)
onpointerup
: 
(...)
onprerenderingchange
: 
(...)
onprogress
: 
(...)
onratechange
: 
(...)
onreadystatechange
: 
undefined
onreset
: 
(...)
onresize
: 
(...)
onresume
: 
(...)
onscroll
: 
(...)
onscrollend
: 
(...)
onscrollsnapchange
: 
(...)
onscrollsnapchanging
: 
(...)
onsearch
: 
(...)
onsecuritypolicyviolation
: 
(...)
onseeked
: 
(...)
onseeking
: 
(...)
onselect
: 
(...)
onselectionchange
: 
(...)
onselectstart
: 
(...)
onslotchange
: 
(...)
onstalled
: 
(...)
onsubmit
: 
(...)
onsuspend
: 
(...)
ontimeupdate
: 
(...)
ontoggle
: 
(...)
ontransitioncancel
: 
(...)
ontransitionend
: 
(...)
ontransitionrun
: 
(...)
ontransitionstart
: 
(...)
onvisibilitychange
: 
(...)
onvolumechange
: 
(...)
onwaiting
: 
(...)
onwebkitanimationend
: 
(...)
onwebkitanimationiteration
: 
(...)
onwebkitanimationstart
: 
(...)
onwebkitfullscreenchange
: 
(...)
onwebkitfullscreenerror
: 
(...)
onwebkittransitionend
: 
(...)
onwheel
: 
(...)
ownerDocument
: 
(...)
parentElement
: 
(...)
parentNode
: 
(...)
pictureInPictureElement
: 
(...)
pictureInPictureEnabled
: 
(...)
plugins
: 
(...)
pointerLockElement
: 
(...)
prerendering
: 
(...)
previousSibling
: 
(...)
readyState
: 
(...)
referrer
: 
(...)
rootElement
: 
(...)
scripts
: 
(...)
scrollingElement
: 
(...)
softNavigations
: 
(...)
styleSheets
: 
(...)
textContent
: 
(...)
timeline
: 
(...)
title
: 
(...)
visibilityState
: 
(...)
vlinkColor
: 
(...)
wasDiscarded
: 
(...)
webkitCurrentFullScreenElement
: 
(...)
webkitFullscreenElement
: 
(...)
webkitFullscreenEnabled
: 
(...)
webkitHidden
: 
(...)
webkitIsFullScreen
: 
(...)
webkitVisibilityState
: 
(...)
xmlEncoding
: 
(...)
xmlStandalone
: 
(...)
xmlVersion
: 
(...)
[[Prototype]]
: 
Document
URL
: 
(...)
activeElement
: 
(...)
adoptNode
: 
ƒ adoptNode()
adoptedStyleSheets
: 
(...)
alinkColor
: 
(...)
all
: 
(...)
anchors
: 
(...)
append
: 
ƒ append()
applets
: 
(...)
ariaNotify
: 
ƒ ariaNotify()
bgColor
: 
(...)
body
: 
(...)
browsingTopics
: 
ƒ browsingTopics()
captureEvents
: 
ƒ captureEvents()
caretPositionFromPoint
: 
ƒ caretPositionFromPoint()
caretRangeFromPoint
: 
ƒ caretRangeFromPoint()
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
children
: 
HTMLCollection(1)
0
: 
html
length
: 
1
[[Prototype]]
: 
HTMLCollection
clear
: 
ƒ clear()
close
: 
ƒ close()
compatMode
: 
(...)
contentType
: 
(...)
cookie
: 
(...)
createAttribute
: 
ƒ createAttribute()
createAttributeNS
: 
ƒ createAttributeNS()
createCDATASection
: 
ƒ createCDATASection()
createComment
: 
ƒ createComment()
createDocumentFragment
: 
ƒ createDocumentFragment()
createElement
: 
ƒ createElement()
createElementNS
: 
ƒ createElementNS()
createEvent
: 
ƒ createEvent()
createExpression
: 
ƒ createExpression()
createNSResolver
: 
ƒ createNSResolver()
createNodeIterator
: 
ƒ createNodeIterator()
createProcessingInstruction
: 
ƒ createProcessingInstruction()
createRange
: 
ƒ createRange()
createTextNode
: 
ƒ createTextNode()
createTreeWalker
: 
ƒ createTreeWalker()
currentScript
: 
(...)
defaultView
: 
(...)
designMode
: 
(...)
dir
: 
(...)
doctype
: 
(...)
documentElement
: 
(...)
documentURI
: 
(...)
domain
: 
(...)
elementFromPoint
: 
ƒ elementFromPoint()
elementsFromPoint
: 
ƒ elementsFromPoint()
embeds
: 
(...)
evaluate
: 
ƒ evaluate()
execCommand
: 
ƒ execCommand()
exitFullscreen
: 
ƒ exitFullscreen()
exitPictureInPicture
: 
ƒ exitPictureInPicture()
exitPointerLock
: 
ƒ exitPointerLock()
featurePolicy
: 
(...)
fgColor
: 
(...)
firstElementChild
: 
(...)
fonts
: 
(...)
forms
: 
(...)
fragmentDirective
: 
(...)
fullscreen
: 
(...)
fullscreenElement
: 
(...)
fullscreenEnabled
: 
(...)
getAnimations
: 
ƒ getAnimations()
getElementById
: 
ƒ getElementById()
getElementsByClassName
: 
ƒ getElementsByClassName()
getElementsByName
: 
ƒ getElementsByName()
getElementsByTagName
: 
ƒ getElementsByTagName()
getElementsByTagNameNS
: 
ƒ getElementsByTagNameNS()
getPartRoot
: 
ƒ getPartRoot()
getSelection
: 
ƒ getSelection()
hasFocus
: 
ƒ hasFocus()
hasPrivateToken
: 
ƒ hasPrivateToken()
hasRedemptionRecord
: 
ƒ hasRedemptionRecord()
hasStorageAccess
: 
ƒ hasStorageAccess()
hasUnpartitionedCookieAccess
: 
ƒ hasUnpartitionedCookieAccess()
head
: 
(...)
hidden
: 
(...)
images
: 
(...)
implementation
: 
(...)
importNode
: 
ƒ importNode()
inputEncoding
: 
(...)
lastElementChild
: 
(...)
lastModified
: 
(...)
linkColor
: 
(...)
links
: 
(...)
moveBefore
: 
ƒ moveBefore()
onabort
: 
(...)
onanimationend
: 
(...)
onanimationiteration
: 
(...)
onanimationstart
: 
(...)
onauxclick
: 
(...)
onbeforecopy
: 
(...)
onbeforecut
: 
(...)
onbeforeinput
: 
(...)
onbeforematch
: 
(...)
onbeforepaste
: 
(...)
onbeforetoggle
: 
(...)
onbeforexrselect
: 
(...)
onblur
: 
(...)
oncancel
: 
(...)
oncanplay
: 
(...)
oncanplaythrough
: 
(...)
onchange
: 
(...)
onclick
: 
(...)
onclose
: 
(...)
oncommand
: 
(...)
oncontentvisibilityautostatechange
: 
(...)
oncontextlost
: 
(...)
oncontextmenu
: 
(...)
oncontextrestored
: 
(...)
oncopy
: 
(...)
oncuechange
: 
(...)
oncut
: 
(...)
ondblclick
: 
(...)
ondrag
: 
(...)
ondragend
: 
(...)
ondragenter
: 
(...)
ondragleave
: 
(...)
ondragover
: 
(...)
ondragstart
: 
(...)
ondrop
: 
(...)
ondurationchange
: 
(...)
onemptied
: 
(...)
onended
: 
(...)
onerror
: 
(...)
onfocus
: 
(...)
onformdata
: 
(...)
onfreeze
: 
(...)
onfullscreenchange
: 
(...)
onfullscreenerror
: 
(...)
ongotpointercapture
: 
(...)
oninput
: 
(...)
oninvalid
: 
(...)
onkeydown
: 
(...)
onkeypress
: 
(...)
onkeyup
: 
(...)
onload
: 
(...)
onloadeddata
: 
(...)
onloadedmetadata
: 
(...)
onloadstart
: 
(...)
onlostpointercapture
: 
(...)
onmousedown
: 
(...)
onmouseenter
: 
undefined
onmouseleave
: 
undefined
onmousemove
: 
(...)
onmouseout
: 
(...)
onmouseover
: 
(...)
onmouseup
: 
(...)
onmousewheel
: 
(...)
onoverscroll
: 
(...)
onpaste
: 
(...)
onpause
: 
(...)
onplay
: 
(...)
onplaying
: 
(...)
onpointercancel
: 
(...)
onpointerdown
: 
(...)
onpointerenter
: 
(...)
onpointerleave
: 
(...)
onpointerlockchange
: 
(...)
onpointerlockerror
: 
(...)
onpointermove
: 
(...)
onpointerout
: 
(...)
onpointerover
: 
(...)
onpointerrawupdate
: 
(...)
onpointerup
: 
(...)
onprerenderingchange
: 
(...)
onprogress
: 
(...)
onratechange
: 
(...)
onreadystatechange
: 
undefined
onreset
: 
(...)
onresize
: 
(...)
onresume
: 
(...)
onscroll
: 
(...)
onscrollend
: 
(...)
onscrollsnapchange
: 
(...)
onscrollsnapchanging
: 
(...)
onsearch
: 
(...)
onsecuritypolicyviolation
: 
(...)
onseeked
: 
(...)
onseeking
: 
(...)
onselect
: 
(...)
onselectionchange
: 
(...)
onselectstart
: 
(...)
onslotchange
: 
(...)
onstalled
: 
(...)
onsubmit
: 
(...)
onsuspend
: 
(...)
ontimeupdate
: 
(...)
ontoggle
: 
(...)
ontransitioncancel
: 
(...)
ontransitionend
: 
(...)
ontransitionrun
: 
(...)
ontransitionstart
: 
(...)
onvisibilitychange
: 
(...)
onvolumechange
: 
(...)
onwaiting
: 
(...)
onwebkitanimationend
: 
(...)
onwebkitanimationiteration
: 
(...)
onwebkitanimationstart
: 
(...)
onwebkitfullscreenchange
: 
(...)
onwebkitfullscreenerror
: 
(...)
onwebkittransitionend
: 
(...)
onwheel
: 
(...)
open
: 
ƒ open()
pictureInPictureElement
: 
(...)
pictureInPictureEnabled
: 
(...)
plugins
: 
(...)
pointerLockElement
: 
(...)
prepend
: 
ƒ prepend()
prerendering
: 
(...)
queryCommandEnabled
: 
ƒ queryCommandEnabled()
queryCommandIndeterm
: 
ƒ queryCommandIndeterm()
queryCommandState
: 
ƒ queryCommandState()
queryCommandSupported
: 
ƒ queryCommandSupported()
queryCommandValue
: 
ƒ queryCommandValue()
querySelector
: 
ƒ querySelector()
querySelectorAll
: 
ƒ querySelectorAll()
readyState
: 
(...)
referrer
: 
(...)
releaseEvents
: 
ƒ releaseEvents()
replaceChildren
: 
ƒ replaceChildren()
requestStorageAccess
: 
ƒ requestStorageAccess()
requestStorageAccessFor
: 
ƒ requestStorageAccessFor()
rootElement
: 
(...)
scripts
: 
(...)
scrollingElement
: 
(...)
setSequentialFocusStartingPoint
: 
ƒ setSequentialFocusStartingPoint()
softNavigations
: 
(...)
startViewTransition
: 
ƒ startViewTransition()
styleSheets
: 
(...)
timeline
: 
(...)
title
: 
(...)
visibilityState
: 
(...)
vlinkColor
: 
(...)
wasDiscarded
: 
(...)
webkitCancelFullScreen
: 
ƒ webkitCancelFullScreen()
webkitCurrentFullScreenElement
: 
(...)
webkitExitFullscreen
: 
ƒ webkitExitFullscreen()
webkitFullscreenElement
: 
(...)
webkitFullscreenEnabled
: 
(...)
webkitHidden
: 
(...)
webkitIsFullScreen
: 
(...)
webkitVisibilityState
: 
(...)
write
: 
ƒ write()
writeln
: 
ƒ writeln()
xmlEncoding
: 
(...)
xmlStandalone
: 
(...)
xmlVersion
: 
(...)
constructor
: 
ƒ Document()
Symbol(Symbol.toStringTag)
: 
"Document"
Symbol(Symbol.unscopables)
: 
{append: true, fullscreen: true, prepend: true, replaceChildren: true}
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList(4)
firstChild
: 
<!DOCTYPE html>
isConnected
: 
true
lastChild
: 
html
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, class: class, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(3) [head, text, body]
children
: 
HTMLCollection(2) [head, body]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
head
firstElementChild
: 
head
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"<head>\n<meta charset=\"utf-8\">\n<meta name=\"color-scheme\" content=\"light dark\">\n\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <link rel=\"stylesheet\" href=\"chrome://resources/css/text_defaults_md.css\">\n\n<title>Experiments</title>\n\n\n<style>\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n</style>\n</head>\n<body>\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n</body>"
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
body
lastElementChild
: 
body
localName
: 
"html"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"HTML"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
outerHTML
: 
"<html class=\"\"><head>\n<meta charset=\"utf-8\">\n<meta name=\"color-scheme\" content=\"light dark\">\n\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <link rel=\"stylesheet\" href=\"chrome://resources/css/text_defaults_md.css\">\n\n<title>Experiments</title>\n\n\n<style>\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n</style>\n</head>\n<body>\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n</body></html>"
outerText
: 
""
ownerDocument
: 
document
parentElement
: 
null
parentNode
: 
document
part
: 
DOMTokenList [value: '']
popover
: 
null
prefix
: 
null
previousElementSibling
: 
null
previousSibling
: 
comment
role
: 
null
scrollHeight
: 
2109
scrollLeft
: 
0
scrollParent
: 
null
scrollTop
: 
0
scrollWidth
: 
2689
shadowRoot
: 
null
slot
: 
""
spellcheck
: 
true
style
: 
CSSStyleDeclaration {accentColor: '', additiveSymbols: '', alignContent: '', alignItems: '', alignSelf: '', …}
tabIndex
: 
-1
tagName
: 
"HTML"
textContent
: 
"\n\n\n\n  \n  \n\nExperiments\n\n\n\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n\n\n\n  \n  \n\n\n"
title
: 
""
translate
: 
true
version
: 
""
virtualKeyboardPolicy
: 
""
writingSuggestions
: 
"true"
[[Prototype]]
: 
HTMLHtmlElement
version
: 
""
constructor
: 
ƒ HTMLHtmlElement()
Symbol(Symbol.toStringTag)
: 
"HTMLHtmlElement"
accessKey
: 
(...)
anchorElement
: 
(...)
ariaActiveDescendantElement
: 
(...)
ariaAtomic
: 
(...)
ariaAutoComplete
: 
(...)
ariaBrailleLabel
: 
(...)
ariaBrailleRoleDescription
: 
(...)
ariaBusy
: 
(...)
ariaChecked
: 
(...)
ariaColCount
: 
(...)
ariaColIndex
: 
(...)
ariaColIndexText
: 
(...)
ariaColSpan
: 
(...)
ariaControlsElements
: 
(...)
ariaCurrent
: 
(...)
ariaDescribedByElements
: 
(...)
ariaDescription
: 
(...)
ariaDetailsElements
: 
(...)
ariaDisabled
: 
(...)
ariaErrorMessageElements
: 
(...)
ariaExpanded
: 
(...)
ariaFlowToElements
: 
(...)
ariaHasPopup
: 
(...)
ariaHidden
: 
(...)
ariaInvalid
: 
(...)
ariaKeyShortcuts
: 
(...)
ariaLabel
: 
(...)
ariaLabelledByElements
: 
(...)
ariaLevel
: 
(...)
ariaLive
: 
(...)
ariaModal
: 
(...)
ariaMultiLine
: 
(...)
ariaMultiSelectable
: 
(...)
ariaOrientation
: 
(...)
ariaOwnsElements
: 
(...)
ariaPlaceholder
: 
(...)
ariaPosInSet
: 
(...)
ariaPressed
: 
(...)
ariaReadOnly
: 
(...)
ariaRelevant
: 
(...)
ariaRequired
: 
(...)
ariaRoleDescription
: 
(...)
ariaRowCount
: 
(...)
ariaRowIndex
: 
(...)
ariaRowIndexText
: 
(...)
ariaRowSpan
: 
(...)
ariaSelected
: 
(...)
ariaSetSize
: 
(...)
ariaSort
: 
(...)
ariaValueMax
: 
(...)
ariaValueMin
: 
(...)
ariaValueNow
: 
(...)
ariaValueText
: 
(...)
ariaVirtualContent
: 
(...)
assignedSlot
: 
(...)
attributeStyleMap
: 
(...)
attributes
: 
(...)
autocapitalize
: 
(...)
autofocus
: 
(...)
baseURI
: 
(...)
childElementCount
: 
(...)
childNodes
: 
(...)
children
: 
(...)
classList
: 
(...)
className
: 
(...)
clientHeight
: 
(...)
clientLeft
: 
(...)
clientTop
: 
(...)
clientWidth
: 
(...)
computedName
: 
(...)
computedRole
: 
(...)
containerTiming
: 
(...)
containerTimingIgnore
: 
(...)
contentEditable
: 
(...)
currentCSSZoom
: 
(...)
dataset
: 
(...)
dir
: 
(...)
draggable
: 
(...)
editContext
: 
(...)
elementTiming
: 
(...)
enterKeyHint
: 
(...)
firstChild
: 
(...)
firstElementChild
: 
(...)
focusgroup
: 
(...)
headingOffset
: 
(...)
headingReset
: 
(...)
hidden
: 
(...)
id
: 
(...)
inert
: 
(...)
innerHTML
: 
(...)
innerText
: 
(...)
inputMode
: 
(...)
isConnected
: 
(...)
isContentEditable
: 
(...)
lang
: 
(...)
lastChild
: 
(...)
lastElementChild
: 
(...)
localName
: 
(...)
namespaceURI
: 
(...)
nextElementSibling
: 
(...)
nextSibling
: 
(...)
nodeName
: 
(...)
nodeType
: 
(...)
nodeValue
: 
(...)
nonce
: 
(...)
offsetHeight
: 
(...)
offsetLeft
: 
(...)
offsetParent
: 
(...)
offsetTop
: 
(...)
offsetWidth
: 
(...)
onabort
: 
(...)
onanimationend
: 
(...)
onanimationiteration
: 
(...)
onanimationstart
: 
(...)
onauxclick
: 
(...)
onbeforecopy
: 
(...)
onbeforecut
: 
(...)
onbeforeinput
: 
(...)
onbeforematch
: 
(...)
onbeforepaste
: 
(...)
onbeforetoggle
: 
(...)
onbeforexrselect
: 
(...)
onblur
: 
(...)
oncancel
: 
(...)
oncanplay
: 
(...)
oncanplaythrough
: 
(...)
onchange
: 
(...)
onclick
: 
(...)
onclose
: 
(...)
oncommand
: 
(...)
oncontentvisibilityautostatechange
: 
(...)
oncontextlost
: 
(...)
oncontextmenu
: 
(...)
oncontextrestored
: 
(...)
oncopy
: 
(...)
oncuechange
: 
(...)
oncut
: 
(...)
ondblclick
: 
(...)
ondrag
: 
(...)
ondragend
: 
(...)
ondragenter
: 
(...)
ondragleave
: 
(...)
ondragover
: 
(...)
ondragstart
: 
(...)
ondrop
: 
(...)
ondurationchange
: 
(...)
onemptied
: 
(...)
onended
: 
(...)
onerror
: 
(...)
onfocus
: 
(...)
onformdata
: 
(...)
onfullscreenchange
: 
(...)
onfullscreenerror
: 
(...)
ongotpointercapture
: 
(...)
oninput
: 
(...)
oninvalid
: 
(...)
onkeydown
: 
(...)
onkeypress
: 
(...)
onkeyup
: 
(...)
onload
: 
(...)
onloadeddata
: 
(...)
onloadedmetadata
: 
(...)
onloadstart
: 
(...)
onlostpointercapture
: 
(...)
onmousedown
: 
(...)
onmouseenter
: 
undefined
onmouseleave
: 
undefined
onmousemove
: 
(...)
onmouseout
: 
(...)
onmouseover
: 
(...)
onmouseup
: 
(...)
onmousewheel
: 
(...)
onoverscroll
: 
(...)
onpaste
: 
(...)
onpause
: 
(...)
onplay
: 
(...)
onplaying
: 
(...)
onpointercancel
: 
(...)
onpointerdown
: 
(...)
onpointerenter
: 
(...)
onpointerleave
: 
(...)
onpointermove
: 
(...)
onpointerout
: 
(...)
onpointerover
: 
(...)
onpointerrawupdate
: 
(...)
onpointerup
: 
(...)
onprogress
: 
(...)
onratechange
: 
(...)
onreset
: 
(...)
onresize
: 
(...)
onscroll
: 
(...)
onscrollend
: 
(...)
onscrollsnapchange
: 
(...)
onscrollsnapchanging
: 
(...)
onsearch
: 
(...)
onsecuritypolicyviolation
: 
(...)
onseeked
: 
(...)
onseeking
: 
(...)
onselect
: 
(...)
onselectionchange
: 
(...)
onselectstart
: 
(...)
onslotchange
: 
(...)
onstalled
: 
(...)
onsubmit
: 
(...)
onsuspend
: 
(...)
ontimeupdate
: 
(...)
ontoggle
: 
(...)
ontransitioncancel
: 
(...)
ontransitionend
: 
(...)
ontransitionrun
: 
(...)
ontransitionstart
: 
(...)
onvolumechange
: 
(...)
onwaiting
: 
(...)
onwebkitanimationend
: 
(...)
onwebkitanimationiteration
: 
(...)
onwebkitanimationstart
: 
(...)
onwebkitfullscreenchange
: 
(...)
onwebkitfullscreenerror
: 
(...)
onwebkittransitionend
: 
(...)
onwheel
: 
(...)
outerHTML
: 
(...)
outerText
: 
(...)
ownerDocument
: 
(...)
parentElement
: 
(...)
parentNode
: 
(...)
part
: 
(...)
popover
: 
(...)
prefix
: 
(...)
previousElementSibling
: 
(...)
previousSibling
: 
(...)
role
: 
(...)
scrollHeight
: 
(...)
scrollLeft
: 
(...)
scrollParent
: 
(...)
scrollTop
: 
(...)
scrollWidth
: 
(...)
shadowRoot
: 
(...)
slot
: 
(...)
spellcheck
: 
(...)
style
: 
(...)
tabIndex
: 
(...)
tagName
: 
(...)
textContent
: 
(...)
title
: 
(...)
translate
: 
(...)
virtualKeyboardPolicy
: 
(...)
writingSuggestions
: 
(...)
get version
: 
ƒ version()
set version
: 
ƒ version()
[[Prototype]]
: 
HTMLElement
accessKey
: 
(...)
attachInternals
: 
ƒ attachInternals()
attributeStyleMap
: 
(...)
autocapitalize
: 
(...)
autofocus
: 
(...)
blur
: 
ƒ blur()
click
: 
ƒ click()
contentEditable
: 
(...)
dataset
: 
(...)
dir
: 
(...)
draggable
: 
(...)
editContext
: 
(...)
enterKeyHint
: 
(...)
focus
: 
ƒ focus()
focusgroup
: 
(...)
hidden
: 
(...)
hidePopover
: 
ƒ hidePopover()
inert
: 
(...)
innerText
: 
(...)
inputMode
: 
(...)
isContentEditable
: 
(...)
lang
: 
(...)
nonce
: 
(...)
offsetHeight
: 
(...)
offsetLeft
: 
(...)
offsetParent
: 
(...)
offsetTop
: 
(...)
offsetWidth
: 
(...)
onabort
: 
(...)
onanimationend
: 
(...)
onanimationiteration
: 
(...)
onanimationstart
: 
(...)
onauxclick
: 
(...)
onbeforeinput
: 
(...)
onbeforematch
: 
(...)
onbeforetoggle
: 
(...)
onbeforexrselect
: 
(...)
onblur
: 
(...)
oncancel
: 
(...)
oncanplay
: 
(...)
oncanplaythrough
: 
(...)
onchange
: 
(...)
onclick
: 
(...)
onclose
: 
(...)
oncommand
: 
(...)
oncontentvisibilityautostatechange
: 
(...)
oncontextlost
: 
(...)
oncontextmenu
: 
(...)
oncontextrestored
: 
(...)
oncopy
: 
(...)
oncuechange
: 
(...)
oncut
: 
(...)
ondblclick
: 
(...)
ondrag
: 
(...)
ondragend
: 
(...)
ondragenter
: 
(...)
ondragleave
: 
(...)
ondragover
: 
(...)
ondragstart
: 
(...)
ondrop
: 
(...)
ondurationchange
: 
(...)
onemptied
: 
(...)
onended
: 
(...)
onerror
: 
(...)
onfocus
: 
(...)
onformdata
: 
(...)
ongotpointercapture
: 
(...)
oninput
: 
(...)
oninvalid
: 
(...)
onkeydown
: 
(...)
onkeypress
: 
(...)
onkeyup
: 
(...)
onload
: 
(...)
onloadeddata
: 
(...)
onloadedmetadata
: 
(...)
onloadstart
: 
(...)
onlostpointercapture
: 
(...)
onmousedown
: 
(...)
onmouseenter
: 
undefined
onmouseleave
: 
undefined
onmousemove
: 
(...)
onmouseout
: 
(...)
onmouseover
: 
(...)
onmouseup
: 
(...)
onmousewheel
: 
(...)
onoverscroll
: 
(...)
onpaste
: 
(...)
onpause
: 
(...)
onplay
: 
(...)
onplaying
: 
(...)
onpointercancel
: 
(...)
onpointerdown
: 
(...)
onpointerenter
: 
(...)
onpointerleave
: 
(...)
onpointermove
: 
(...)
onpointerout
: 
(...)
onpointerover
: 
(...)
onpointerrawupdate
: 
(...)
onpointerup
: 
(...)
onprogress
: 
(...)
onratechange
: 
(...)
onreset
: 
(...)
onresize
: 
(...)
onscroll
: 
(...)
onscrollend
: 
(...)
onscrollsnapchange
: 
(...)
onscrollsnapchanging
: 
(...)
onsecuritypolicyviolation
: 
(...)
onseeked
: 
(...)
onseeking
: 
(...)
onselect
: 
(...)
onselectionchange
: 
(...)
onselectstart
: 
(...)
onslotchange
: 
(...)
onstalled
: 
(...)
onsubmit
: 
(...)
onsuspend
: 
(...)
ontimeupdate
: 
(...)
ontoggle
: 
(...)
ontransitioncancel
: 
(...)
ontransitionend
: 
(...)
ontransitionrun
: 
(...)
ontransitionstart
: 
(...)
onvolumechange
: 
(...)
onwaiting
: 
(...)
onwebkitanimationend
: 
(...)
onwebkitanimationiteration
: 
(...)
onwebkitanimationstart
: 
(...)
onwebkittransitionend
: 
(...)
onwheel
: 
(...)
outerText
: 
(...)
popover
: 
(...)
scrollParent
: 
(...)
showPopover
: 
ƒ showPopover()
spellcheck
: 
(...)
style
: 
(...)
tabIndex
: 
(...)
title
: 
(...)
togglePopover
: 
ƒ togglePopover()
translate
: 
(...)
virtualKeyboardPolicy
: 
(...)
writingSuggestions
: 
(...)
constructor
: 
ƒ HTMLElement()
Symbol(Symbol.toStringTag)
: 
"HTMLElement"
anchorElement
: 
(...)
ariaActiveDescendantElement
: 
(...)
ariaAtomic
: 
(...)
ariaAutoComplete
: 
(...)
ariaBrailleLabel
: 
(...)
ariaBrailleRoleDescription
: 
(...)
ariaBusy
: 
(...)
ariaChecked
: 
(...)
ariaColCount
: 
(...)
ariaColIndex
: 
(...)
ariaColIndexText
: 
(...)
ariaColSpan
: 
(...)
ariaControlsElements
: 
(...)
ariaCurrent
: 
(...)
ariaDescribedByElements
: 
(...)
ariaDescription
: 
(...)
ariaDetailsElements
: 
(...)
ariaDisabled
: 
(...)
ariaErrorMessageElements
: 
(...)
ariaExpanded
: 
(...)
ariaFlowToElements
: 
(...)
ariaHasPopup
: 
(...)
ariaHidden
: 
(...)
ariaInvalid
: 
(...)
ariaKeyShortcuts
: 
(...)
ariaLabel
: 
(...)
ariaLabelledByElements
: 
(...)
ariaLevel
: 
(...)
ariaLive
: 
(...)
ariaModal
: 
(...)
ariaMultiLine
: 
(...)
ariaMultiSelectable
: 
(...)
ariaOrientation
: 
(...)
ariaOwnsElements
: 
(...)
ariaPlaceholder
: 
(...)
ariaPosInSet
: 
(...)
ariaPressed
: 
(...)
ariaReadOnly
: 
(...)
ariaRelevant
: 
(...)
ariaRequired
: 
(...)
ariaRoleDescription
: 
(...)
ariaRowCount
: 
(...)
ariaRowIndex
: 
(...)
ariaRowIndexText
: 
(...)
ariaRowSpan
: 
(...)
ariaSelected
: 
(...)
ariaSetSize
: 
(...)
ariaSort
: 
(...)
ariaValueMax
: 
(...)
ariaValueMin
: 
(...)
ariaValueNow
: 
(...)
ariaValueText
: 
(...)
ariaVirtualContent
: 
(...)
assignedSlot
: 
(...)
attributes
: 
(...)
baseURI
: 
(...)
childElementCount
: 
(...)
childNodes
: 
(...)
children
: 
(...)
classList
: 
(...)
className
: 
(...)
clientHeight
: 
(...)
clientLeft
: 
(...)
clientTop
: 
(...)
clientWidth
: 
(...)
computedName
: 
(...)
computedRole
: 
(...)
containerTiming
: 
(...)
containerTimingIgnore
: 
(...)
currentCSSZoom
: 
(...)
elementTiming
: 
(...)
firstChild
: 
(...)
firstElementChild
: 
(...)
headingOffset
: 
(...)
headingReset
: 
(...)
id
: 
(...)
innerHTML
: 
(...)
isConnected
: 
(...)
lastChild
: 
(...)
lastElementChild
: 
(...)
localName
: 
(...)
namespaceURI
: 
(...)
nextElementSibling
: 
(...)
nextSibling
: 
(...)
nodeName
: 
(...)
nodeType
: 
(...)
nodeValue
: 
(...)
onbeforecopy
: 
(...)
onbeforecut
: 
(...)
onbeforepaste
: 
(...)
onfullscreenchange
: 
(...)
onfullscreenerror
: 
(...)
onsearch
: 
(...)
onwebkitfullscreenchange
: 
(...)
onwebkitfullscreenerror
: 
(...)
outerHTML
: 
(...)
ownerDocument
: 
(...)
parentElement
: 
(...)
parentNode
: 
(...)
part
: 
(...)
prefix
: 
(...)
previousElementSibling
: 
null
previousSibling
: 
comment
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
" so don't mark it with direction or language attributes. "
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
57
nextElementSibling
: 
html
nextSibling
: 
html
nodeName
: 
"#comment"
nodeType
: 
8
nodeValue
: 
" so don't mark it with direction or language attributes. "
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
URL
: 
"chrome://flags/"
activeElement
: 
body
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(11) [html, head, meta, meta, meta, link, title, style, body, script, flags-app, color-scheme: meta, viewport: meta]
anchors
: 
HTMLCollection []
applets
: 
HTMLCollection []
baseURI
: 
"chrome://flags/"
bgColor
: 
""
body
: 
body
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(4) [<!DOCTYPE html>, comment, comment, html]
children
: 
HTMLCollection [html]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
""
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
""
doctype
: 
<!DOCTYPE html>
documentElement
: 
html
documentURI
: 
"chrome://flags/"
domain
: 
"flags"
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
name
: 
"html"
nextSibling
: 
comment
nodeName
: 
"html"
nodeType
: 
10
nodeValue
: 
null
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
URL
: 
"chrome://flags/"
activeElement
: 
body
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(11) [html, head, meta, meta, meta, link, title, style, body, script, flags-app, color-scheme: meta, viewport: meta]
anchors
: 
HTMLCollection []
applets
: 
HTMLCollection []
baseURI
: 
"chrome://flags/"
bgColor
: 
""
body
: 
body
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(4) [<!DOCTYPE html>, comment, comment, html]
children
: 
HTMLCollection(1)
0
: 
html
length
: 
1
[[Prototype]]
: 
HTMLCollection
item
: 
ƒ item()
length
: 
(...)
namedItem
: 
ƒ namedItem()
constructor
: 
ƒ HTMLCollection()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.toStringTag)
: 
"HTMLCollection"
get length
: 
ƒ length()
[[Prototype]]
: 
Object
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
""
currentScript
: 
null
defaultView
: 
Window
alert
: 
ƒ alert()
length
: 
0
name
: 
"alert"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
atob
: 
ƒ atob()
length
: 
1
name
: 
"atob"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
blur
: 
ƒ blur()
length
: 
0
name
: 
"blur"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
btoa
: 
ƒ btoa()
length
: 
1
name
: 
"btoa"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caches
: 
CacheStorage
[[Prototype]]
: 
CacheStorage
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
length
: 
1
name
: 
"cancelAnimationFrame"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
cancelIdleCallback
: 
ƒ cancelIdleCallback()
length
: 
1
name
: 
"cancelIdleCallback"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
captureEvents
: 
ƒ captureEvents()
length
: 
0
name
: 
"captureEvents"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
chrome
: 
csi
: 
ƒ ()
getVariableValue
: 
ƒ ()
loadTimes
: 
ƒ ()
perplexity
: 
Object
analytics
: 
{recordEvent: ƒ}
blacklist
: 
{BlacklistSource: {…}, isDomainInBlacklist: ƒ}
shortcuts
: 
{Modifier: {…}, Source: {…}, clearShortcut: ƒ, getCurrentShortcuts: ƒ, setShortcut: ƒ}
system
: 
ExtensionInstallResult
: 
ABORTED
: 
"Aborted"
BLOCKED_BY_POLICY
: 
"BlockedByPolicy"
BLOCKLISTED
: 
"Blocklisted"
ICON_ERROR
: 
"IconError"
INSTALL_IN_PROGRESS
: 
"InstallInProgress"
INVALID_ID
: 
"InvalidId"
INVALID_MANIFEST
: 
"InvalidManifest"
INVALID_WEBSTORE_RESPONSE
: 
"InvalidWebstoreResponse"
LAUNCH_FEATURE_DISABLED
: 
"LaunchFeatureDisabled"
LAUNCH_IN_PROGRESS
: 
"LaunchInProgress"
LAUNCH_UNSUPPORTED_EXTENSION_TYPE
: 
"LaunchUnsupportedExtensionType"
MISSING_DEPENDENCIES
: 
"MissingDependencies"
NOT_PERMITTED
: 
"NotPermitted"
OTHER_ERROR
: 
"OtherError"
REQUIREMENT_VIOLATIONS
: 
"RequirementViolations"
SUCCESS
: 
"Success"
USER_CANCELLED
: 
"UserCancelled"
WEBSTORE_REQUEST_ERROR
: 
"WebstoreRequestError"
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
ExtensionUpdatePriority
: 
BACKGROUND
: 
"background"
FOREGROUND
: 
"foreground"
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
length
: 
1
name
: 
"__lookupSetter__"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at __lookupSetter__.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at __lookupSetter__.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at __lookupSetter__.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at __lookupSetter__.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
__proto__
: 
Object
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
Representation
: 
HEX
: 
"hex"
RGB
: 
"rgb"
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
Theme
: 
DARK
: 
"dark"
DEVICE
: 
"device"
LIGHT
: 
"light"
[[Prototype]]
: 
Object
bringWindowToTop
: 
ƒ bringWindowToTop()
length
: 
0
name
: 
"bringWindowToTop"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bringWindowToTop.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bringWindowToTop.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getBrowserPath
: 
ƒ getBrowserPath()
length
: 
0
name
: 
"getBrowserPath"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getCPUArchitecture
: 
ƒ getCPUArchitecture()
length
: 
0
name
: 
"getCPUArchitecture"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getChannel
: 
ƒ getChannel()
length
: 
0
name
: 
"getChannel"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getCurrentColorTheme
: 
ƒ getCurrentColorTheme()
length
: 
0
name
: 
"getCurrentColorTheme"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getCurrentColorThemeName
: 
ƒ getCurrentColorThemeName()
length
: 
0
name
: 
"getCurrentColorThemeName"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getCurrentTheme
: 
ƒ getCurrentTheme()
length
: 
0
name
: 
"getCurrentTheme"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getCurrentThemeSetting
: 
ƒ getCurrentThemeSetting()
length
: 
0
name
: 
"getCurrentThemeSetting"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getInstallationId
: 
ƒ getInstallationId()
length
: 
0
name
: 
"getInstallationId"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getMachineId
: 
ƒ getMachineId()
length
: 
0
name
: 
"getMachineId"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getProductVersion
: 
ƒ getProductVersion()
length
: 
0
name
: 
"getProductVersion"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
installExtension
: 
ƒ installExtension()
length
: 
0
name
: 
"installExtension"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
isBrowserCrashedLastTime
: 
ƒ isBrowserCrashedLastTime()
length
: 
0
name
: 
"isBrowserCrashedLastTime"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
isPerplexityDefaultBrowser
: 
ƒ isPerplexityDefaultBrowser()
length
: 
0
name
: 
"isPerplexityDefaultBrowser"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
onCurrentColorThemeChanged
: 
(...)
onCurrentThemeChanged
: 
(...)
onPing
: 
(...)
pong
: 
ƒ pong()
setCurrentTheme
: 
ƒ setCurrentTheme()
setPerplexityAsDefaultBrowser
: 
ƒ setPerplexityAsDefaultBrowser()
startVoiceInput
: 
ƒ startVoiceInput()
updateExtensions
: 
ƒ updateExtensions()
get onCurrentColorThemeChanged
: 
ƒ ()
set onCurrentColorThemeChanged
: 
ƒ ()
get onCurrentThemeChanged
: 
ƒ ()
set onCurrentThemeChanged
: 
ƒ ()
get onPing
: 
ƒ ()
set onPing
: 
ƒ ()
[[Prototype]]
: 
Object
[[Prototype]]
: 
Object
runtime
: 
Object
send
: 
ƒ ()
timeTicks
: 
{nowInMicroseconds: ƒ}
get perplexity
: 
ƒ ()
set perplexity
: 
ƒ ()
get runtime
: 
ƒ ()
set runtime
: 
ƒ ()
[[Prototype]]
: 
Object
clearInterval
: 
ƒ clearInterval()
length
: 
0
name
: 
"clearInterval"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clearTimeout
: 
ƒ clearTimeout()
length
: 
0
name
: 
"clearTimeout"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clientInformation
: 
Navigator
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth {onadvertisementreceived: null}
clipboard
: 
Clipboard {}
connection
: 
NetworkInformation {onchange: null, effectiveType: '4g', rtt: 50, downlink: 10, saveData: false, …}
cookieEnabled
: 
true
credentials
: 
CredentialsContainer {}
deprecatedRunAdAuctionEnforcesKAnonymity
: 
false
deviceMemory
: 
8
devicePosture
: 
DevicePosture {type: 'continuous', onchange: null}
doNotTrack
: 
null
geolocation
: 
Geolocation {}
gpu
: 
GPU {wgslLanguageFeatures: WGSLLanguageFeatures}
hardwareConcurrency
: 
8
hid
: 
HID {onconnect: null, ondisconnect: null}
identity
: 
CredentialsContainer {}
ink
: 
Ink {}
keyboard
: 
Keyboard {}
language
: 
"en-US"
languages
: 
(2) ['en-US', 'en']
locks
: 
LockManager {}
login
: 
NavigatorLogin {}
managed
: 
NavigatorManagedData {onmanagedconfigurationchange: null}
maxTouchPoints
: 
0
mediaCapabilities
: 
MediaCapabilities {}
mediaDevices
: 
MediaDevices {ondevicechange: null}
mediaSession
: 
MediaSession {metadata: null, playbackState: 'none'}
mimeTypes
: 
MimeTypeArray {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, length: 2}
onLine
: 
true
pdfViewerEnabled
: 
true
permissions
: 
Permissions {}
platform
: 
"Win32"
plugins
: 
PluginArray {0: Plugin, 1: Plugin, 2: Plugin, 3: Plugin, 4: Plugin, PDF Viewer: Plugin, Chrome PDF Viewer: Plugin, Chromium PDF Viewer: Plugin, Microsoft Edge PDF Viewer: Plugin, WebKit built-in PDF: Plugin, …}
preferences
: 
PreferenceManager {colorScheme: PreferenceObject, contrast: PreferenceObject, reducedMotion: PreferenceObject, reducedTransparency: PreferenceObject, reducedData: PreferenceObject}
presentation
: 
Presentation {defaultRequest: null, receiver: null}
product
: 
"Gecko"
productSub
: 
"20030107"
protectedAudience
: 
ProtectedAudience {}
scheduling
: 
Scheduling {}
serial
: 
Serial {onconnect: null, ondisconnect: null}
serviceWorker
: 
ServiceWorkerContainer {controller: null, ready: Promise, oncontrollerchange: null, onmessage: null, onmessageerror: null}
storage
: 
StorageManager {}
storageBuckets
: 
StorageBucketManager {}
usb
: 
USB {onconnect: null, ondisconnect: null}
userActivation
: 
UserActivation {hasBeenActive: true, isActive: false}
userAgent
: 
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
userAgentData
: 
NavigatorUAData {brands: Array(3), mobile: false, platform: 'Windows'}
vendor
: 
"Google Inc."
vendorSub
: 
""
virtualKeyboard
: 
VirtualKeyboard {boundingRect: DOMRect, overlaysContent: false, ongeometrychange: null}
wakeLock
: 
WakeLock {}
webdriver
: 
false
webkitPersistentStorage
: 
DeprecatedStorageQuota {}
webkitTemporaryStorage
: 
DeprecatedStorageQuota {}
windowControlsOverlay
: 
WindowControlsOverlay {visible: false, ongeometrychange: null}
xr
: 
XRSystem {ondevicechange: null}
[[Prototype]]
: 
Navigator
close
: 
ƒ close()
length
: 
0
name
: 
"close"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
closed
: 
false
confirm
: 
ƒ confirm()
cookieStore
: 
CookieStore {onchange: null}
cr
: 
{webUIResponse: ƒ, webUIListenerCallback: ƒ}
createImageBitmap
: 
ƒ createImageBitmap()
credentialless
: 
false
crossOriginIsolated
: 
false
crypto
: 
Crypto {subtle: SubtleCrypto}
customElements
: 
CustomElementRegistry {}
devicePixelRatio
: 
0.75
document
: 
document
documentPictureInPicture
: 
DocumentPictureInPicture {window: null, onenter: null}
event
: 
undefined
external
: 
External {}
fence
: 
null
fetch
: 
ƒ fetch()
fetchLater
: 
ƒ fetchLater()
find
: 
ƒ find()
focus
: 
ƒ focus()
frameElement
: 
null
frames
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
getComputedStyle
: 
ƒ getComputedStyle()
getScreenDetails
: 
ƒ getScreenDetails()
getSelection
: 
ƒ getSelection()
history
: 
History {length: 2, scrollRestoration: 'auto', state: null}
indexedDB
: 
IDBFactory {}
innerHeight
: 
2109
innerWidth
: 
2689
isSecureContext
: 
true
launchQueue
: 
LaunchQueue {}
length
: 
0
litElementVersions
: 
['4.2.0']
litHtmlVersions
: 
Array(1)
0
: 
"3.3.0"
length
: 
1
[[Prototype]]
: 
Array(0)
litPropertyMetadata
: 
WeakMap
[[Entries]]
No properties
[[Prototype]]
: 
WeakMap
localStorage
: 
Storage
length
: 
0
[[Prototype]]
: 
Storage
location
: 
Location
ancestorOrigins
: 
DOMStringList
length
: 
0
[[Prototype]]
: 
DOMStringList
assign
: 
ƒ assign()
length
: 
1
name
: 
"assign"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
hash
: 
""
host
: 
"flags"
hostname
: 
"flags"
href
: 
"chrome://flags/"
origin
: 
"chrome://flags"
pathname
: 
"/"
port
: 
""
protocol
: 
"chrome:"
reload
: 
ƒ reload()
length
: 
0
name
: 
"reload"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
replace
: 
ƒ replace()
length
: 
1
name
: 
"replace"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
search
: 
""
toString
: 
ƒ toString()
length
: 
0
name
: 
"toString"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
valueOf
: 
ƒ valueOf()
length
: 
0
name
: 
"valueOf"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.toPrimitive)
: 
undefined
[[Prototype]]
: 
Location
locationbar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
matchMedia
: 
ƒ matchMedia()
length
: 
1
name
: 
"matchMedia"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
menubar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
moveBy
: 
ƒ moveBy()
length
: 
2
name
: 
"moveBy"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
moveTo
: 
ƒ moveTo()
length
: 
2
name
: 
"moveTo"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
name
: 
""
navigation
: 
Navigation
activation
: 
NavigationActivation {entry: NavigationHistoryEntry, from: NavigationHistoryEntry, navigationType: 'traverse'}
canGoBack
: 
false
canGoForward
: 
false
currentEntry
: 
NavigationHistoryEntry {key: 'b4581bbd-628b-4b66-8c1a-b983f0325c4f', id: 'd029303d-ddb4-4d96-9aca-8f2c7e62109f', url: 'chrome://flags/', index: 0, sameDocument: true, …}
oncurrententrychange
: 
null
onnavigate
: 
null
onnavigateerror
: 
null
onnavigatesuccess
: 
null
transition
: 
null
[[Prototype]]
: 
Navigation
navigator
: 
Navigator
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth {onadvertisementreceived: null}
clipboard
: 
Clipboard {}
connection
: 
NetworkInformation {onchange: null, effectiveType: '4g', rtt: 50, downlink: 10, saveData: false, …}
cookieEnabled
: 
true
credentials
: 
CredentialsContainer {}
deprecatedRunAdAuctionEnforcesKAnonymity
: 
false
deviceMemory
: 
8
devicePosture
: 
DevicePosture {type: 'continuous', onchange: null}
doNotTrack
: 
null
geolocation
: 
Geolocation {}
gpu
: 
GPU {wgslLanguageFeatures: WGSLLanguageFeatures}
hardwareConcurrency
: 
8
hid
: 
HID {onconnect: null, ondisconnect: null}
identity
: 
CredentialsContainer {}
ink
: 
Ink {}
keyboard
: 
Keyboard {}
language
: 
"en-US"
languages
: 
(2) ['en-US', 'en']
locks
: 
LockManager {}
login
: 
NavigatorLogin {}
managed
: 
NavigatorManagedData {onmanagedconfigurationchange: null}
maxTouchPoints
: 
0
mediaCapabilities
: 
MediaCapabilities {}
mediaDevices
: 
MediaDevices {ondevicechange: null}
mediaSession
: 
MediaSession {metadata: null, playbackState: 'none'}
mimeTypes
: 
MimeTypeArray {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, length: 2}
onLine
: 
true
pdfViewerEnabled
: 
true
permissions
: 
Permissions {}
platform
: 
"Win32"
plugins
: 
PluginArray {0: Plugin, 1: Plugin, 2: Plugin, 3: Plugin, 4: Plugin, PDF Viewer: Plugin, Chrome PDF Viewer: Plugin, Chromium PDF Viewer: Plugin, Microsoft Edge PDF Viewer: Plugin, WebKit built-in PDF: Plugin, …}
preferences
: 
PreferenceManager {colorScheme: PreferenceObject, contrast: PreferenceObject, reducedMotion: PreferenceObject, reducedTransparency: PreferenceObject, reducedData: PreferenceObject}
presentation
: 
Presentation {defaultRequest: null, receiver: null}
product
: 
"Gecko"
productSub
: 
"20030107"
protectedAudience
: 
ProtectedAudience {}
scheduling
: 
Scheduling {}
serial
: 
Serial {onconnect: null, ondisconnect: null}
serviceWorker
: 
ServiceWorkerContainer {controller: null, ready: Promise, oncontrollerchange: null, onmessage: null, onmessageerror: null}
storage
: 
StorageManager {}
storageBuckets
: 
StorageBucketManager {}
usb
: 
USB
onconnect
: 
null
ondisconnect
: 
null
[[Prototype]]
: 
USB
getDevices
: 
ƒ getDevices()
onconnect
: 
null
ondisconnect
: 
null
requestDevice
: 
ƒ requestDevice()
length
: 
1
name
: 
"requestDevice"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at requestDevice.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at requestDevice.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at requestDevice.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at requestDevice.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ USB()
Symbol(Symbol.toStringTag)
: 
"USB"
get onconnect
: 
ƒ onconnect()
set onconnect
: 
ƒ onconnect()
get ondisconnect
: 
ƒ ondisconnect()
set ondisconnect
: 
ƒ ondisconnect()
[[Prototype]]
: 
EventTarget
userActivation
: 
UserActivation
hasBeenActive
: 
true
isActive
: 
false
[[Prototype]]
: 
UserActivation
hasBeenActive
: 
true
isActive
: 
false
constructor
: 
ƒ UserActivation()
Symbol(Symbol.toStringTag)
: 
"UserActivation"
get hasBeenActive
: 
ƒ hasBeenActive()
get isActive
: 
ƒ isActive()
[[Prototype]]
: 
Object
userAgent
: 
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
userAgentData
: 
NavigatorUAData
brands
: 
Array(3)
0
: 
brand
: 
"Not;A=Brand"
version
: 
"99"
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
1
: 
brand
: 
"Google Chrome"
version
: 
"139"
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
2
: 
brand
: 
"Chromium"
version
: 
"139"
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
length
: 
3
[[Prototype]]
: 
Array(0)
mobile
: 
false
platform
: 
"Windows"
[[Prototype]]
: 
NavigatorUAData
vendor
: 
"Google Inc."
vendorSub
: 
""
virtualKeyboard
: 
VirtualKeyboard
boundingRect
: 
DOMRect
bottom
: 
0
height
: 
0
left
: 
0
right
: 
0
top
: 
0
width
: 
0
x
: 
0
y
: 
0
[[Prototype]]
: 
DOMRect
ongeometrychange
: 
null
overlaysContent
: 
false
[[Prototype]]
: 
VirtualKeyboard
wakeLock
: 
WakeLock
[[Prototype]]
: 
WakeLock
webdriver
: 
false
webkitPersistentStorage
: 
DeprecatedStorageQuota
[[Prototype]]
: 
DeprecatedStorageQuota
queryUsageAndQuota
: 
ƒ queryUsageAndQuota()
requestQuota
: 
ƒ requestQuota()
Symbol(Symbol.toStringTag)
: 
"DeprecatedStorageQuota"
[[Prototype]]
: 
Object
webkitTemporaryStorage
: 
DeprecatedStorageQuota
[[Prototype]]
: 
DeprecatedStorageQuota
windowControlsOverlay
: 
WindowControlsOverlay
ongeometrychange
: 
null
visible
: 
false
[[Prototype]]
: 
WindowControlsOverlay
xr
: 
XRSystem
ondevicechange
: 
null
[[Prototype]]
: 
XRSystem
[[Prototype]]
: 
Navigator
adAuctionComponents
: 
ƒ adAuctionComponents()
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth
onadvertisementreceived
: 
null
[[Prototype]]
: 
Bluetooth
canLoadAdAuctionFencedFrame
: 
ƒ canLoadAdAuctionFencedFrame()
canShare
: 
ƒ canShare()
clearAppBadge
: 
ƒ clearAppBadge()
clearOriginJoinedAdInterestGroups
: 
ƒ clearOriginJoinedAdInterestGroups()
clipboard
: 
(...)
connection
: 
(...)
cookieEnabled
: 
(...)
createAuctionNonce
: 
ƒ createAuctionNonce()
createHandwritingRecognizer
: 
ƒ createHandwritingRecognizer()
credentials
: 
(...)
deprecatedReplaceInURN
: 
ƒ deprecatedReplaceInURN()
deprecatedRunAdAuctionEnforcesKAnonymity
: 
(...)
deprecatedURNToURL
: 
ƒ deprecatedURNToURL()
deviceMemory
: 
(...)
devicePosture
: 
(...)
doNotTrack
: 
(...)
geolocation
: 
(...)
getBattery
: 
ƒ getBattery()
getGamepads
: 
ƒ getGamepads()
getInstalledRelatedApps
: 
ƒ getInstalledRelatedApps()
getInterestGroupAdAuctionData
: 
ƒ getInterestGroupAdAuctionData()
getUserMedia
: 
ƒ getUserMedia()
gpu
: 
(...)
hardwareConcurrency
: 
(...)
hid
: 
(...)
identity
: 
(...)
ink
: 
(...)
install
: 
ƒ install()
javaEnabled
: 
ƒ javaEnabled()
joinAdInterestGroup
: 
ƒ joinAdInterestGroup()
keyboard
: 
(...)
language
: 
(...)
languages
: 
(...)
leaveAdInterestGroup
: 
ƒ leaveAdInterestGroup()
locks
: 
(...)
login
: 
(...)
managed
: 
(...)
maxTouchPoints
: 
(...)
mediaCapabilities
: 
(...)
mediaDevices
: 
(...)
mediaSession
: 
(...)
mimeTypes
: 
(...)
onLine
: 
(...)
pdfViewerEnabled
: 
(...)
permissions
: 
(...)
platform
: 
(...)
plugins
: 
(...)
preferences
: 
(...)
presentation
: 
(...)
product
: 
(...)
productSub
: 
(...)
protectedAudience
: 
(...)
queryHandwritingRecognizer
: 
ƒ queryHandwritingRecognizer()
registerProtocolHandler
: 
ƒ registerProtocolHandler()
requestMIDIAccess
: 
ƒ requestMIDIAccess()
requestMediaKeySystemAccess
: 
ƒ requestMediaKeySystemAccess()
runAdAuction
: 
ƒ runAdAuction()
scheduling
: 
(...)
sendBeacon
: 
ƒ sendBeacon()
serial
: 
(...)
serviceWorker
: 
(...)
setAppBadge
: 
ƒ setAppBadge()
share
: 
ƒ share()
storage
: 
(...)
storageBuckets
: 
(...)
unregisterProtocolHandler
: 
ƒ unregisterProtocolHandler()
updateAdInterestGroups
: 
ƒ updateAdInterestGroups()
usb
: 
(...)
userActivation
: 
(...)
userAgent
: 
(...)
userAgentData
: 
(...)
vendor
: 
(...)
vendorSub
: 
(...)
vibrate
: 
ƒ vibrate()
virtualKeyboard
: 
VirtualKeyboard
boundingRect
: 
DOMRect
bottom
: 
0
height
: 
0
left
: 
0
right
: 
0
top
: 
0
width
: 
0
x
: 
0
y
: 
0
[[Prototype]]
: 
DOMRect
ongeometrychange
: 
null
overlaysContent
: 
false
[[Prototype]]
: 
VirtualKeyboard
boundingRect
: 
(...)
hide
: 
ƒ hide()
length
: 
0
name
: 
"hide"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
ongeometrychange
: 
(...)
overlaysContent
: 
(...)
show
: 
ƒ show()
length
: 
0
name
: 
"show"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ VirtualKeyboard()
Symbol(Symbol.toStringTag)
: 
"VirtualKeyboard"
get boundingRect
: 
ƒ boundingRect()
get ongeometrychange
: 
ƒ ongeometrychange()
set ongeometrychange
: 
ƒ ongeometrychange()
get overlaysContent
: 
ƒ overlaysContent()
set overlaysContent
: 
ƒ overlaysContent()
[[Prototype]]
: 
EventTarget
addEventListener
: 
ƒ addEventListener()
dispatchEvent
: 
ƒ dispatchEvent()
removeEventListener
: 
ƒ removeEventListener()
when
: 
ƒ when()
constructor
: 
ƒ EventTarget()
Symbol(Symbol.toStringTag)
: 
"EventTarget"
[[Prototype]]
: 
Object
wakeLock
: 
WakeLock
webdriver
: 
false
webkitGetUserMedia
: 
ƒ webkitGetUserMedia()
webkitPersistentStorage
: 
DeprecatedStorageQuota
[[Prototype]]
: 
DeprecatedStorageQuota
webkitTemporaryStorage
: 
DeprecatedStorageQuota
[[Prototype]]
: 
DeprecatedStorageQuota
windowControlsOverlay
: 
WindowControlsOverlay
ongeometrychange
: 
null
visible
: 
false
[[Prototype]]
: 
WindowControlsOverlay
xr
: 
XRSystem
ondevicechange
: 
null
[[Prototype]]
: 
XRSystem
isSessionSupported
: 
ƒ isSessionSupported()
ondevicechange
: 
null
requestSession
: 
ƒ requestSession()
constructor
: 
ƒ XRSystem()
length
: 
0
name
: 
"XRSystem"
prototype
: 
XRSystem {Symbol(Symbol.toStringTag): 'XRSystem', isSessionSupported: ƒ, requestSession: ƒ}
arguments
: 
null
caller
: 
null
[[Prototype]]
: 
ƒ EventTarget()
length
: 
0
name
: 
"EventTarget"
prototype
: 
EventTarget {Symbol(Symbol.toStringTag): 'EventTarget', addEventListener: ƒ, dispatchEvent: ƒ, removeEventListener: ƒ, when: ƒ}
arguments
: 
null
caller
: 
null
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.toStringTag)
: 
"XRSystem"
get ondevicechange
: 
ƒ ondevicechange()
set ondevicechange
: 
ƒ ondevicechange()
[[Prototype]]
: 
EventTarget
addEventListener
: 
ƒ addEventListener()
length
: 
2
name
: 
"addEventListener"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
dispatchEvent
: 
ƒ dispatchEvent()
length
: 
1
name
: 
"dispatchEvent"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at dispatchEvent.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at dispatchEvent.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
removeEventListener
: 
ƒ removeEventListener()
length
: 
2
name
: 
"removeEventListener"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
when
: 
ƒ when()
length
: 
1
name
: 
"when"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at when.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at when.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ EventTarget()
length
: 
0
name
: 
"EventTarget"
prototype
: 
EventTarget
addEventListener
: 
ƒ addEventListener()
length
: 
2
name
: 
"addEventListener"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at addEventListener.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at addEventListener.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
dispatchEvent
: 
ƒ dispatchEvent()
length
: 
1
name
: 
"dispatchEvent"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at dispatchEvent.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at dispatchEvent.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
removeEventListener
: 
ƒ removeEventListener()
length
: 
2
name
: 
"removeEventListener"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
when
: 
ƒ when()
length
: 
1
name
: 
"when"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ EventTarget()
Symbol(Symbol.toStringTag)
: 
"EventTarget"
[[Prototype]]
: 
Object
arguments
: 
null
caller
: 
null
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.toStringTag)
: 
"EventTarget"
[[Prototype]]
: 
Object
constructor
: 
ƒ Navigator()
Symbol(Symbol.toStringTag)
: 
"Navigator"
get appCodeName
: 
ƒ appCodeName()
length
: 
0
name
: 
"get appCodeName"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get appName
: 
ƒ appName()
length
: 
0
name
: 
"get appName"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get appVersion
: 
ƒ appVersion()
length
: 
0
name
: 
"get appVersion"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get bluetooth
: 
ƒ bluetooth()
length
: 
0
name
: 
"get bluetooth"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get clipboard
: 
ƒ clipboard()
length
: 
0
name
: 
"get clipboard"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get connection
: 
ƒ connection()
length
: 
0
name
: 
"get connection"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get cookieEnabled
: 
ƒ cookieEnabled()
length
: 
0
name
: 
"get cookieEnabled"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get credentials
: 
ƒ credentials()
length
: 
0
name
: 
"get credentials"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get deprecatedRunAdAuctionEnforcesKAnonymity
: 
ƒ deprecatedRunAdAuctionEnforcesKAnonymity()
length
: 
0
name
: 
"get deprecatedRunAdAuctionEnforcesKAnonymity"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get deviceMemory
: 
ƒ deviceMemory()
length
: 
0
name
: 
"get deviceMemory"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get devicePosture
: 
ƒ devicePosture()
length
: 
0
name
: 
"get devicePosture"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get doNotTrack
: 
ƒ doNotTrack()
length
: 
0
name
: 
"get doNotTrack"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get geolocation
: 
ƒ geolocation()
length
: 
0
name
: 
"get geolocation"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get gpu
: 
ƒ gpu()
length
: 
0
name
: 
"get gpu"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get hardwareConcurrency
: 
ƒ hardwareConcurrency()
length
: 
0
name
: 
"get hardwareConcurrency"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get hid
: 
ƒ hid()
length
: 
0
name
: 
"get hid"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at get hid.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at get hid.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
1
name
: 
"Function"
prototype
: 
ƒ ()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
get identity
: 
ƒ identity()
length
: 
0
name
: 
"get identity"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get ink
: 
ƒ ink()
length
: 
0
name
: 
"get ink"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get keyboard
: 
ƒ keyboard()
length
: 
0
name
: 
"get keyboard"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get language
: 
ƒ language()
length
: 
0
name
: 
"get language"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get languages
: 
ƒ languages()
length
: 
0
name
: 
"get languages"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get locks
: 
ƒ locks()
length
: 
0
name
: 
"get locks"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get login
: 
ƒ login()
length
: 
0
name
: 
"get login"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get managed
: 
ƒ managed()
length
: 
0
name
: 
"get managed"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get maxTouchPoints
: 
ƒ maxTouchPoints()
length
: 
0
name
: 
"get maxTouchPoints"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get mediaCapabilities
: 
ƒ mediaCapabilities()
length
: 
0
name
: 
"get mediaCapabilities"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get mediaDevices
: 
ƒ mediaDevices()
length
: 
0
name
: 
"get mediaDevices"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get mediaSession
: 
ƒ mediaSession()
length
: 
0
name
: 
"get mediaSession"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get mimeTypes
: 
ƒ mimeTypes()
length
: 
0
name
: 
"get mimeTypes"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get onLine
: 
ƒ onLine()
length
: 
0
name
: 
"get onLine"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get pdfViewerEnabled
: 
ƒ pdfViewerEnabled()
length
: 
0
name
: 
"get pdfViewerEnabled"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get permissions
: 
ƒ permissions()
length
: 
0
name
: 
"get permissions"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get platform
: 
ƒ platform()
length
: 
0
name
: 
"get platform"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get plugins
: 
ƒ plugins()
length
: 
0
name
: 
"get plugins"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get preferences
: 
ƒ preferences()
length
: 
0
name
: 
"get preferences"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get presentation
: 
ƒ presentation()
length
: 
0
name
: 
"get presentation"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get product
: 
ƒ product()
length
: 
0
name
: 
"get product"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get productSub
: 
ƒ productSub()
length
: 
0
name
: 
"get productSub"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get protectedAudience
: 
ƒ protectedAudience()
length
: 
0
name
: 
"get protectedAudience"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get scheduling
: 
ƒ scheduling()
length
: 
0
name
: 
"get scheduling"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get serial
: 
ƒ serial()
length
: 
0
name
: 
"get serial"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get serviceWorker
: 
ƒ serviceWorker()
length
: 
0
name
: 
"get serviceWorker"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get storage
: 
ƒ storage()
length
: 
0
name
: 
"get storage"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get storageBuckets
: 
ƒ storageBuckets()
length
: 
0
name
: 
"get storageBuckets"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get usb
: 
ƒ usb()
length
: 
0
name
: 
"get usb"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get userActivation
: 
ƒ userActivation()
length
: 
0
name
: 
"get userActivation"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get userAgent
: 
ƒ userAgent()
length
: 
0
name
: 
"get userAgent"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get userAgentData
: 
ƒ userAgentData()
length
: 
0
name
: 
"get userAgentData"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get vendor
: 
ƒ vendor()
length
: 
0
name
: 
"get vendor"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get vendorSub
: 
ƒ vendorSub()
length
: 
0
name
: 
"get vendorSub"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get virtualKeyboard
: 
ƒ virtualKeyboard()
length
: 
0
name
: 
"get virtualKeyboard"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get wakeLock
: 
ƒ wakeLock()
length
: 
0
name
: 
"get wakeLock"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get webdriver
: 
ƒ webdriver()
length
: 
0
name
: 
"get webdriver"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get webkitPersistentStorage
: 
ƒ webkitPersistentStorage()
length
: 
0
name
: 
"get webkitPersistentStorage"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get webkitTemporaryStorage
: 
ƒ webkitTemporaryStorage()
length
: 
0
name
: 
"get webkitTemporaryStorage"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get windowControlsOverlay
: 
ƒ windowControlsOverlay()
length
: 
0
name
: 
"get windowControlsOverlay"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get xr
: 
ƒ xr()
length
: 
0
name
: 
"get xr"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onappinstalled
: 
null
onauxclick
: 
null
onbeforeinput
: 
null
onbeforeinstallprompt
: 
null
onbeforematch
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncuechange
: 
null
ondblclick
: 
null
ondevicemotion
: 
null
ondeviceorientation
: 
null
ondeviceorientationabsolute
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpagereveal
: 
null
onpageshow
: 
null
onpageswap
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onpopstate
: 
null
onprogress
: 
null
onratechange
: 
null
onrejectionhandled
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onstorage
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontimezonechange
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onunhandledrejection
: 
null
onunload
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
open
: 
ƒ open()
length
: 
0
name
: 
"open"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at open.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at open.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at open.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at open.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
length
: 
1
name
: 
"[Symbol.hasInstance]"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
length
: 
1
name
: 
"set arguments"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get caller
: 
ƒ caller()
length
: 
0
name
: 
"get caller"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set caller
: 
ƒ caller()
length
: 
1
name
: 
"set caller"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
opener
: 
null
origin
: 
"chrome://flags"
originAgentCluster
: 
false
outerHeight
: 
1752
outerWidth
: 
3200
pageXOffset
: 
0
pageYOffset
: 
0
parent
: 
Window
alert
: 
ƒ alert()
atob
: 
ƒ atob()
blur
: 
ƒ blur()
btoa
: 
ƒ btoa()
caches
: 
CacheStorage {}
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
captureEvents
: 
ƒ captureEvents()
chrome
: 
{perplexity: {…}, runtime: {…}, loadTimes: ƒ, csi: ƒ, send: ƒ, …}
clearInterval
: 
ƒ clearInterval()
clearTimeout
: 
ƒ clearTimeout()
clientInformation
: 
Navigator {vendorSub: '', productSub: '20030107', vendor: 'Google Inc.', maxTouchPoints: 0, scheduling: Scheduling, …}
close
: 
ƒ close()
closed
: 
false
confirm
: 
ƒ confirm()
cookieStore
: 
CookieStore {onchange: null}
cr
: 
{webUIResponse: ƒ, webUIListenerCallback: ƒ}
createImageBitmap
: 
ƒ createImageBitmap()
credentialless
: 
false
crossOriginIsolated
: 
false
crypto
: 
Crypto {subtle: SubtleCrypto}
customElements
: 
CustomElementRegistry {}
devicePixelRatio
: 
0.75
document
: 
document
documentPictureInPicture
: 
DocumentPictureInPicture {window: null, onenter: null}
event
: 
undefined
external
: 
External {}
fence
: 
null
fetch
: 
ƒ fetch()
fetchLater
: 
ƒ fetchLater()
find
: 
ƒ find()
focus
: 
ƒ focus()
frameElement
: 
null
frames
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
getComputedStyle
: 
ƒ getComputedStyle()
getScreenDetails
: 
ƒ getScreenDetails()
getSelection
: 
ƒ getSelection()
history
: 
History {length: 2, scrollRestoration: 'auto', state: null}
indexedDB
: 
IDBFactory {}
innerHeight
: 
2109
innerWidth
: 
2689
isSecureContext
: 
true
launchQueue
: 
LaunchQueue {}
length
: 
0
litElementVersions
: 
['4.2.0']
litHtmlVersions
: 
['3.3.0']
litPropertyMetadata
: 
WeakMap {}
localStorage
: 
Storage {length: 0}
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
locationbar
: 
BarProp {visible: true}
matchMedia
: 
ƒ matchMedia()
menubar
: 
BarProp {visible: true}
moveBy
: 
ƒ moveBy()
moveTo
: 
ƒ moveTo()
name
: 
""
navigation
: 
Navigation {currentEntry: NavigationHistoryEntry, transition: null, activation: NavigationActivation, canGoBack: false, canGoForward: false, …}
navigator
: 
Navigator {vendorSub: '', productSub: '20030107', vendor: 'Google Inc.', maxTouchPoints: 0, scheduling: Scheduling, …}
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onappinstalled
: 
null
onauxclick
: 
null
onbeforeinput
: 
null
onbeforeinstallprompt
: 
null
onbeforematch
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncuechange
: 
null
ondblclick
: 
null
ondevicemotion
: 
null
ondeviceorientation
: 
null
ondeviceorientationabsolute
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpagereveal
: 
null
onpageshow
: 
null
onpageswap
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onpopstate
: 
null
onprogress
: 
null
onratechange
: 
null
onrejectionhandled
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onstorage
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontimezonechange
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onunhandledrejection
: 
null
onunload
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
open
: 
ƒ open()
opener
: 
null
origin
: 
"chrome://flags"
originAgentCluster
: 
false
outerHeight
: 
1752
outerWidth
: 
3200
pageXOffset
: 
0
pageYOffset
: 
0
parent
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
performance
: 
Performance {timeOrigin: 1758565909398.9, onresourcetimingbufferfull: null, timing: PerformanceTiming, navigation: PerformanceNavigation, memory: MemoryInfo, …}
personalbar
: 
BarProp {visible: true}
popinContextType
: 
ƒ popinContextType()
popinContextTypesSupported
: 
ƒ popinContextTypesSupported()
postMessage
: 
ƒ postMessage()
print
: 
ƒ print()
privateAttribution
: 
PrivateAttribution {}
prompt
: 
ƒ prompt()
queryLocalFonts
: 
ƒ queryLocalFonts()
(...)
performance
: 
Performance
eventCounts
: 
EventCounts {size: 36}
interactionCount
: 
2
memory
: 
MemoryInfo {totalJSHeapSize: 8611686, usedJSHeapSize: 7342570, jsHeapSizeLimit: 2248146944}
navigation
: 
PerformanceNavigation {type: 0, redirectCount: 0}
onresourcetimingbufferfull
: 
null
timeOrigin
: 
1758565909398.9
timing
: 
PerformanceTiming {navigationStart: 1758565909398, unloadEventStart: 0, unloadEventEnd: 0, redirectStart: 0, redirectEnd: 0, …}
[[Prototype]]
: 
Performance
personalbar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
popinContextType
: 
ƒ popinContextType()
length
: 
0
name
: 
"popinContextType"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
popinContextTypesSupported
: 
ƒ popinContextTypesSupported()
length
: 
0
name
: 
"popinContextTypesSupported"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
postMessage
: 
ƒ postMessage()
print
: 
ƒ print()
length
: 
0
name
: 
"print"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
privateAttribution
: 
PrivateAttribution {}
prompt
: 
ƒ prompt()
length
: 
0
name
: 
"prompt"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
queryLocalFonts
: 
ƒ queryLocalFonts()
queueMicrotask
: 
ƒ queueMicrotask()
length
: 
1
name
: 
"queueMicrotask"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
reactiveElementVersions
: 
['2.1.0']
releaseEvents
: 
ƒ releaseEvents()
length
: 
0
name
: 
"releaseEvents"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
reportError
: 
ƒ reportError()
requestAnimationFrame
: 
ƒ requestAnimationFrame()
length
: 
1
name
: 
"requestAnimationFrame"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
requestIdleCallback
: 
ƒ requestIdleCallback()
resizeBy
: 
ƒ resizeBy()
length
: 
2
name
: 
"resizeBy"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
resizeTo
: 
ƒ resizeTo()
scheduler
: 
Scheduler
[[Prototype]]
: 
Scheduler
screen
: 
Screen {availWidth: 3200, availHeight: 1752, width: 3200, height: 1800, colorDepth: 30, …}
screenLeft
: 
0
screenTop
: 
0
screenX
: 
0
screenY
: 
0
scroll
: 
ƒ scroll()
scrollBy
: 
ƒ scrollBy()
length
: 
0
name
: 
"scrollBy"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
scrollTo
: 
ƒ scrollTo()
scrollX
: 
0
scrollY
: 
0
scrollbars
: 
BarProp {visible: true}
self
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
sessionStorage
: 
Storage
length
: 
0
[[Prototype]]
: 
Storage
setInterval
: 
ƒ setInterval()
setTimeout
: 
ƒ setTimeout()
length
: 
1
name
: 
"setTimeout"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
sharedStorage
: 
SharedStorage {worklet: SharedStorageWorklet}
showDirectoryPicker
: 
ƒ showDirectoryPicker()
length
: 
0
name
: 
"showDirectoryPicker"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
showOpenFilePicker
: 
ƒ showOpenFilePicker()
showSaveFilePicker
: 
ƒ showSaveFilePicker()
length
: 
0
name
: 
"showSaveFilePicker"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
speechSynthesis
: 
SpeechSynthesis
onvoiceschanged
: 
null
paused
: 
false
pending
: 
false
speaking
: 
false
[[Prototype]]
: 
SpeechSynthesis
status
: 
""
statusbar
: 
BarProp {visible: true}
stop
: 
ƒ stop()
length
: 
0
name
: 
"stop"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
structuredClone
: 
ƒ structuredClone()
length
: 
1
name
: 
"structuredClone"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
styleMedia
: 
StyleMedia
type
: 
"screen"
[[Prototype]]
: 
StyleMedia
toolbar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
top
: 
Window
alert
: 
ƒ alert()
atob
: 
ƒ atob()
blur
: 
ƒ blur()
length
: 
0
name
: 
"blur"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
btoa
: 
ƒ btoa()
caches
: 
CacheStorage
[[Prototype]]
: 
CacheStorage
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
length
: 
1
name
: 
"cancelIdleCallback"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
captureEvents
: 
ƒ captureEvents()
chrome
: 
csi
: 
ƒ ()
getVariableValue
: 
ƒ ()
loadTimes
: 
ƒ ()
perplexity
: 
{analytics: {…}, blacklist: {…}, shortcuts: {…}, system: {…}}
runtime
: 
{ContextType: {…}, OnInstalledReason: {…}, OnRestartRequiredReason: {…}, …}
send
: 
ƒ ()
timeTicks
: 
{nowInMicroseconds: ƒ}
[[Prototype]]
: 
Object
clearInterval
: 
ƒ clearInterval()
clearTimeout
: 
ƒ clearTimeout()
length
: 
0
name
: 
"clearTimeout"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clientInformation
: 
Navigator
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth {onadvertisementreceived: null}
clipboard
: 
Clipboard {}
connection
: 
NetworkInformation {onchange: null, effectiveType: '4g', rtt: 50, downlink: 10, saveData: false, …}
cookieEnabled
: 
true
credentials
: 
CredentialsContainer {}
deprecatedRunAdAuctionEnforcesKAnonymity
: 
false
deviceMemory
: 
8
devicePosture
: 
DevicePosture {type: 'continuous', onchange: null}
doNotTrack
: 
null
geolocation
: 
Geolocation {}
gpu
: 
GPU {wgslLanguageFeatures: WGSLLanguageFeatures}
hardwareConcurrency
: 
8
hid
: 
HID {onconnect: null, ondisconnect: null}
identity
: 
CredentialsContainer {}
ink
: 
Ink {}
keyboard
: 
Keyboard {}
language
: 
"en-US"
languages
: 
(2) ['en-US', 'en']
locks
: 
LockManager {}
login
: 
NavigatorLogin {}
managed
: 
NavigatorManagedData {onmanagedconfigurationchange: null}
maxTouchPoints
: 
0
mediaCapabilities
: 
MediaCapabilities
[[Prototype]]
: 
MediaCapabilities
mediaDevices
: 
MediaDevices {ondevicechange: null}
mediaSession
: 
MediaSession
metadata
: 
null
playbackState
: 
"none"
[[Prototype]]
: 
MediaSession
mimeTypes
: 
MimeTypeArray
0
: 
MimeType
description
: 
"Portable Document Format"
enabledPlugin
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
suffixes
: 
"pdf"
type
: 
"application/pdf"
[[Prototype]]
: 
MimeType
1
: 
MimeType
description
: 
"Portable Document Format"
enabledPlugin
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
suffixes
: 
"pdf"
type
: 
"text/pdf"
[[Prototype]]
: 
MimeType
application/pdf
: 
MimeType
description
: 
"Portable Document Format"
enabledPlugin
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
suffixes
: 
"pdf"
type
: 
"application/pdf"
[[Prototype]]
: 
MimeType
text/pdf
: 
MimeType
description
: 
"Portable Document Format"
enabledPlugin
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
suffixes
: 
"pdf"
type
: 
"text/pdf"
[[Prototype]]
: 
MimeType
length
: 
2
[[Prototype]]
: 
MimeTypeArray
onLine
: 
true
pdfViewerEnabled
: 
true
permissions
: 
Permissions
[[Prototype]]
: 
Permissions
platform
: 
"Win32"
plugins
: 
PluginArray
0
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"PDF Viewer"
[[Prototype]]
: 
Plugin
1
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"Chrome PDF Viewer"
[[Prototype]]
: 
Plugin
2
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"Chromium PDF Viewer"
[[Prototype]]
: 
Plugin
3
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"Microsoft Edge PDF Viewer"
[[Prototype]]
: 
Plugin
4
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"WebKit built-in PDF"
[[Prototype]]
: 
Plugin
Chrome PDF Viewer
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
Chromium PDF Viewer
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
Microsoft Edge PDF Viewer
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'Microsoft Edge PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
PDF Viewer
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
WebKit built-in PDF
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'WebKit built-in PDF', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
length
: 
5
[[Prototype]]
: 
PluginArray
preferences
: 
PreferenceManager {colorScheme: PreferenceObject, contrast: PreferenceObject, reducedMotion: PreferenceObject, reducedTransparency: PreferenceObject, reducedData: PreferenceObject}
presentation
: 
Presentation {defaultRequest: null, receiver: null}
product
: 
"Gecko"
productSub
: 
"20030107"
protectedAudience
: 
ProtectedAudience {}
scheduling
: 
Scheduling
[[Prototype]]
: 
Scheduling
serial
: 
Serial
onconnect
: 
null
ondisconnect
: 
null
[[Prototype]]
: 
Serial
serviceWorker
: 
ServiceWorkerContainer
controller
: 
null
oncontrollerchange
: 
null
onmessage
: 
null
onmessageerror
: 
null
ready
: 
Promise {<pending>}
[[Prototype]]
: 
ServiceWorkerContainer
storage
: 
StorageManager
[[Prototype]]
: 
StorageManager
storageBuckets
: 
StorageBucketManager
[[Prototype]]
: 
StorageBucketManager
usb
: 
USB {onconnect: null, ondisconnect: null}
userActivation
: 
UserActivation {hasBeenActive: true, isActive: false}
userAgent
: 
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
userAgentData
: 
NavigatorUAData {brands: Array(3), mobile: false, platform: 'Windows'}
vendor
: 
"Google Inc."
vendorSub
: 
""
virtualKeyboard
: 
VirtualKeyboard
boundingRect
: 
DOMRect {x: 0, y: 0, width: 0, height: 0, top: 0, …}
ongeometrychange
: 
null
overlaysContent
: 
false
[[Prototype]]
: 
VirtualKeyboard
wakeLock
: 
WakeLock
[[Prototype]]
: 
WakeLock
webdriver
: 
false
webkitPersistentStorage
: 
DeprecatedStorageQuota {}
webkitTemporaryStorage
: 
DeprecatedStorageQuota {}
windowControlsOverlay
: 
WindowControlsOverlay {visible: false, ongeometrychange: null}
xr
: 
XRSystem {ondevicechange: null}
[[Prototype]]
: 
Navigator
close
: 
ƒ close()
closed
: 
false
confirm
: 
ƒ confirm()
cookieStore
: 
CookieStore
onchange
: 
null
[[Prototype]]
: 
CookieStore
cr
: 
webUIListenerCallback
: 
ƒ webUIListenerCallback(event, ...args)
webUIResponse
: 
ƒ webUIResponse(id, isSuccess, response)
[[Prototype]]
: 
Object
createImageBitmap
: 
ƒ createImageBitmap()
credentialless
: 
false
crossOriginIsolated
: 
false
crypto
: 
Crypto
subtle
: 
SubtleCrypto {}
[[Prototype]]
: 
Crypto
customElements
: 
CustomElementRegistry {}
devicePixelRatio
: 
0.75
document
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
URL
: 
"chrome://flags/"
activeElement
: 
body
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(11) [html, head, meta, meta, meta, link, title, style, body, script, flags-app, color-scheme: meta, viewport: meta]
anchors
: 
HTMLCollection []
applets
: 
HTMLCollection []
baseURI
: 
"chrome://flags/"
bgColor
: 
""
body
: 
body
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(4) [<!DOCTYPE html>, comment, comment, html]
children
: 
HTMLCollection [html]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
""
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
""
doctype
: 
<!DOCTYPE html>
documentElement
: 
html
documentURI
: 
"chrome://flags/"
domain
: 
"flags"
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection []
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html
lastElementChild
: 
html
lastModified
: 
"09/22/2025 12:01:31"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection [script]
scrollingElement
: 
html
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, length: 2}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 1781719.95, duration: null}
title
: 
"Experiments"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
(...)
documentPictureInPicture
: 
DocumentPictureInPicture {window: null, onenter: null}
event
: 
undefined
external
: 
External {}
fence
: 
null
fetch
: 
ƒ fetch()
fetchLater
: 
ƒ fetchLater()
length
: 
1
name
: 
"fetchLater"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
find
: 
ƒ find()
length
: 
0
name
: 
"find"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
focus
: 
ƒ focus()
frameElement
: 
null
frames
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
getComputedStyle
: 
ƒ getComputedStyle()
getScreenDetails
: 
ƒ getScreenDetails()
length
: 
0
name
: 
"getScreenDetails"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getSelection
: 
ƒ getSelection()
history
: 
History
length
: 
2
scrollRestoration
: 
"auto"
state
: 
null
[[Prototype]]
: 
History
indexedDB
: 
IDBFactory
[[Prototype]]
: 
IDBFactory
innerHeight
: 
2109
innerWidth
: 
2689
isSecureContext
: 
true
launchQueue
: 
LaunchQueue
[[Prototype]]
: 
LaunchQueue
length
: 
0
litElementVersions
: 
Array(1)
0
: 
"4.2.0"
length
: 
1
[[Prototype]]
: 
Array(0)
litHtmlVersions
: 
['3.3.0']
litPropertyMetadata
: 
WeakMap
[[Entries]]
No properties
[[Prototype]]
: 
WeakMap
localStorage
: 
Storage
length
: 
0
[[Prototype]]
: 
Storage
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
locationbar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
matchMedia
: 
ƒ matchMedia()
length
: 
1
name
: 
"matchMedia"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
menubar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
moveBy
: 
ƒ moveBy()
length
: 
2
name
: 
"moveBy"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
moveTo
: 
ƒ moveTo()
length
: 
2
name
: 
"moveTo"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
name
: 
""
navigation
: 
Navigation {currentEntry: NavigationHistoryEntry, transition: null, activation: NavigationActivation, canGoBack: false, canGoForward: false, …}
navigator
: 
Navigator {vendorSub: '', productSub: '20030107', vendor: 'Google Inc.', maxTouchPoints: 0, scheduling: Scheduling, …}
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onappinstalled
: 
null
onauxclick
: 
null
onbeforeinput
: 
null
onbeforeinstallprompt
: 
null
onbeforematch
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncuechange
: 
null
ondblclick
: 
null
ondevicemotion
: 
null
ondeviceorientation
: 
null
ondeviceorientationabsolute
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpagereveal
: 
null
onpageshow
: 
null
onpageswap
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onpopstate
: 
null
onprogress
: 
null
onratechange
: 
null
onrejectionhandled
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onstorage
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontimezonechange
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onunhandledrejection
: 
null
onunload
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
open
: 
ƒ open()
opener
: 
null
origin
: 
"chrome://flags"
originAgentCluster
: 
false
outerHeight
: 
1752
outerWidth
: 
3200
pageXOffset
: 
0
pageYOffset
: 
0
parent
: 
Window
alert
: 
ƒ alert()
atob
: 
ƒ atob()
length
: 
1
name
: 
"atob"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
blur
: 
ƒ blur()
btoa
: 
ƒ btoa()
length
: 
1
name
: 
"btoa"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caches
: 
CacheStorage {}
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
length
: 
1
name
: 
"cancelIdleCallback"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
captureEvents
: 
ƒ captureEvents()
chrome
: 
csi
: 
ƒ ()
getVariableValue
: 
ƒ ()
loadTimes
: 
ƒ ()
perplexity
: 
{analytics: {…}, blacklist: {…}, shortcuts: {…}, system: {…}}
runtime
: 
{ContextType: {…}, OnInstalledReason: {…}, OnRestartRequiredReason: {…}, …}
send
: 
ƒ ()
timeTicks
: 
{nowInMicroseconds: ƒ}
[[Prototype]]
: 
Object
clearInterval
: 
ƒ clearInterval()
clearTimeout
: 
ƒ clearTimeout()
length
: 
0
name
: 
"clearTimeout"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clientInformation
: 
Navigator
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth {onadvertisementreceived: null}
clipboard
: 
Clipboard {}
connection
: 
NetworkInformation {onchange: null, effectiveType: '4g', rtt: 50, downlink: 10, saveData: false, …}
cookieEnabled
: 
true
credentials
: 
CredentialsContainer {}
deprecatedRunAdAuctionEnforcesKAnonymity
: 
false
deviceMemory
: 
8
devicePosture
: 
DevicePosture {type: 'continuous', onchange: null}
doNotTrack
: 
null
geolocation
: 
Geolocation {}
gpu
: 
GPU {wgslLanguageFeatures: WGSLLanguageFeatures}
hardwareConcurrency
: 
8
hid
: 
HID {onconnect: null, ondisconnect: null}
identity
: 
CredentialsContainer {}
ink
: 
Ink {}
keyboard
: 
Keyboard {}
language
: 
"en-US"
languages
: 
(2) ['en-US', 'en']
locks
: 
LockManager {}
login
: 
NavigatorLogin {}
managed
: 
NavigatorManagedData {onmanagedconfigurationchange: null}
maxTouchPoints
: 
0
mediaCapabilities
: 
MediaCapabilities {}
mediaDevices
: 
MediaDevices {ondevicechange: null}
mediaSession
: 
MediaSession {metadata: null, playbackState: 'none'}
mimeTypes
: 
MimeTypeArray {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, length: 2}
onLine
: 
true
pdfViewerEnabled
: 
true
permissions
: 
Permissions {}
platform
: 
"Win32"
plugins
: 
PluginArray {0: Plugin, 1: Plugin, 2: Plugin, 3: Plugin, 4: Plugin, PDF Viewer: Plugin, Chrome PDF Viewer: Plugin, Chromium PDF Viewer: Plugin, Microsoft Edge PDF Viewer: Plugin, WebKit built-in PDF: Plugin, …}
preferences
: 
PreferenceManager {colorScheme: PreferenceObject, contrast: PreferenceObject, reducedMotion: PreferenceObject, reducedTransparency: PreferenceObject, reducedData: PreferenceObject}
presentation
: 
Presentation {defaultRequest: null, receiver: null}
product
: 
"Gecko"
productSub
: 
"20030107"
protectedAudience
: 
ProtectedAudience {}
scheduling
: 
Scheduling {}
serial
: 
Serial {onconnect: null, ondisconnect: null}
serviceWorker
: 
ServiceWorkerContainer {controller: null, ready: Promise, oncontrollerchange: null, onmessage: null, onmessageerror: null}
storage
: 
StorageManager {}
storageBuckets
: 
StorageBucketManager {}
usb
: 
USB {onconnect: null, ondisconnect: null}
userActivation
: 
UserActivation {hasBeenActive: true, isActive: false}
userAgent
: 
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
userAgentData
: 
NavigatorUAData {brands: Array(3), mobile: false, platform: 'Windows'}
vendor
: 
"Google Inc."
vendorSub
: 
""
virtualKeyboard
: 
VirtualKeyboard {boundingRect: DOMRect, overlaysContent: false, ongeometrychange: null}
wakeLock
: 
WakeLock {}
webdriver
: 
false
webkitPersistentStorage
: 
DeprecatedStorageQuota {}
webkitTemporaryStorage
: 
DeprecatedStorageQuota {}
windowControlsOverlay
: 
WindowControlsOverlay {visible: false, ongeometrychange: null}
xr
: 
XRSystem {ondevicechange: null}
[[Prototype]]
: 
Navigator
close
: 
ƒ close()
closed
: 
false
confirm
: 
ƒ confirm()
length
: 
0
name
: 
"confirm"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
cookieStore
: 
CookieStore
onchange
: 
null
[[Prototype]]
: 
CookieStore
cr
: 
webUIListenerCallback
: 
ƒ webUIListenerCallback(event, ...args)
length
: 
1
name
: 
"webUIListenerCallback"
prototype
: 
{}
arguments
: 
(...)
caller
: 
(...)
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
webUIResponse
: 
ƒ webUIResponse(id, isSuccess, response)
length
: 
3
name
: 
"webUIResponse"
prototype
: 
{}
arguments
: 
(...)
caller
: 
(...)
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[2]
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
createImageBitmap
: 
ƒ createImageBitmap()
length
: 
1
name
: 
"createImageBitmap"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
credentialless
: 
false
crossOriginIsolated
: 
false
crypto
: 
Crypto {subtle: SubtleCrypto}
customElements
: 
CustomElementRegistry {}
devicePixelRatio
: 
0.75
document
: 
document
documentPictureInPicture
: 
DocumentPictureInPicture {window: null, onenter: null}
event
: 
undefined
external
: 
External {}
fence
: 
null
fetch
: 
ƒ fetch()
fetchLater
: 
ƒ fetchLater()
find
: 
ƒ find()
focus
: 
ƒ focus()
frameElement
: 
null
frames
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
getComputedStyle
: 
ƒ getComputedStyle()
getScreenDetails
: 
ƒ getScreenDetails()
getSelection
: 
ƒ getSelection()
history
: 
History {length: 2, scrollRestoration: 'auto', state: null}
indexedDB
: 
IDBFactory {}
innerHeight
: 
2109
innerWidth
: 
2689
isSecureContext
: 
true
launchQueue
: 
LaunchQueue {}
length
: 
0
litElementVersions
: 
['4.2.0']
litHtmlVersions
: 
['3.3.0']
litPropertyMetadata
: 
WeakMap {}
localStorage
: 
Storage {length: 0}
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
locationbar
: 
BarProp {visible: true}
matchMedia
: 
ƒ matchMedia()
menubar
: 
BarProp {visible: true}
moveBy
: 
ƒ moveBy()
moveTo
: 
ƒ moveTo()
name
: 
""
navigation
: 
Navigation {currentEntry: NavigationHistoryEntry, transition: null, activation: NavigationActivation, canGoBack: false, canGoForward: false, …}
navigator
: 
Navigator {vendorSub: '', productSub: '20030107', vendor: 'Google Inc.', maxTouchPoints: 0, scheduling: Scheduling, …}
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onappinstalled
: 
null
onauxclick
: 
null
onbeforeinput
: 
null
onbeforeinstallprompt
: 
null
onbeforematch
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncuechange
: 
null
ondblclick
: 
null
ondevicemotion
: 
null
ondeviceorientation
: 
null
ondeviceorientationabsolute
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpagereveal
: 
null
onpageshow
: 
null
onpageswap
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onpopstate
: 
null
onprogress
: 
null
onratechange
: 
null
onrejectionhandled
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onstorage
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontimezonechange
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onunhandledrejection
: 
null
onunload
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
open
: 
ƒ open()
opener
: 
null
origin
: 
"chrome://flags"
originAgentCluster
: 
false
outerHeight
: 
1752
outerWidth
: 
3200
pageXOffset
: 
0
pageYOffset
: 
0
parent
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
performance
: 
Performance {timeOrigin: 1758565909398.9, onresourcetimingbufferfull: null, timing: PerformanceTiming, navigation: PerformanceNavigation, memory: MemoryInfo, …}
personalbar
: 
BarProp {visible: true}
popinContextType
: 
ƒ popinContextType()
popinContextTypesSupported
: 
ƒ popinContextTypesSupported()
postMessage
: 
ƒ postMessage()
print
: 
ƒ print()
privateAttribution
: 
PrivateAttribution {}
prompt
: 
ƒ prompt()
queryLocalFonts
: 
ƒ queryLocalFonts()
(...)
performance
: 
Performance
eventCounts
: 
EventCounts {size: 36}
interactionCount
: 
2
memory
: 
MemoryInfo {totalJSHeapSize: 8087398, usedJSHeapSize: 7333298, jsHeapSizeLimit: 2248146944}
navigation
: 
PerformanceNavigation {type: 0, redirectCount: 0}
onresourcetimingbufferfull
: 
null
timeOrigin
: 
1758565909398.9
timing
: 
PerformanceTiming {navigationStart: 1758565909398, unloadEventStart: 0, unloadEventEnd: 0, redirectStart: 0, redirectEnd: 0, …}
[[Prototype]]
: 
Performance
personalbar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
popinContextType
: 
ƒ popinContextType()
length
: 
0
name
: 
"popinContextType"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
popinContextTypesSupported
: 
ƒ popinContextTypesSupported()
length
: 
0
name
: 
"popinContextTypesSupported"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
postMessage
: 
ƒ postMessage()
length
: 
1
name
: 
"postMessage"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
print
: 
ƒ print()
length
: 
0
name
: 
"print"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
privateAttribution
: 
PrivateAttribution
[[Prototype]]
: 
PrivateAttribution
prompt
: 
ƒ prompt()
length
: 
0
name
: 
"prompt"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
queryLocalFonts
: 
ƒ queryLocalFonts()
length
: 
0
name
: 
"queryLocalFonts"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
queueMicrotask
: 
ƒ queueMicrotask()
length
: 
1
name
: 
"queueMicrotask"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
reactiveElementVersions
: 
Array(1)
0
: 
"2.1.0"
length
: 
1
[[Prototype]]
: 
Array(0)
releaseEvents
: 
ƒ releaseEvents()
length
: 
0
name
: 
"releaseEvents"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
reportError
: 
ƒ reportError()
length
: 
1
name
: 
"reportError"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
requestAnimationFrame
: 
ƒ requestAnimationFrame()
length
: 
1
name
: 
"requestAnimationFrame"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
requestIdleCallback
: 
ƒ requestIdleCallback()
length
: 
1
name
: 
"requestIdleCallback"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
resizeBy
: 
ƒ resizeBy()
length
: 
2
name
: 
"resizeBy"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
resizeTo
: 
ƒ resizeTo()
length
: 
2
name
: 
"resizeTo"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
scheduler
: 
Scheduler
[[Prototype]]
: 
Scheduler
screen
: 
Screen
availHeight
: 
1752
availLeft
: 
0
availTop
: 
0
availWidth
: 
3200
colorDepth
: 
30
height
: 
1800
isExtended
: 
false
onchange
: 
null
orientation
: 
ScreenOrientation {angle: 0, type: 'landscape-primary', onchange: null}
pixelDepth
: 
30
width
: 
3200
[[Prototype]]
: 
Screen
screenLeft
: 
0
screenTop
: 
0
screenX
: 
0
screenY
: 
0
scroll
: 
ƒ scroll()
scrollBy
: 
ƒ scrollBy()
scrollTo
: 
ƒ scrollTo()
scrollX
: 
0
scrollY
: 
0
scrollbars
: 
BarProp {visible: true}
self
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
sessionStorage
: 
Storage {length: 0}
setInterval
: 
ƒ setInterval()
setTimeout
: 
ƒ setTimeout()
sharedStorage
: 
SharedStorage {worklet: SharedStorageWorklet}
showDirectoryPicker
: 
ƒ showDirectoryPicker()
showOpenFilePicker
: 
ƒ showOpenFilePicker()
showSaveFilePicker
: 
ƒ showSaveFilePicker()
speechSynthesis
: 
SpeechSynthesis {pending: false, speaking: false, paused: false, onvoiceschanged: null}
status
: 
""
statusbar
: 
BarProp {visible: true}
stop
: 
ƒ stop()
structuredClone
: 
ƒ structuredClone()
styleMedia
: 
StyleMedia {type: 'screen'}
toolbar
: 
BarProp {visible: true}
top
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
trustedTypes
: 
TrustedTypePolicyFactory {emptyHTML: emptyHTML "", emptyScript: emptyScript "", defaultPolicy: null, onbeforecreatepolicy: null}
viewport
: 
Viewport {segments: Array(1)}
visualViewport
: 
VisualViewport {offsetLeft: 0, offsetTop: 0, pageLeft: 0, pageTop: 0, width: 2689.333251953125, …}
webkitCancelAnimationFrame
: 
ƒ webkitCancelAnimationFrame()
webkitRequestAnimationFrame
: 
ƒ webkitRequestAnimationFrame()
webkitRequestFileSystem
: 
ƒ webkitRequestFileSystem()
webkitResolveLocalFileSystemURL
: 
ƒ webkitResolveLocalFileSystemURL()
window
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
Infinity
: 
Infinity
AbortController
: 
ƒ AbortController()
AbortSignal
: 
ƒ AbortSignal()
AbsoluteOrientationSensor
: 
ƒ AbsoluteOrientationSensor()
AbstractRange
: 
ƒ AbstractRange()
Accelerometer
: 
ƒ Accelerometer()
AggregateError
: 
ƒ AggregateError()
AmbientLightSensor
: 
ƒ AmbientLightSensor()
AnalyserNode
: 
ƒ AnalyserNode()
Animation
: 
ƒ Animation()
AnimationEffect
: 
ƒ AnimationEffect()
AnimationEvent
: 
ƒ AnimationEvent()
AnimationPlaybackEvent
: 
ƒ AnimationPlaybackEvent()
AnimationTimeline
: 
ƒ AnimationTimeline()
AnimationTrigger
: 
ƒ AnimationTrigger()
Array
: 
ƒ Array()
ArrayBuffer
: 
ƒ ArrayBuffer()
AsyncDisposableStack
: 
ƒ AsyncDisposableStack()
Atomics
: 
Atomics {load: ƒ, store: ƒ, add: ƒ, sub: ƒ, and: ƒ, …}
Attr
: 
ƒ Attr()
AttributePart
: 
ƒ AttributePart()
Audio
: 
ƒ Audio()
AudioBuffer
: 
ƒ AudioBuffer()
AudioBufferSourceNode
: 
ƒ AudioBufferSourceNode()
AudioContext
: 
ƒ AudioContext()
AudioData
: 
ƒ AudioData()
AudioDecoder
: 
ƒ AudioDecoder()
AudioDestinationNode
: 
ƒ AudioDestinationNode()
AudioEncoder
: 
ƒ AudioEncoder()
AudioListener
: 
ƒ AudioListener()
AudioNode
: 
ƒ AudioNode()
AudioParam
: 
ƒ AudioParam()
AudioParamMap
: 
ƒ AudioParamMap()
AudioPlayoutStats
: 
ƒ AudioPlayoutStats()
AudioProcessingEvent
: 
ƒ AudioProcessingEvent()
AudioScheduledSourceNode
: 
ƒ AudioScheduledSourceNode()
AudioSinkInfo
: 
ƒ AudioSinkInfo()
AudioTrack
: 
ƒ AudioTrack()
AudioTrackList
: 
ƒ AudioTrackList()
AudioWorklet
: 
ƒ AudioWorklet()
AudioWorkletNode
: 
ƒ AudioWorkletNode()
AuthenticatorAssertionResponse
: 
ƒ AuthenticatorAssertionResponse()
AuthenticatorAttestationResponse
: 
ƒ AuthenticatorAttestationResponse()
AuthenticatorResponse
: 
ƒ AuthenticatorResponse()
BackForwardCacheRestoration
: 
ƒ BackForwardCacheRestoration()
BackgroundFetchManager
: 
ƒ BackgroundFetchManager()
BackgroundFetchRecord
: 
ƒ BackgroundFetchRecord()
BackgroundFetchRegistration
: 
ƒ BackgroundFetchRegistration()
BarProp
: 
ƒ BarProp()
BaseAudioContext
: 
ƒ BaseAudioContext()
BatteryManager
: 
ƒ BatteryManager()
BeforeCreatePolicyEvent
: 
ƒ BeforeCreatePolicyEvent()
BeforeInstallPromptEvent
: 
ƒ BeforeInstallPromptEvent()
BeforeUnloadEvent
: 
ƒ BeforeUnloadEvent()
BigInt
: 
ƒ BigInt()
BigInt64Array
: 
ƒ BigInt64Array()
BigUint64Array
: 
ƒ BigUint64Array()
BiquadFilterNode
: 
ƒ BiquadFilterNode()
Blob
: 
ƒ Blob()
BlobEvent
: 
ƒ BlobEvent()
Bluetooth
: 
ƒ Bluetooth()
BluetoothAdvertisingEvent
: 
ƒ BluetoothAdvertisingEvent()
BluetoothCharacteristicProperties
: 
ƒ BluetoothCharacteristicProperties()
BluetoothDevice
: 
ƒ BluetoothDevice()
BluetoothLEScan
: 
ƒ BluetoothLEScan()
BluetoothManufacturerDataMap
: 
ƒ BluetoothManufacturerDataMap()
BluetoothRemoteGATTCharacteristic
: 
ƒ BluetoothRemoteGATTCharacteristic()
BluetoothRemoteGATTDescriptor
: 
ƒ BluetoothRemoteGATTDescriptor()
BluetoothRemoteGATTServer
: 
ƒ BluetoothRemoteGATTServer()
BluetoothRemoteGATTService
: 
ƒ BluetoothRemoteGATTService()
BluetoothServiceDataMap
: 
ƒ BluetoothServiceDataMap()
BluetoothUUID
: 
ƒ BluetoothUUID()
Boolean
: 
ƒ Boolean()
BroadcastChannel
: 
ƒ BroadcastChannel()
BrowserCaptureMediaStreamTrack
: 
ƒ BrowserCaptureMediaStreamTrack()
ByteLengthQueuingStrategy
: 
ƒ ByteLengthQueuingStrategy()
CDATASection
: 
ƒ CDATASection()
CSPViolationReportBody
: 
ƒ CSPViolationReportBody()
CSS
: 
CSS {highlights: HighlightRegistry, Hz: ƒ, Q: ƒ, cap: ƒ, ch: ƒ, …}
CSSAnimation
: 
ƒ CSSAnimation()
CSSColorValue
: 
ƒ CSSColorValue()
CSSConditionRule
: 
ƒ CSSConditionRule()
CSSContainerRule
: 
ƒ CSSContainerRule()
CSSCounterStyleRule
: 
ƒ CSSCounterStyleRule()
CSSFontFaceRule
: 
ƒ CSSFontFaceRule()
CSSFontFeatureValuesRule
: 
ƒ CSSFontFeatureValuesRule()
CSSFontPaletteValuesRule
: 
ƒ CSSFontPaletteValuesRule()
CSSFunctionDeclarations
: 
ƒ CSSFunctionDeclarations()
CSSFunctionDescriptors
: 
ƒ CSSFunctionDescriptors()
CSSFunctionRule
: 
ƒ CSSFunctionRule()
CSSGroupingRule
: 
ƒ CSSGroupingRule()
CSSHSL
: 
ƒ CSSHSL()
CSSHWB
: 
ƒ CSSHWB()
CSSImageValue
: 
ƒ CSSImageValue()
CSSImportRule
: 
ƒ CSSImportRule()
CSSKeyframeRule
: 
ƒ CSSKeyframeRule()
CSSKeyframesRule
: 
ƒ CSSKeyframesRule()
CSSKeywordValue
: 
ƒ CSSKeywordValue()
CSSLayerBlockRule
: 
ƒ CSSLayerBlockRule()
CSSLayerStatementRule
: 
ƒ CSSLayerStatementRule()
CSSMarginRule
: 
ƒ CSSMarginRule()
CSSMathClamp
: 
ƒ CSSMathClamp()
CSSMathInvert
: 
ƒ CSSMathInvert()
CSSMathMax
: 
ƒ CSSMathMax()
CSSMathMin
: 
ƒ CSSMathMin()
CSSMathNegate
: 
ƒ CSSMathNegate()
CSSMathProduct
: 
ƒ CSSMathProduct()
CSSMathSum
: 
ƒ CSSMathSum()
CSSMathValue
: 
ƒ CSSMathValue()
CSSMatrixComponent
: 
ƒ CSSMatrixComponent()
CSSMediaRule
: 
ƒ CSSMediaRule()
CSSNamespaceRule
: 
ƒ CSSNamespaceRule()
CSSNestedDeclarations
: 
ƒ CSSNestedDeclarations()
CSSNumericArray
: 
ƒ CSSNumericArray()
CSSNumericValue
: 
ƒ CSSNumericValue()
CSSPageRule
: 
ƒ CSSPageRule()
CSSPerspective
: 
ƒ CSSPerspective()
CSSPositionTryDescriptors
: 
ƒ CSSPositionTryDescriptors()
CSSPositionTryRule
: 
ƒ CSSPositionTryRule()
CSSPositionValue
: 
ƒ CSSPositionValue()
CSSPropertyRule
: 
ƒ CSSPropertyRule()
CSSRGB
: 
ƒ CSSRGB()
CSSRotate
: 
ƒ CSSRotate()
CSSRule
: 
ƒ CSSRule()
CSSRuleList
: 
ƒ CSSRuleList()
CSSScale
: 
ƒ CSSScale()
CSSScopeRule
: 
ƒ CSSScopeRule()
CSSSkew
: 
ƒ CSSSkew()
CSSSkewX
: 
ƒ CSSSkewX()
CSSSkewY
: 
ƒ CSSSkewY()
CSSStartingStyleRule
: 
ƒ CSSStartingStyleRule()
CSSStyleDeclaration
: 
ƒ CSSStyleDeclaration()
CSSStyleRule
: 
ƒ CSSStyleRule()
CSSStyleSheet
: 
ƒ CSSStyleSheet()
CSSStyleValue
: 
ƒ CSSStyleValue()
CSSSupportsRule
: 
ƒ CSSSupportsRule()
CSSTransformComponent
: 
ƒ CSSTransformComponent()
CSSTransformValue
: 
ƒ CSSTransformValue()
CSSTransition
: 
ƒ CSSTransition()
CSSTranslate
: 
ƒ CSSTranslate()
CSSUnitValue
: 
ƒ CSSUnitValue()
CSSUnparsedValue
: 
ƒ CSSUnparsedValue()
CSSVariableReferenceValue
: 
ƒ CSSVariableReferenceValue()
CSSViewTransitionRule
: 
ƒ CSSViewTransitionRule()
Cache
: 
ƒ Cache()
CacheStorage
: 
ƒ CacheStorage()
CanvasCaptureMediaStreamTrack
: 
ƒ CanvasCaptureMediaStreamTrack()
CanvasFilter
: 
ƒ CanvasFilter()
CanvasGradient
: 
ƒ CanvasGradient()
CanvasPattern
: 
ƒ CanvasPattern()
CanvasRenderingContext2D
: 
ƒ CanvasRenderingContext2D()
CaptureController
: 
ƒ CaptureController()
CaretPosition
: 
ƒ CaretPosition()
ChannelMergerNode
: 
ƒ ChannelMergerNode()
ChannelSplitterNode
: 
ƒ ChannelSplitterNode()
ChapterInformation
: 
ƒ ChapterInformation()
CharacterBoundsUpdateEvent
: 
ƒ CharacterBoundsUpdateEvent()
CharacterData
: 
ƒ CharacterData()
ChildNodePart
: 
ƒ ChildNodePart()
Clipboard
: 
ƒ Clipboard()
ClipboardEvent
: 
ƒ ClipboardEvent()
ClipboardItem
: 
ƒ ClipboardItem()
CloseEvent
: 
ƒ CloseEvent()
CloseWatcher
: 
ƒ CloseWatcher()
CommandEvent
: 
ƒ CommandEvent()
Comment
: 
ƒ Comment()
CompositionEvent
: 
ƒ CompositionEvent()
CompressionStream
: 
ƒ CompressionStream()
ConstantSourceNode
: 
ƒ ConstantSourceNode()
ContentIndex
: 
ƒ ContentIndex()
ContentVisibilityAutoStateChangeEvent
: 
ƒ ContentVisibilityAutoStateChangeEvent()
ConvolverNode
: 
ƒ ConvolverNode()
CookieChangeEvent
: 
ƒ CookieChangeEvent()
CookieStore
: 
ƒ CookieStore()
CookieStoreManager
: 
ƒ CookieStoreManager()
CountQueuingStrategy
: 
ƒ CountQueuingStrategy()
CreateMonitor
: 
ƒ CreateMonitor()
Credential
: 
ƒ Credential()
CredentialsContainer
: 
ƒ CredentialsContainer()
CropTarget
: 
ƒ CropTarget()
Crypto
: 
ƒ Crypto()
CryptoKey
: 
ƒ CryptoKey()
CustomElementRegistry
: 
ƒ CustomElementRegistry()
CustomEvent
: 
ƒ CustomEvent()
CustomStateSet
: 
ƒ CustomStateSet()
DOMError
: 
ƒ DOMError()
DOMException
: 
ƒ DOMException()
DOMImplementation
: 
ƒ DOMImplementation()
DOMMatrix
: 
ƒ DOMMatrix()
DOMMatrixReadOnly
: 
ƒ DOMMatrixReadOnly()
DOMParser
: 
ƒ DOMParser()
DOMPoint
: 
ƒ DOMPoint()
DOMPointReadOnly
: 
ƒ DOMPointReadOnly()
DOMQuad
: 
ƒ DOMQuad()
DOMRect
: 
ƒ DOMRect()
DOMRectList
: 
ƒ DOMRectList()
DOMRectReadOnly
: 
ƒ DOMRectReadOnly()
DOMStringList
: 
ƒ DOMStringList()
DOMStringMap
: 
ƒ DOMStringMap()
DOMTokenList
: 
ƒ DOMTokenList()
DataTransfer
: 
ƒ DataTransfer()
DataTransferItem
: 
ƒ DataTransferItem()
DataTransferItemList
: 
ƒ DataTransferItemList()
DataView
: 
ƒ DataView()
Date
: 
ƒ Date()
DecompressionStream
: 
ƒ DecompressionStream()
DelayNode
: 
ƒ DelayNode()
DelegatedInkTrailPresenter
: 
ƒ DelegatedInkTrailPresenter()
DeviceMotionEvent
: 
ƒ DeviceMotionEvent()
DeviceMotionEventAcceleration
: 
ƒ DeviceMotionEventAcceleration()
DeviceMotionEventRotationRate
: 
ƒ DeviceMotionEventRotationRate()
DeviceOrientationEvent
: 
ƒ DeviceOrientationEvent()
DevicePosture
: 
ƒ DevicePosture()
DigitalCredential
: 
ƒ DigitalCredential()
Directive
: 
ƒ Directive()
DisposableStack
: 
ƒ DisposableStack()
Document
: 
ƒ Document()
DocumentFragment
: 
ƒ DocumentFragment()
DocumentPartRoot
: 
ƒ DocumentPartRoot()
DocumentPictureInPicture
: 
ƒ DocumentPictureInPicture()
DocumentPictureInPictureEvent
: 
ƒ DocumentPictureInPictureEvent()
DocumentTimeline
: 
ƒ DocumentTimeline()
DocumentType
: 
ƒ DocumentType()
DragEvent
: 
ƒ DragEvent()
DynamicsCompressorNode
: 
ƒ DynamicsCompressorNode()
EditContext
: 
ƒ EditContext()
Element
: 
ƒ Element()
ElementInternals
: 
ƒ ElementInternals()
EncodedAudioChunk
: 
ƒ EncodedAudioChunk()
EncodedVideoChunk
: 
ƒ EncodedVideoChunk()
Error
: 
ƒ Error()
ErrorEvent
: 
ƒ ErrorEvent()
EvalError
: 
ƒ EvalError()
Event
: 
ƒ Event()
EventCounts
: 
ƒ EventCounts()
EventSource
: 
ƒ EventSource()
EventTarget
: 
ƒ EventTarget()
External
: 
ƒ External()
EyeDropper
: 
ƒ EyeDropper()
FaceDetector
: 
ƒ FaceDetector()
FeaturePolicy
: 
ƒ FeaturePolicy()
FederatedCredential
: 
ƒ FederatedCredential()
Fence
: 
ƒ Fence()
FencedFrameConfig
: 
ƒ FencedFrameConfig()
FetchLaterResult
: 
ƒ FetchLaterResult()
File
: 
ƒ File()
FileList
: 
ƒ FileList()
FileReader
: 
ƒ FileReader()
FileSystemDirectoryHandle
: 
ƒ FileSystemDirectoryHandle()
FileSystemFileHandle
: 
ƒ FileSystemFileHandle()
FileSystemHandle
: 
ƒ FileSystemHandle()
FileSystemObserver
: 
ƒ FileSystemObserver()
FileSystemWritableFileStream
: 
ƒ FileSystemWritableFileStream()
FinalizationRegistry
: 
ƒ FinalizationRegistry()
Float16Array
: 
ƒ Float16Array()
Float32Array
: 
ƒ Float32Array()
Float64Array
: 
ƒ Float64Array()
FocusEvent
: 
ƒ FocusEvent()
FontData
: 
ƒ FontData()
FontFace
: 
ƒ FontFace()
FontFaceSetLoadEvent
: 
ƒ FontFaceSetLoadEvent()
FormData
: 
ƒ FormData()
FormDataEvent
: 
ƒ FormDataEvent()
FragmentDirective
: 
ƒ FragmentDirective()
Function
: 
ƒ Function()
GPU
: 
ƒ GPU()
GPUAdapter
: 
ƒ GPUAdapter()
GPUAdapterInfo
: 
ƒ GPUAdapterInfo()
GPUBindGroup
: 
ƒ GPUBindGroup()
GPUBindGroupLayout
: 
ƒ GPUBindGroupLayout()
GPUBuffer
: 
ƒ GPUBuffer()
GPUBufferUsage
: 
GPUBufferUsage {MAP_READ: 1, MAP_WRITE: 2, COPY_SRC: 4, COPY_DST: 8, INDEX: 16, …}
GPUCanvasContext
: 
ƒ GPUCanvasContext()
GPUColorWrite
: 
GPUColorWrite {RED: 1, GREEN: 2, BLUE: 4, ALPHA: 8, ALL: 15, …}
GPUCommandBuffer
: 
ƒ GPUCommandBuffer()
GPUCommandEncoder
: 
ƒ GPUCommandEncoder()
GPUCompilationInfo
: 
ƒ GPUCompilationInfo()
GPUCompilationMessage
: 
ƒ GPUCompilationMessage()
GPUComputePassEncoder
: 
ƒ GPUComputePassEncoder()
GPUComputePipeline
: 
ƒ GPUComputePipeline()
GPUDevice
: 
ƒ GPUDevice()
GPUDeviceLostInfo
: 
ƒ GPUDeviceLostInfo()
GPUError
: 
ƒ GPUError()
GPUExternalTexture
: 
ƒ GPUExternalTexture()
GPUInternalError
: 
ƒ GPUInternalError()
GPUMapMode
: 
GPUMapMode {READ: 1, WRITE: 2, Symbol(Symbol.toStringTag): 'GPUMapMode'}
GPUOutOfMemoryError
: 
ƒ GPUOutOfMemoryError()
GPUPipelineError
: 
ƒ GPUPipelineError()
GPUPipelineLayout
: 
ƒ GPUPipelineLayout()
GPUQuerySet
: 
ƒ GPUQuerySet()
GPUQueue
: 
ƒ GPUQueue()
GPURenderBundle
: 
ƒ GPURenderBundle()
GPURenderBundleEncoder
: 
ƒ GPURenderBundleEncoder()
GPURenderPassEncoder
: 
ƒ GPURenderPassEncoder()
GPURenderPipeline
: 
ƒ GPURenderPipeline()
GPUSampler
: 
ƒ GPUSampler()
GPUShaderModule
: 
ƒ GPUShaderModule()
GPUShaderStage
: 
GPUShaderStage {VERTEX: 1, FRAGMENT: 2, COMPUTE: 4, Symbol(Symbol.toStringTag): 'GPUShaderStage'}
GPUSubgroupMatrixConfig
: 
ƒ GPUSubgroupMatrixConfig()
GPUSupportedFeatures
: 
ƒ GPUSupportedFeatures()
GPUSupportedLimits
: 
ƒ GPUSupportedLimits()
GPUTexture
: 
ƒ GPUTexture()
GPUTextureUsage
: 
GPUTextureUsage {COPY_SRC: 1, COPY_DST: 2, TEXTURE_BINDING: 4, STORAGE_BINDING: 8, RENDER_ATTACHMENT: 16, …}
GPUTextureView
: 
ƒ GPUTextureView()
GPUUncapturedErrorEvent
: 
ƒ GPUUncapturedErrorEvent()
GPUValidationError
: 
ƒ GPUValidationError()
GainNode
: 
ƒ GainNode()
Gamepad
: 
ƒ Gamepad()
GamepadButton
: 
ƒ GamepadButton()
GamepadEvent
: 
ƒ GamepadEvent()
GamepadHapticActuator
: 
ƒ GamepadHapticActuator()
GamepadTouch
: 
ƒ GamepadTouch()
Geolocation
: 
ƒ Geolocation()
GeolocationCoordinates
: 
ƒ GeolocationCoordinates()
GeolocationPosition
: 
ƒ GeolocationPosition()
GeolocationPositionError
: 
ƒ GeolocationPositionError()
GravitySensor
: 
ƒ GravitySensor()
Gyroscope
: 
ƒ Gyroscope()
HID
: 
ƒ HID()
HIDConnectionEvent
: 
ƒ HIDConnectionEvent()
HIDDevice
: 
ƒ HIDDevice()
HIDInputReportEvent
: 
ƒ HIDInputReportEvent()
HTMLAllCollection
: 
ƒ HTMLAllCollection()
HTMLAnchorElement
: 
ƒ HTMLAnchorElement()
HTMLAreaElement
: 
ƒ HTMLAreaElement()
HTMLAudioElement
: 
ƒ HTMLAudioElement()
HTMLBRElement
: 
ƒ HTMLBRElement()
HTMLBaseElement
: 
ƒ HTMLBaseElement()
HTMLBodyElement
: 
ƒ HTMLBodyElement()
HTMLButtonElement
: 
ƒ HTMLButtonElement()
HTMLCanvasElement
: 
ƒ HTMLCanvasElement()
HTMLCollection
: 
ƒ HTMLCollection()
HTMLDListElement
: 
ƒ HTMLDListElement()
HTMLDataElement
: 
ƒ HTMLDataElement()
HTMLDataListElement
: 
ƒ HTMLDataListElement()
HTMLDetailsElement
: 
ƒ HTMLDetailsElement()
HTMLDialogElement
: 
ƒ HTMLDialogElement()
HTMLDirectoryElement
: 
ƒ HTMLDirectoryElement()
HTMLDivElement
: 
ƒ HTMLDivElement()
HTMLDocument
: 
ƒ HTMLDocument()
HTMLElement
: 
ƒ HTMLElement()
HTMLEmbedElement
: 
ƒ HTMLEmbedElement()
HTMLFencedFrameElement
: 
ƒ HTMLFencedFrameElement()
HTMLFieldSetElement
: 
ƒ HTMLFieldSetElement()
HTMLFontElement
: 
ƒ HTMLFontElement()
HTMLFormControlsCollection
: 
ƒ HTMLFormControlsCollection()
HTMLFormElement
: 
ƒ HTMLFormElement()
HTMLFrameElement
: 
ƒ HTMLFrameElement()
HTMLFrameSetElement
: 
ƒ HTMLFrameSetElement()
HTMLHRElement
: 
ƒ HTMLHRElement()
HTMLHeadElement
: 
ƒ HTMLHeadElement()
HTMLHeadingElement
: 
ƒ HTMLHeadingElement()
HTMLHtmlElement
: 
ƒ HTMLHtmlElement()
HTMLIFrameElement
: 
ƒ HTMLIFrameElement()
HTMLImageElement
: 
ƒ HTMLImageElement()
HTMLInputElement
: 
ƒ HTMLInputElement()
HTMLLIElement
: 
ƒ HTMLLIElement()
HTMLLabelElement
: 
ƒ HTMLLabelElement()
HTMLLegendElement
: 
ƒ HTMLLegendElement()
HTMLLinkElement
: 
ƒ HTMLLinkElement()
HTMLMapElement
: 
ƒ HTMLMapElement()
HTMLMarqueeElement
: 
ƒ HTMLMarqueeElement()
HTMLMediaElement
: 
ƒ HTMLMediaElement()
HTMLMenuElement
: 
ƒ HTMLMenuElement()
HTMLMetaElement
: 
ƒ HTMLMetaElement()
HTMLMeterElement
: 
ƒ HTMLMeterElement()
HTMLModElement
: 
ƒ HTMLModElement()
HTMLOListElement
: 
ƒ HTMLOListElement()
HTMLObjectElement
: 
ƒ HTMLObjectElement()
HTMLOptGroupElement
: 
ƒ HTMLOptGroupElement()
HTMLOptionElement
: 
ƒ HTMLOptionElement()
HTMLOptionsCollection
: 
ƒ HTMLOptionsCollection()
HTMLOutputElement
: 
ƒ HTMLOutputElement()
HTMLParagraphElement
: 
ƒ HTMLParagraphElement()
HTMLParamElement
: 
ƒ HTMLParamElement()
HTMLPermissionElement
: 
ƒ HTMLPermissionElement()
HTMLPictureElement
: 
ƒ HTMLPictureElement()
HTMLPreElement
: 
ƒ HTMLPreElement()
HTMLProgressElement
: 
ƒ HTMLProgressElement()
HTMLQuoteElement
: 
ƒ HTMLQuoteElement()
HTMLScriptElement
: 
ƒ HTMLScriptElement()
HTMLSelectElement
: 
ƒ HTMLSelectElement()
HTMLSelectedContentElement
: 
ƒ HTMLSelectedContentElement()
HTMLSlotElement
: 
ƒ HTMLSlotElement()
HTMLSourceElement
: 
ƒ HTMLSourceElement()
HTMLSpanElement
: 
ƒ HTMLSpanElement()
HTMLStyleElement
: 
ƒ HTMLStyleElement()
HTMLTableCaptionElement
: 
ƒ HTMLTableCaptionElement()
HTMLTableCellElement
: 
ƒ HTMLTableCellElement()
HTMLTableColElement
: 
ƒ HTMLTableColElement()
HTMLTableElement
: 
ƒ HTMLTableElement()
HTMLTableRowElement
: 
ƒ HTMLTableRowElement()
HTMLTableSectionElement
: 
ƒ HTMLTableSectionElement()
HTMLTemplateElement
: 
ƒ HTMLTemplateElement()
HTMLTextAreaElement
: 
ƒ HTMLTextAreaElement()
HTMLTimeElement
: 
ƒ HTMLTimeElement()
HTMLTitleElement
: 
ƒ HTMLTitleElement()
HTMLTrackElement
: 
ƒ HTMLTrackElement()
HTMLUListElement
: 
ƒ HTMLUListElement()
HTMLUnknownElement
: 
ƒ HTMLUnknownElement()
HTMLVideoElement
: 
ƒ HTMLVideoElement()
HandwritingStroke
: 
ƒ HandwritingStroke()
HashChangeEvent
: 
ƒ HashChangeEvent()
Headers
: 
ƒ Headers()
Highlight
: 
ƒ Highlight()
HighlightRegistry
: 
ƒ HighlightRegistry()
History
: 
ƒ History()
IDBCursor
: 
ƒ IDBCursor()
IDBCursorWithValue
: 
ƒ IDBCursorWithValue()
IDBDatabase
: 
ƒ IDBDatabase()
IDBFactory
: 
ƒ IDBFactory()
IDBIndex
: 
ƒ IDBIndex()
IDBKeyRange
: 
ƒ IDBKeyRange()
IDBObjectStore
: 
ƒ IDBObjectStore()
IDBOpenDBRequest
: 
ƒ IDBOpenDBRequest()
IDBRecord
: 
ƒ IDBRecord()
IDBRequest
: 
ƒ IDBRequest()
IDBTransaction
: 
ƒ IDBTransaction()
IDBVersionChangeEvent
: 
ƒ IDBVersionChangeEvent()
IIRFilterNode
: 
ƒ IIRFilterNode()
IdentityCredential
: 
ƒ IdentityCredential()
IdentityCredentialError
: 
ƒ IdentityCredentialError()
IdentityProvider
: 
ƒ IdentityProvider()
IdleDeadline
: 
ƒ IdleDeadline()
IdleDetector
: 
ƒ IdleDetector()
Image
: 
ƒ Image()
ImageBitmap
: 
ƒ ImageBitmap()
ImageBitmapRenderingContext
: 
ƒ ImageBitmapRenderingContext()
ImageCapture
: 
ƒ ImageCapture()
ImageData
: 
ƒ ImageData()
ImageDecoder
: 
ƒ ImageDecoder()
ImageTrack
: 
ƒ ImageTrack()
ImageTrackList
: 
ƒ ImageTrackList()
Ink
: 
ƒ Ink()
InputDeviceCapabilities
: 
ƒ InputDeviceCapabilities()
InputDeviceInfo
: 
ƒ InputDeviceInfo()
InputEvent
: 
ƒ InputEvent()
Int8Array
: 
ƒ Int8Array()
Int16Array
: 
ƒ Int16Array()
Int32Array
: 
ƒ Int32Array()
IntegrityViolationReportBody
: 
ƒ IntegrityViolationReportBody()
InteractionContentfulPaint
: 
ƒ InteractionContentfulPaint()
InterestEvent
: 
ƒ InterestEvent()
IntersectionObserver
: 
ƒ IntersectionObserver()
IntersectionObserverEntry
: 
ƒ IntersectionObserverEntry()
Intl
: 
Intl {getCanonicalLocales: ƒ, supportedValuesOf: ƒ, DateTimeFormat: ƒ, NumberFormat: ƒ, Collator: ƒ, …}
Iterator
: 
ƒ Iterator()
JSON
: 
JSON {Symbol(Symbol.toStringTag): 'JSON', parse: ƒ, stringify: ƒ, rawJSON: ƒ, isRawJSON: ƒ}
Keyboard
: 
ƒ Keyboard()
KeyboardEvent
: 
ƒ KeyboardEvent()
KeyboardLayoutMap
: 
ƒ KeyboardLayoutMap()
KeyframeEffect
: 
ƒ KeyframeEffect()
LanguageDetector
: 
ƒ LanguageDetector()
LanguageModel
: 
ƒ LanguageModel()
LanguageModelParams
: 
ƒ LanguageModelParams()
LargestContentfulPaint
: 
ƒ LargestContentfulPaint()
LaunchParams
: 
ƒ LaunchParams()
LaunchQueue
: 
ƒ LaunchQueue()
LayoutShift
: 
ƒ LayoutShift()
LayoutShiftAttribution
: 
ƒ LayoutShiftAttribution()
LinearAccelerationSensor
: 
ƒ LinearAccelerationSensor()
Location
: 
ƒ Location()
Lock
: 
ƒ Lock()
LockManager
: 
ƒ LockManager()
MIDIAccess
: 
ƒ MIDIAccess()
MIDIConnectionEvent
: 
ƒ MIDIConnectionEvent()
MIDIInput
: 
ƒ MIDIInput()
MIDIInputMap
: 
ƒ MIDIInputMap()
MIDIMessageEvent
: 
ƒ MIDIMessageEvent()
MIDIOutput
: 
ƒ MIDIOutput()
MIDIOutputMap
: 
ƒ MIDIOutputMap()
MIDIPort
: 
ƒ MIDIPort()
Magnetometer
: 
ƒ Magnetometer()
Map
: 
ƒ Map()
Math
: 
Math {abs: ƒ, acos: ƒ, acosh: ƒ, asin: ƒ, asinh: ƒ, …}
MathMLElement
: 
ƒ MathMLElement()
MediaCapabilities
: 
ƒ MediaCapabilities()
MediaDeviceInfo
: 
ƒ MediaDeviceInfo()
MediaDevices
: 
ƒ MediaDevices()
MediaElementAudioSourceNode
: 
ƒ MediaElementAudioSourceNode()
MediaEncryptedEvent
: 
ƒ MediaEncryptedEvent()
MediaError
: 
ƒ MediaError()
MediaKeyMessageEvent
: 
ƒ MediaKeyMessageEvent()
MediaKeySession
: 
ƒ MediaKeySession()
MediaKeyStatusMap
: 
ƒ MediaKeyStatusMap()
MediaKeySystemAccess
: 
ƒ MediaKeySystemAccess()
MediaKeys
: 
ƒ MediaKeys()
MediaList
: 
ƒ MediaList()
MediaMetadata
: 
ƒ MediaMetadata()
MediaQueryList
: 
ƒ MediaQueryList()
MediaQueryListEvent
: 
ƒ MediaQueryListEvent()
MediaRecorder
: 
ƒ MediaRecorder()
MediaSession
: 
ƒ MediaSession()
MediaSource
: 
ƒ MediaSource()
MediaSourceHandle
: 
ƒ MediaSourceHandle()
MediaStream
: 
ƒ MediaStream()
MediaStreamAudioDestinationNode
: 
ƒ MediaStreamAudioDestinationNode()
MediaStreamAudioSourceNode
: 
ƒ MediaStreamAudioSourceNode()
MediaStreamEvent
: 
ƒ MediaStreamEvent()
MediaStreamTrack
: 
ƒ MediaStreamTrack()
MediaStreamTrackAudioStats
: 
ƒ MediaStreamTrackAudioStats()
MediaStreamTrackEvent
: 
ƒ MediaStreamTrackEvent()
MediaStreamTrackGenerator
: 
ƒ MediaStreamTrackGenerator()
MediaStreamTrackProcessor
: 
ƒ MediaStreamTrackProcessor()
MediaStreamTrackVideoStats
: 
ƒ MediaStreamTrackVideoStats()
MessageChannel
: 
ƒ MessageChannel()
MessageEvent
: 
ƒ MessageEvent()
MessagePort
: 
ƒ MessagePort()
MimeType
: 
ƒ MimeType()
MimeTypeArray
: 
ƒ MimeTypeArray()
MouseEvent
: 
ƒ MouseEvent()
MutationObserver
: 
ƒ MutationObserver()
MutationRecord
: 
ƒ MutationRecord()
NaN
: 
NaN
NamedNodeMap
: 
ƒ NamedNodeMap()
NavigateEvent
: 
ƒ NavigateEvent()
Navigation
: 
ƒ Navigation()
NavigationActivation
: 
ƒ NavigationActivation()
NavigationCurrentEntryChangeEvent
: 
ƒ NavigationCurrentEntryChangeEvent()
NavigationDestination
: 
ƒ NavigationDestination()
NavigationHistoryEntry
: 
ƒ NavigationHistoryEntry()
NavigationPrecommitController
: 
ƒ NavigationPrecommitController()
NavigationPreloadManager
: 
ƒ NavigationPreloadManager()
NavigationTransition
: 
ƒ NavigationTransition()
Navigator
: 
ƒ Navigator()
NavigatorLogin
: 
ƒ NavigatorLogin()
NavigatorManagedData
: 
ƒ NavigatorManagedData()
NavigatorUAData
: 
ƒ NavigatorUAData()
NetworkInformation
: 
ƒ NetworkInformation()
Node
: 
ƒ Node()
NodeFilter
: 
ƒ NodeFilter()
NodeIterator
: 
ƒ NodeIterator()
NodeList
: 
ƒ NodeList()
NodePart
: 
ƒ NodePart()
NotRestoredReasonDetails
: 
ƒ NotRestoredReasonDetails()
NotRestoredReasons
: 
ƒ NotRestoredReasons()
Notification
: 
ƒ Notification()
Number
: 
ƒ Number()
OTPCredential
: 
ƒ OTPCredential()
Object
: 
ƒ Object()
Observable
: 
ƒ Observable()
OfflineAudioCompletionEvent
: 
ƒ OfflineAudioCompletionEvent()
OfflineAudioContext
: 
ƒ OfflineAudioContext()
OffscreenCanvas
: 
ƒ OffscreenCanvas()
OffscreenCanvasRenderingContext2D
: 
ƒ OffscreenCanvasRenderingContext2D()
Option
: 
ƒ Option()
OrientationSensor
: 
ƒ OrientationSensor()
OscillatorNode
: 
ƒ OscillatorNode()
OverconstrainedError
: 
ƒ OverconstrainedError()
OverscrollEvent
: 
ƒ OverscrollEvent()
PageRevealEvent
: 
ƒ PageRevealEvent()
PageSwapEvent
: 
ƒ PageSwapEvent()
PageTransitionEvent
: 
ƒ PageTransitionEvent()
PannerNode
: 
ƒ PannerNode()
Part
: 
ƒ Part()
PasswordCredential
: 
ƒ PasswordCredential()
Path2D
: 
ƒ Path2D()
PaymentAddress
: 
ƒ PaymentAddress()
PaymentManager
: 
ƒ PaymentManager()
PaymentMethodChangeEvent
: 
ƒ PaymentMethodChangeEvent()
PaymentRequest
: 
ƒ PaymentRequest()
PaymentRequestUpdateEvent
: 
ƒ PaymentRequestUpdateEvent()
PaymentResponse
: 
ƒ PaymentResponse()
Performance
: 
ƒ Performance()
PerformanceContainerTiming
: 
ƒ PerformanceContainerTiming()
PerformanceElementTiming
: 
ƒ PerformanceElementTiming()
PerformanceEntry
: 
ƒ PerformanceEntry()
PerformanceEventTiming
: 
ƒ PerformanceEventTiming()
PerformanceLongAnimationFrameTiming
: 
ƒ PerformanceLongAnimationFrameTiming()
PerformanceLongTaskTiming
: 
ƒ PerformanceLongTaskTiming()
PerformanceMark
: 
ƒ PerformanceMark()
PerformanceMeasure
: 
ƒ PerformanceMeasure()
PerformanceNavigation
: 
ƒ PerformanceNavigation()
PerformanceNavigationTiming
: 
ƒ PerformanceNavigationTiming()
PerformanceObserver
: 
ƒ PerformanceObserver()
PerformanceObserverEntryList
: 
ƒ PerformanceObserverEntryList()
PerformancePaintTiming
: 
ƒ PerformancePaintTiming()
PerformanceResourceTiming
: 
ƒ PerformanceResourceTiming()
PerformanceScriptTiming
: 
ƒ PerformanceScriptTiming()
PerformanceServerTiming
: 
ƒ PerformanceServerTiming()
PerformanceTiming
: 
ƒ PerformanceTiming()
PerformanceTimingConfidence
: 
ƒ PerformanceTimingConfidence()
PeriodicSyncManager
: 
ƒ PeriodicSyncManager()
PeriodicWave
: 
ƒ PeriodicWave()
PermissionStatus
: 
ƒ PermissionStatus()
Permissions
: 
ƒ Permissions()
PictureInPictureEvent
: 
ƒ PictureInPictureEvent()
PictureInPictureWindow
: 
ƒ PictureInPictureWindow()
Plugin
: 
ƒ Plugin()
PluginArray
: 
ƒ PluginArray()
PointerEvent
: 
ƒ PointerEvent()
PopStateEvent
: 
ƒ PopStateEvent()
PreferenceManager
: 
ƒ PreferenceManager()
PreferenceObject
: 
ƒ PreferenceObject()
Presentation
: 
ƒ Presentation()
PresentationAvailability
: 
ƒ PresentationAvailability()
PresentationConnection
: 
ƒ PresentationConnection()
PresentationConnectionAvailableEvent
: 
ƒ PresentationConnectionAvailableEvent()
PresentationConnectionCloseEvent
: 
ƒ PresentationConnectionCloseEvent()
PresentationConnectionList
: 
ƒ PresentationConnectionList()
PresentationReceiver
: 
ƒ PresentationReceiver()
PresentationRequest
: 
ƒ PresentationRequest()
PressureObserver
: 
ƒ PressureObserver()
PressureRecord
: 
ƒ PressureRecord()
PrivateAttribution
: 
ƒ PrivateAttribution()
ProcessingInstruction
: 
ƒ ProcessingInstruction()
Profiler
: 
ƒ Profiler()
ProgressEvent
: 
ƒ ProgressEvent()
Promise
: 
ƒ Promise()
PromiseRejectionEvent
: 
ƒ PromiseRejectionEvent()
Proofreader
: 
ƒ Proofreader()
ProtectedAudience
: 
ƒ ProtectedAudience()
Proxy
: 
ƒ Proxy()
PublicKeyCredential
: 
ƒ PublicKeyCredential()
PushManager
: 
ƒ PushManager()
PushSubscription
: 
ƒ PushSubscription()
PushSubscriptionOptions
: 
ƒ PushSubscriptionOptions()
QuotaExceededError
: 
ƒ QuotaExceededError()
RTCCertificate
: 
ƒ RTCCertificate()
RTCDTMFSender
: 
ƒ RTCDTMFSender()
RTCDTMFToneChangeEvent
: 
ƒ RTCDTMFToneChangeEvent()
RTCDataChannel
: 
ƒ RTCDataChannel()
RTCDataChannelEvent
: 
ƒ RTCDataChannelEvent()
RTCDtlsTransport
: 
ƒ RTCDtlsTransport()
RTCEncodedAudioFrame
: 
ƒ RTCEncodedAudioFrame()
RTCEncodedVideoFrame
: 
ƒ RTCEncodedVideoFrame()
RTCError
: 
ƒ RTCError()
RTCErrorEvent
: 
ƒ RTCErrorEvent()
RTCIceCandidate
: 
ƒ RTCIceCandidate()
RTCIceTransport
: 
ƒ RTCIceTransport()
RTCPeerConnection
: 
ƒ RTCPeerConnection()
RTCPeerConnectionIceErrorEvent
: 
ƒ RTCPeerConnectionIceErrorEvent()
RTCPeerConnectionIceEvent
: 
ƒ RTCPeerConnectionIceEvent()
RTCRtpReceiver
: 
ƒ RTCRtpReceiver()
RTCRtpScriptTransform
: 
ƒ RTCRtpScriptTransform()
RTCRtpSender
: 
ƒ RTCRtpSender()
RTCRtpTransceiver
: 
ƒ RTCRtpTransceiver()
RTCSctpTransport
: 
ƒ RTCSctpTransport()
RTCSessionDescription
: 
ƒ RTCSessionDescription()
RTCStatsReport
: 
ƒ RTCStatsReport()
RTCTrackEvent
: 
ƒ RTCTrackEvent()
RadioNodeList
: 
ƒ RadioNodeList()
Range
: 
ƒ Range()
RangeError
: 
ƒ RangeError()
ReadableByteStreamController
: 
ƒ ReadableByteStreamController()
ReadableStream
: 
ƒ ReadableStream()
ReadableStreamBYOBReader
: 
ƒ ReadableStreamBYOBReader()
ReadableStreamBYOBRequest
: 
ƒ ReadableStreamBYOBRequest()
ReadableStreamDefaultController
: 
ƒ ReadableStreamDefaultController()
ReadableStreamDefaultReader
: 
ƒ ReadableStreamDefaultReader()
ReferenceError
: 
ƒ ReferenceError()
Reflect
: 
Reflect {defineProperty: ƒ, deleteProperty: ƒ, apply: ƒ, construct: ƒ, get: ƒ, …}
RegExp
: 
ƒ RegExp()
RelativeOrientationSensor
: 
ƒ RelativeOrientationSensor()
RemotePlayback
: 
ƒ RemotePlayback()
ReportBody
: 
ƒ ReportBody()
ReportingObserver
: 
ƒ ReportingObserver()
Request
: 
ƒ Request()
ResizeObserver
: 
ƒ ResizeObserver()
ResizeObserverEntry
: 
ƒ ResizeObserverEntry()
ResizeObserverSize
: 
ƒ ResizeObserverSize()
Response
: 
ƒ Response()
RestrictionTarget
: 
ƒ RestrictionTarget()
Rewriter
: 
ƒ Rewriter()
SVGAElement
: 
ƒ SVGAElement()
SVGAngle
: 
ƒ SVGAngle()
SVGAnimateElement
: 
ƒ SVGAnimateElement()
SVGAnimateMotionElement
: 
ƒ SVGAnimateMotionElement()
SVGAnimateTransformElement
: 
ƒ SVGAnimateTransformElement()
SVGAnimatedAngle
: 
ƒ SVGAnimatedAngle()
SVGAnimatedBoolean
: 
ƒ SVGAnimatedBoolean()
SVGAnimatedEnumeration
: 
ƒ SVGAnimatedEnumeration()
SVGAnimatedInteger
: 
ƒ SVGAnimatedInteger()
SVGAnimatedLength
: 
ƒ SVGAnimatedLength()
SVGAnimatedLengthList
: 
ƒ SVGAnimatedLengthList()
SVGAnimatedNumber
: 
ƒ SVGAnimatedNumber()
SVGAnimatedNumberList
: 
ƒ SVGAnimatedNumberList()
SVGAnimatedPreserveAspectRatio
: 
ƒ SVGAnimatedPreserveAspectRatio()
SVGAnimatedRect
: 
ƒ SVGAnimatedRect()
SVGAnimatedString
: 
ƒ SVGAnimatedString()
SVGAnimatedTransformList
: 
ƒ SVGAnimatedTransformList()
SVGAnimationElement
: 
ƒ SVGAnimationElement()
SVGCircleElement
: 
ƒ SVGCircleElement()
SVGClipPathElement
: 
ƒ SVGClipPathElement()
SVGComponentTransferFunctionElement
: 
ƒ SVGComponentTransferFunctionElement()
SVGDefsElement
: 
ƒ SVGDefsElement()
SVGDescElement
: 
ƒ SVGDescElement()
SVGElement
: 
ƒ SVGElement()
SVGEllipseElement
: 
ƒ SVGEllipseElement()
SVGFEBlendElement
: 
ƒ SVGFEBlendElement()
SVGFEColorMatrixElement
: 
ƒ SVGFEColorMatrixElement()
SVGFEComponentTransferElement
: 
ƒ SVGFEComponentTransferElement()
SVGFECompositeElement
: 
ƒ SVGFECompositeElement()
SVGFEConvolveMatrixElement
: 
ƒ SVGFEConvolveMatrixElement()
SVGFEDiffuseLightingElement
: 
ƒ SVGFEDiffuseLightingElement()
SVGFEDisplacementMapElement
: 
ƒ SVGFEDisplacementMapElement()
SVGFEDistantLightElement
: 
ƒ SVGFEDistantLightElement()
SVGFEDropShadowElement
: 
ƒ SVGFEDropShadowElement()
SVGFEFloodElement
: 
ƒ SVGFEFloodElement()
SVGFEFuncAElement
: 
ƒ SVGFEFuncAElement()
SVGFEFuncBElement
: 
ƒ SVGFEFuncBElement()
SVGFEFuncGElement
: 
ƒ SVGFEFuncGElement()
SVGFEFuncRElement
: 
ƒ SVGFEFuncRElement()
SVGFEGaussianBlurElement
: 
ƒ SVGFEGaussianBlurElement()
SVGFEImageElement
: 
ƒ SVGFEImageElement()
SVGFEMergeElement
: 
ƒ SVGFEMergeElement()
SVGFEMergeNodeElement
: 
ƒ SVGFEMergeNodeElement()
SVGFEMorphologyElement
: 
ƒ SVGFEMorphologyElement()
SVGFEOffsetElement
: 
ƒ SVGFEOffsetElement()
SVGFEPointLightElement
: 
ƒ SVGFEPointLightElement()
SVGFESpecularLightingElement
: 
ƒ SVGFESpecularLightingElement()
SVGFESpotLightElement
: 
ƒ SVGFESpotLightElement()
SVGFETileElement
: 
ƒ SVGFETileElement()
SVGFETurbulenceElement
: 
ƒ SVGFETurbulenceElement()
SVGFilterElement
: 
ƒ SVGFilterElement()
SVGForeignObjectElement
: 
ƒ SVGForeignObjectElement()
SVGGElement
: 
ƒ SVGGElement()
SVGGeometryElement
: 
ƒ SVGGeometryElement()
SVGGradientElement
: 
ƒ SVGGradientElement()
SVGGraphicsElement
: 
ƒ SVGGraphicsElement()
SVGImageElement
: 
ƒ SVGImageElement()
SVGLength
: 
ƒ SVGLength()
SVGLengthList
: 
ƒ SVGLengthList()
SVGLineElement
: 
ƒ SVGLineElement()
SVGLinearGradientElement
: 
ƒ SVGLinearGradientElement()
SVGMPathElement
: 
ƒ SVGMPathElement()
SVGMarkerElement
: 
ƒ SVGMarkerElement()
SVGMaskElement
: 
ƒ SVGMaskElement()
SVGMatrix
: 
ƒ SVGMatrix()
SVGMetadataElement
: 
ƒ SVGMetadataElement()
SVGNumber
: 
ƒ SVGNumber()
SVGNumberList
: 
ƒ SVGNumberList()
SVGPathElement
: 
ƒ SVGPathElement()
SVGPatternElement
: 
ƒ SVGPatternElement()
SVGPoint
: 
ƒ SVGPoint()
SVGPointList
: 
ƒ SVGPointList()
SVGPolygonElement
: 
ƒ SVGPolygonElement()
SVGPolylineElement
: 
ƒ SVGPolylineElement()
SVGPreserveAspectRatio
: 
ƒ SVGPreserveAspectRatio()
SVGRadialGradientElement
: 
ƒ SVGRadialGradientElement()
SVGRect
: 
ƒ SVGRect()
SVGRectElement
: 
ƒ SVGRectElement()
SVGSVGElement
: 
ƒ SVGSVGElement()
SVGScriptElement
: 
ƒ SVGScriptElement()
SVGSetElement
: 
ƒ SVGSetElement()
SVGStopElement
: 
ƒ SVGStopElement()
SVGStringList
: 
ƒ SVGStringList()
SVGStyleElement
: 
ƒ SVGStyleElement()
SVGSwitchElement
: 
ƒ SVGSwitchElement()
SVGSymbolElement
: 
ƒ SVGSymbolElement()
SVGTSpanElement
: 
ƒ SVGTSpanElement()
SVGTextContentElement
: 
ƒ SVGTextContentElement()
SVGTextElement
: 
ƒ SVGTextElement()
SVGTextPathElement
: 
ƒ SVGTextPathElement()
SVGTextPositioningElement
: 
ƒ SVGTextPositioningElement()
SVGTitleElement
: 
ƒ SVGTitleElement()
SVGTransform
: 
ƒ SVGTransform()
SVGTransformList
: 
ƒ SVGTransformList()
SVGUnitTypes
: 
ƒ SVGUnitTypes()
SVGUseElement
: 
ƒ SVGUseElement()
SVGViewElement
: 
ƒ SVGViewElement()
Scheduler
: 
ƒ Scheduler()
Scheduling
: 
ƒ Scheduling()
Screen
: 
ƒ Screen()
ScreenDetailed
: 
ƒ ScreenDetailed()
ScreenDetails
: 
ƒ ScreenDetails()
ScreenOrientation
: 
ƒ ScreenOrientation()
ScriptProcessorNode
: 
ƒ ScriptProcessorNode()
ScrollTimeline
: 
ƒ ScrollTimeline()
SecurityPolicyViolationEvent
: 
ƒ SecurityPolicyViolationEvent()
Selection
: 
ƒ Selection()
SelectorDirective
: 
ƒ SelectorDirective()
Sensor
: 
ƒ Sensor()
SensorErrorEvent
: 
ƒ SensorErrorEvent()
Serial
: 
ƒ Serial()
SerialPort
: 
ƒ SerialPort()
ServiceWorker
: 
ƒ ServiceWorker()
ServiceWorkerContainer
: 
ƒ ServiceWorkerContainer()
ServiceWorkerRegistration
: 
ƒ ServiceWorkerRegistration()
Set
: 
ƒ Set()
ShadowRoot
: 
ƒ ShadowRoot()
SharedStorage
: 
ƒ SharedStorage()
SharedStorageAppendMethod
: 
ƒ SharedStorageAppendMethod()
SharedStorageClearMethod
: 
ƒ SharedStorageClearMethod()
SharedStorageDeleteMethod
: 
ƒ SharedStorageDeleteMethod()
SharedStorageModifierMethod
: 
ƒ SharedStorageModifierMethod()
SharedStorageSetMethod
: 
ƒ SharedStorageSetMethod()
SharedStorageWorklet
: 
ƒ SharedStorageWorklet()
SharedWorker
: 
ƒ SharedWorker()
SnapEvent
: 
ƒ SnapEvent()
SoftNavigationEntry
: 
ƒ SoftNavigationEntry()
SourceBuffer
: 
ƒ SourceBuffer()
SourceBufferList
: 
ƒ SourceBufferList()
SpeechGrammar
: 
ƒ SpeechGrammar()
SpeechGrammarList
: 
ƒ SpeechGrammarList()
SpeechRecognition
: 
ƒ SpeechRecognition()
SpeechRecognitionContext
: 
ƒ SpeechRecognitionContext()
SpeechRecognitionErrorEvent
: 
ƒ SpeechRecognitionErrorEvent()
SpeechRecognitionEvent
: 
ƒ SpeechRecognitionEvent()
SpeechRecognitionPhrase
: 
ƒ SpeechRecognitionPhrase()
SpeechRecognitionPhraseList
: 
ƒ SpeechRecognitionPhraseList()
SpeechSynthesis
: 
ƒ SpeechSynthesis()
SpeechSynthesisErrorEvent
: 
ƒ SpeechSynthesisErrorEvent()
SpeechSynthesisEvent
: 
ƒ SpeechSynthesisEvent()
SpeechSynthesisUtterance
: 
ƒ SpeechSynthesisUtterance()
SpeechSynthesisVoice
: 
ƒ SpeechSynthesisVoice()
StaticRange
: 
ƒ StaticRange()
StereoPannerNode
: 
ƒ StereoPannerNode()
Storage
: 
ƒ Storage()
StorageBucket
: 
ƒ StorageBucket()
StorageBucketManager
: 
ƒ StorageBucketManager()
StorageEvent
: 
ƒ StorageEvent()
StorageManager
: 
ƒ StorageManager()
String
: 
ƒ String()
StylePropertyMap
: 
ƒ StylePropertyMap()
StylePropertyMapReadOnly
: 
ƒ StylePropertyMapReadOnly()
StyleSheet
: 
ƒ StyleSheet()
StyleSheetList
: 
ƒ StyleSheetList()
SubmitEvent
: 
ƒ SubmitEvent()
Subscriber
: 
ƒ Subscriber()
SubtleCrypto
: 
ƒ SubtleCrypto()
Summarizer
: 
ƒ Summarizer()
SuppressedError
: 
ƒ SuppressedError()
Symbol
: 
ƒ Symbol()
SyncManager
: 
ƒ SyncManager()
SyntaxError
: 
ƒ SyntaxError()
TaskAttributionTiming
: 
ƒ TaskAttributionTiming()
TaskController
: 
ƒ TaskController()
TaskPriorityChangeEvent
: 
ƒ TaskPriorityChangeEvent()
TaskSignal
: 
ƒ TaskSignal()
Text
: 
ƒ Text()
TextCluster
: 
ƒ TextCluster()
TextDecoder
: 
ƒ TextDecoder()
TextDecoderStream
: 
ƒ TextDecoderStream()
TextDetector
: 
ƒ TextDetector()
TextDirective
: 
ƒ TextDirective()
TextEncoder
: 
ƒ TextEncoder()
TextEncoderStream
: 
ƒ TextEncoderStream()
TextEvent
: 
ƒ TextEvent()
TextFormat
: 
ƒ TextFormat()
TextFormatUpdateEvent
: 
ƒ TextFormatUpdateEvent()
TextMetrics
: 
ƒ TextMetrics()
TextTrack
: 
ƒ TextTrack()
TextTrackCue
: 
ƒ TextTrackCue()
TextTrackCueList
: 
ƒ TextTrackCueList()
TextTrackList
: 
ƒ TextTrackList()
TextUpdateEvent
: 
ƒ TextUpdateEvent()
TimeRanges
: 
ƒ TimeRanges()
TimestampTrigger
: 
ƒ TimestampTrigger()
ToggleEvent
: 
ƒ ToggleEvent()
Touch
: 
ƒ Touch()
TouchEvent
: 
ƒ TouchEvent()
TouchList
: 
ƒ TouchList()
TrackDefault
: 
ƒ TrackDefault()
TrackDefaultList
: 
ƒ TrackDefaultList()
TrackEvent
: 
ƒ TrackEvent()
TransformStream
: 
ƒ TransformStream()
TransformStreamDefaultController
: 
ƒ TransformStreamDefaultController()
TransitionEvent
: 
ƒ TransitionEvent()
Translator
: 
ƒ Translator()
TreeWalker
: 
ƒ TreeWalker()
TrustedHTML
: 
ƒ TrustedHTML()
TrustedScript
: 
ƒ TrustedScript()
TrustedScriptURL
: 
ƒ TrustedScriptURL()
TrustedTypePolicy
: 
ƒ TrustedTypePolicy()
TrustedTypePolicyFactory
: 
ƒ TrustedTypePolicyFactory()
TypeError
: 
ƒ TypeError()
UIEvent
: 
ƒ UIEvent()
URIError
: 
ƒ URIError()
URL
: 
ƒ URL()
URLPattern
: 
ƒ URLPattern()
URLSearchParams
: 
ƒ URLSearchParams()
USB
: 
ƒ USB()
USBAlternateInterface
: 
ƒ USBAlternateInterface()
USBConfiguration
: 
ƒ USBConfiguration()
USBConnectionEvent
: 
ƒ USBConnectionEvent()
USBDevice
: 
ƒ USBDevice()
USBEndpoint
: 
ƒ USBEndpoint()
USBInTransferResult
: 
ƒ USBInTransferResult()
USBInterface
: 
ƒ USBInterface()
USBIsochronousInTransferPacket
: 
ƒ USBIsochronousInTransferPacket()
USBIsochronousInTransferResult
: 
ƒ USBIsochronousInTransferResult()
USBIsochronousOutTransferPacket
: 
ƒ USBIsochronousOutTransferPacket()
USBIsochronousOutTransferResult
: 
ƒ USBIsochronousOutTransferResult()
USBOutTransferResult
: 
ƒ USBOutTransferResult()
Uint8Array
: 
ƒ Uint8Array()
Uint8ClampedArray
: 
ƒ Uint8ClampedArray()
Uint16Array
: 
ƒ Uint16Array()
Uint32Array
: 
ƒ Uint32Array()
UserActivation
: 
ƒ UserActivation()
VTTCue
: 
ƒ VTTCue()
VTTRegion
: 
ƒ VTTRegion()
ValidityState
: 
ƒ ValidityState()
VideoColorSpace
: 
ƒ VideoColorSpace()
VideoDecoder
: 
ƒ VideoDecoder()
VideoEncoder
: 
ƒ VideoEncoder()
VideoEncoderBuffer
: 
ƒ VideoEncoderBuffer()
VideoFrame
: 
ƒ VideoFrame()
VideoPlaybackQuality
: 
ƒ VideoPlaybackQuality()
VideoTrack
: 
ƒ VideoTrack()
VideoTrackList
: 
ƒ VideoTrackList()
ViewTimeline
: 
ƒ ViewTimeline()
ViewTransition
: 
ƒ ViewTransition()
ViewTransitionTypeSet
: 
ƒ ViewTransitionTypeSet()
Viewport
: 
ƒ Viewport()
VirtualKeyboard
: 
ƒ VirtualKeyboard()
VirtualKeyboardGeometryChangeEvent
: 
ƒ VirtualKeyboardGeometryChangeEvent()
VisibilityStateEntry
: 
ƒ VisibilityStateEntry()
VisualViewport
: 
ƒ VisualViewport()
WGSLLanguageFeatures
: 
ƒ WGSLLanguageFeatures()
WakeLock
: 
ƒ WakeLock()
WakeLockSentinel
: 
ƒ WakeLockSentinel()
WaveShaperNode
: 
ƒ WaveShaperNode()
WeakMap
: 
ƒ WeakMap()
WeakRef
: 
ƒ WeakRef()
WeakSet
: 
ƒ WeakSet()
WebAssembly
: 
WebAssembly {compile: ƒ, validate: ƒ, instantiate: ƒ, compileStreaming: ƒ, instantiateStreaming: ƒ, …}
WebGL2RenderingContext
: 
ƒ WebGL2RenderingContext()
WebGLActiveInfo
: 
ƒ WebGLActiveInfo()
WebGLBuffer
: 
ƒ WebGLBuffer()
WebGLContextEvent
: 
ƒ WebGLContextEvent()
WebGLFramebuffer
: 
ƒ WebGLFramebuffer()
WebGLObject
: 
ƒ WebGLObject()
WebGLProgram
: 
ƒ WebGLProgram()
WebGLQuery
: 
ƒ WebGLQuery()
WebGLRenderbuffer
: 
ƒ WebGLRenderbuffer()
WebGLRenderingContext
: 
ƒ WebGLRenderingContext()
WebGLSampler
: 
ƒ WebGLSampler()
WebGLShader
: 
ƒ WebGLShader()
WebGLShaderPrecisionFormat
: 
ƒ WebGLShaderPrecisionFormat()
WebGLSync
: 
ƒ WebGLSync()
WebGLTexture
: 
ƒ WebGLTexture()
WebGLTransformFeedback
: 
ƒ WebGLTransformFeedback()
WebGLUniformLocation
: 
ƒ WebGLUniformLocation()
WebGLVertexArrayObject
: 
ƒ WebGLVertexArrayObject()
WebKitCSSMatrix
: 
ƒ DOMMatrix()
WebKitMutationObserver
: 
ƒ MutationObserver()
WebSocket
: 
ƒ WebSocket()
WebSocketError
: 
ƒ WebSocketError()
WebSocketStream
: 
ƒ WebSocketStream()
WebTransport
: 
ƒ WebTransport()
WebTransportBidirectionalStream
: 
ƒ WebTransportBidirectionalStream()
WebTransportDatagramDuplexStream
: 
ƒ WebTransportDatagramDuplexStream()
WebTransportError
: 
ƒ WebTransportError()
WheelEvent
: 
ƒ WheelEvent()
Window
: 
ƒ Window()
WindowControlsOverlay
: 
ƒ WindowControlsOverlay()
WindowControlsOverlayGeometryChangeEvent
: 
ƒ WindowControlsOverlayGeometryChangeEvent()
Worker
: 
ƒ Worker()
Worklet
: 
ƒ Worklet()
WritableStream
: 
ƒ WritableStream()
WritableStreamDefaultController
: 
ƒ WritableStreamDefaultController()
WritableStreamDefaultWriter
: 
ƒ WritableStreamDefaultWriter()
Writer
: 
ƒ Writer()
XMLDocument
: 
ƒ XMLDocument()
XMLHttpRequest
: 
ƒ XMLHttpRequest()
XMLHttpRequestEventTarget
: 
ƒ XMLHttpRequestEventTarget()
XMLHttpRequestUpload
: 
ƒ XMLHttpRequestUpload()
XMLSerializer
: 
ƒ XMLSerializer()
XPathEvaluator
: 
ƒ XPathEvaluator()
XPathExpression
: 
ƒ XPathExpression()
XPathResult
: 
ƒ XPathResult()
XRAnchor
: 
ƒ XRAnchor()
XRAnchorSet
: 
ƒ XRAnchorSet()
XRBoundedReferenceSpace
: 
ƒ XRBoundedReferenceSpace()
XRCPUDepthInformation
: 
ƒ XRCPUDepthInformation()
XRCamera
: 
ƒ XRCamera()
XRCompositionLayer
: 
ƒ XRCompositionLayer()
XRDOMOverlayState
: 
ƒ XRDOMOverlayState()
XRDepthInformation
: 
ƒ XRDepthInformation()
XRFrame
: 
ƒ XRFrame()
XRGPUBinding
: 
ƒ XRGPUBinding()
XRGPUSubImage
: 
ƒ XRGPUSubImage()
XRHand
: 
ƒ XRHand()
XRHitTestResult
: 
ƒ XRHitTestResult()
XRHitTestSource
: 
ƒ XRHitTestSource()
XRImageTrackingResult
: 
ƒ XRImageTrackingResult()
XRInputSource
: 
ƒ XRInputSource()
XRInputSourceArray
: 
ƒ XRInputSourceArray()
XRInputSourceEvent
: 
ƒ XRInputSourceEvent()
XRInputSourcesChangeEvent
: 
ƒ XRInputSourcesChangeEvent()
XRJointPose
: 
ƒ XRJointPose()
XRJointSpace
: 
ƒ XRJointSpace()
XRLayer
: 
ƒ XRLayer()
XRLightEstimate
: 
ƒ XRLightEstimate()
XRLightProbe
: 
ƒ XRLightProbe()
XRPlane
: 
ƒ XRPlane()
XRPlaneSet
: 
ƒ XRPlaneSet()
XRPose
: 
ƒ XRPose()
XRProjectionLayer
: 
ƒ XRProjectionLayer()
XRRay
: 
ƒ XRRay()
XRReferenceSpace
: 
ƒ XRReferenceSpace()
XRReferenceSpaceEvent
: 
ƒ XRReferenceSpaceEvent()
XRRenderState
: 
ƒ XRRenderState()
XRRigidTransform
: 
ƒ XRRigidTransform()
XRSession
: 
ƒ XRSession()
XRSessionEvent
: 
ƒ XRSessionEvent()
XRSpace
: 
ƒ XRSpace()
XRSubImage
: 
ƒ XRSubImage()
XRSystem
: 
ƒ XRSystem()
XRTransientInputHitTestResult
: 
ƒ XRTransientInputHitTestResult()
XRTransientInputHitTestSource
: 
ƒ XRTransientInputHitTestSource()
XRView
: 
ƒ XRView()
XRViewerPose
: 
ƒ XRViewerPose()
XRViewport
: 
ƒ XRViewport()
XRWebGLBinding
: 
ƒ XRWebGLBinding()
XRWebGLDepthInformation
: 
ƒ XRWebGLDepthInformation()
XRWebGLLayer
: 
ƒ XRWebGLLayer()
XRWebGLSubImage
: 
ƒ XRWebGLSubImage()
XSLTProcessor
: 
ƒ XSLTProcessor()
console
: 
console {debug: ƒ, error: ƒ, info: ƒ, log: ƒ, warn: ƒ, …}
decodeURI
: 
ƒ decodeURI()
decodeURIComponent
: 
ƒ decodeURIComponent()
encodeURI
: 
ƒ encodeURI()
encodeURIComponent
: 
ƒ encodeURIComponent()
escape
: 
ƒ escape()
eval
: 
ƒ eval()
globalThis
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
isFinite
: 
ƒ isFinite()
isNaN
: 
ƒ isNaN()
offscreenBuffering
: 
true
parseFloat
: 
ƒ parseFloat()
parseInt
: 
ƒ parseInt()
undefined
: 
undefined
unescape
: 
ƒ unescape()
webkitMediaStream
: 
ƒ MediaStream()
webkitRTCPeerConnection
: 
ƒ RTCPeerConnection()
webkitSpeechGrammar
: 
ƒ SpeechGrammar()
webkitSpeechGrammarList
: 
ƒ SpeechGrammarList()
webkitSpeechRecognition
: 
ƒ SpeechRecognition()
webkitSpeechRecognitionError
: 
ƒ SpeechRecognitionErrorEvent()
webkitSpeechRecognitionEvent
: 
ƒ SpeechRecognitionEvent()
webkitURL
: 
ƒ URL()
[[Prototype]]
: 
Window
trustedTypes
: 
TrustedTypePolicyFactory
defaultPolicy
: 
null
emptyHTML
: 
TrustedHTML ""
emptyScript
: 
TrustedScript ""
onbeforecreatepolicy
: 
null
[[Prototype]]
: 
TrustedTypePolicyFactory
viewport
: 
Viewport
segments
: 
[DOMRect]
[[Prototype]]
: 
Viewport
visualViewport
: 
VisualViewport
height
: 
2109.333251953125
offsetLeft
: 
0
offsetTop
: 
0
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
pageLeft
: 
0
pageTop
: 
0
scale
: 
1
width
: 
2689.333251953125
[[Prototype]]
: 
VisualViewport
webkitCancelAnimationFrame
: 
ƒ webkitCancelAnimationFrame()
length
: 
1
name
: 
"webkitCancelAnimationFrame"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
webkitRequestAnimationFrame
: 
ƒ webkitRequestAnimationFrame()
length
: 
1
name
: 
"webkitRequestAnimationFrame"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
webkitRequestFileSystem
: 
ƒ webkitRequestFileSystem()
length
: 
3
name
: 
"webkitRequestFileSystem"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
webkitResolveLocalFileSystemURL
: 
ƒ webkitResolveLocalFileSystemURL()
length
: 
2
name
: 
"webkitResolveLocalFileSystemURL"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
window
: 
Window
alert
: 
ƒ alert()
length
: 
0
name
: 
"alert"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
atob
: 
ƒ atob()
length
: 
1
name
: 
"atob"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
blur
: 
ƒ blur()
length
: 
0
name
: 
"blur"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
btoa
: 
ƒ btoa()
length
: 
1
name
: 
"btoa"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caches
: 
CacheStorage
[[Prototype]]
: 
CacheStorage
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
length
: 
1
name
: 
"cancelAnimationFrame"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
cancelIdleCallback
: 
ƒ cancelIdleCallback()
length
: 
1
name
: 
"cancelIdleCallback"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
captureEvents
: 
ƒ captureEvents()
length
: 
0
name
: 
"captureEvents"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
chrome
: 
csi
: 
ƒ ()
getVariableValue
: 
ƒ ()
loadTimes
: 
ƒ ()
perplexity
: 
{analytics: {…}, blacklist: {…}, shortcuts: {…}, system: {…}}
runtime
: 
{ContextType: {…}, OnInstalledReason: {…}, OnRestartRequiredReason: {…}, …}
send
: 
ƒ ()
timeTicks
: 
{nowInMicroseconds: ƒ}
[[Prototype]]
: 
Object
clearInterval
: 
ƒ clearInterval()
length
: 
0
name
: 
"clearInterval"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clearTimeout
: 
ƒ clearTimeout()
length
: 
0
name
: 
"clearTimeout"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clientInformation
: 
Navigator
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth {onadvertisementreceived: null}
clipboard
: 
Clipboard {}
connection
: 
NetworkInformation {onchange: null, effectiveType: '4g', rtt: 50, downlink: 10, saveData: false, …}
cookieEnabled
: 
true
credentials
: 
CredentialsContainer {}
deprecatedRunAdAuctionEnforcesKAnonymity
: 
false
deviceMemory
: 
8
devicePosture
: 
DevicePosture {type: 'continuous', onchange: null}
doNotTrack
: 
null
geolocation
: 
Geolocation {}
gpu
: 
GPU {wgslLanguageFeatures: WGSLLanguageFeatures}
hardwareConcurrency
: 
8
hid
: 
HID {onconnect: null, ondisconnect: null}
identity
: 
CredentialsContainer {}
ink
: 
Ink {}
keyboard
: 
Keyboard {}
language
: 
"en-US"
languages
: 
(2) ['en-US', 'en']
locks
: 
LockManager {}
login
: 
NavigatorLogin {}
managed
: 
NavigatorManagedData {onmanagedconfigurationchange: null}
maxTouchPoints
: 
0
mediaCapabilities
: 
MediaCapabilities {}
mediaDevices
: 
MediaDevices {ondevicechange: null}
mediaSession
: 
MediaSession {metadata: null, playbackState: 'none'}
mimeTypes
: 
MimeTypeArray {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, length: 2}
onLine
: 
true
pdfViewerEnabled
: 
true
permissions
: 
Permissions {}
platform
: 
"Win32"
plugins
: 
PluginArray {0: Plugin, 1: Plugin, 2: Plugin, 3: Plugin, 4: Plugin, PDF Viewer: Plugin, Chrome PDF Viewer: Plugin, Chromium PDF Viewer: Plugin, Microsoft Edge PDF Viewer: Plugin, WebKit built-in PDF: Plugin, …}
preferences
: 
PreferenceManager {colorScheme: PreferenceObject, contrast: PreferenceObject, reducedMotion: PreferenceObject, reducedTransparency: PreferenceObject, reducedData: PreferenceObject}
presentation
: 
Presentation {defaultRequest: null, receiver: null}
product
: 
"Gecko"
productSub
: 
"20030107"
protectedAudience
: 
ProtectedAudience {}
scheduling
: 
Scheduling {}
serial
: 
Serial {onconnect: null, ondisconnect: null}
serviceWorker
: 
ServiceWorkerContainer {controller: null, ready: Promise, oncontrollerchange: null, onmessage: null, onmessageerror: null}
storage
: 
StorageManager {}
storageBuckets
: 
StorageBucketManager {}
usb
: 
USB {onconnect: null, ondisconnect: null}
userActivation
: 
UserActivation {hasBeenActive: true, isActive: false}
userAgent
: 
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
userAgentData
: 
NavigatorUAData {brands: Array(3), mobile: false, platform: 'Windows'}
vendor
: 
"Google Inc."
vendorSub
: 
""
virtualKeyboard
: 
VirtualKeyboard {boundingRect: DOMRect, overlaysContent: false, ongeometrychange: null}
wakeLock
: 
WakeLock {}
webdriver
: 
false
webkitPersistentStorage
: 
DeprecatedStorageQuota {}
webkitTemporaryStorage
: 
DeprecatedStorageQuota {}
windowControlsOverlay
: 
WindowControlsOverlay {visible: false, ongeometrychange: null}
xr
: 
XRSystem {ondevicechange: null}
[[Prototype]]
: 
Navigator
close
: 
ƒ close()
length
: 
0
name
: 
"close"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
closed
: 
false
confirm
: 
ƒ confirm()
length
: 
0
name
: 
"confirm"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
cookieStore
: 
CookieStore
onchange
: 
null
[[Prototype]]
: 
CookieStore
cr
: 
webUIListenerCallback
: 
ƒ webUIListenerCallback(event, ...args)
webUIResponse
: 
ƒ webUIResponse(id, isSuccess, response)
[[Prototype]]
: 
Object
createImageBitmap
: 
ƒ createImageBitmap()
length
: 
1
name
: 
"createImageBitmap"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
credentialless
: 
false
crossOriginIsolated
: 
false
crypto
: 
Crypto
subtle
: 
SubtleCrypto {}
[[Prototype]]
: 
Crypto
customElements
: 
CustomElementRegistry
[[Prototype]]
: 
CustomElementRegistry
devicePixelRatio
: 
0.75
document
: 
document
documentPictureInPicture
: 
DocumentPictureInPicture
onenter
: 
null
window
: 
null
[[Prototype]]
: 
DocumentPictureInPicture
event
: 
undefined
external
: 
External
[[Prototype]]
: 
External
fence
: 
null
fetch
: 
ƒ fetch()
length
: 
1
name
: 
"fetch"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
fetchLater
: 
ƒ fetchLater()
length
: 
1
name
: 
"fetchLater"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
find
: 
ƒ find()
length
: 
0
name
: 
"find"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
focus
: 
ƒ focus()
length
: 
0
name
: 
"focus"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
frameElement
: 
null
frames
: 
Window
alert
: 
ƒ alert()
length
: 
0
name
: 
"alert"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
atob
: 
ƒ atob()
length
: 
1
name
: 
"atob"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
blur
: 
ƒ blur()
length
: 
0
name
: 
"blur"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
btoa
: 
ƒ btoa()
length
: 
1
name
: 
"btoa"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caches
: 
CacheStorage {}
cancelAnimationFrame
: 
ƒ cancelAnimationFrame()
cancelIdleCallback
: 
ƒ cancelIdleCallback()
length
: 
1
name
: 
"cancelIdleCallback"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
captureEvents
: 
ƒ captureEvents()
length
: 
0
name
: 
"captureEvents"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
chrome
: 
csi
: 
ƒ ()
length
: 
0
name
: 
""
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getVariableValue
: 
ƒ ()
length
: 
0
name
: 
""
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
loadTimes
: 
ƒ ()
length
: 
0
name
: 
""
prototype
: 
{}
arguments
: 
null
caller
: 
null
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
perplexity
: 
analytics
: 
{recordEvent: ƒ}
blacklist
: 
{BlacklistSource: {…}, isDomainInBlacklist: ƒ}
shortcuts
: 
{Modifier: {…}, Source: {…}, clearShortcut: ƒ, getCurrentShortcuts: ƒ, setShortcut: ƒ}
system
: 
{bringWindowToTop: ƒ, getBrowserPath: ƒ, …}
[[Prototype]]
: 
Object
runtime
: 
ContextType
: 
{BACKGROUND: 'BACKGROUND', DEVELOPER_TOOLS: 'DEVELOPER_TOOLS', OFFSCREEN_DOCUMENT: 'OFFSCREEN_DOCUMENT', POPUP: 'POPUP', SIDE_PANEL: 'SIDE_PANEL', …}
OnInstalledReason
: 
{CHROME_UPDATE: 'chrome_update', INSTALL: 'install', SHARED_MODULE_UPDATE: 'shared_module_update', UPDATE: 'update'}
OnRestartRequiredReason
: 
{APP_UPDATE: 'app_update', OS_UPDATE: 'os_update', PERIODIC: 'periodic'}
PlatformArch
: 
{ARM: 'arm', ARM64: 'arm64', MIPS: 'mips', MIPS64: 'mips64', X86_32: 'x86-32', …}
PlatformNaclArch
: 
{ARM: 'arm', MIPS: 'mips', MIPS64: 'mips64', X86_32: 'x86-32', X86_64: 'x86-64'}
PlatformOs
: 
{ANDROID: 'android', CROS: 'cros', FUCHSIA: 'fuchsia', LINUX: 'linux', MAC: 'mac', …}
RequestUpdateCheckStatus
: 
{NO_UPDATE: 'no_update', THROTTLED: 'throttled', UPDATE_AVAILABLE: 'update_available'}
dynamicId
: 
(...)
id
: 
(...)
get dynamicId
: 
ƒ ()
set dynamicId
: 
ƒ ()
get id
: 
ƒ ()
set id
: 
ƒ ()
[[Prototype]]
: 
Object
send
: 
ƒ ()
length
: 
0
name
: 
""
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
timeTicks
: 
nowInMicroseconds
: 
ƒ ()
[[Prototype]]
: 
Object
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
(...)
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
clearInterval
: 
ƒ clearInterval()
length
: 
0
name
: 
"clearInterval"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clearTimeout
: 
ƒ clearTimeout()
length
: 
0
name
: 
"clearTimeout"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clientInformation
: 
Navigator
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth {onadvertisementreceived: null}
clipboard
: 
Clipboard {}
connection
: 
NetworkInformation {onchange: null, effectiveType: '4g', rtt: 50, downlink: 10, saveData: false, …}
cookieEnabled
: 
true
credentials
: 
CredentialsContainer {}
deprecatedRunAdAuctionEnforcesKAnonymity
: 
false
deviceMemory
: 
8
devicePosture
: 
DevicePosture {type: 'continuous', onchange: null}
doNotTrack
: 
null
geolocation
: 
Geolocation {}
gpu
: 
GPU {wgslLanguageFeatures: WGSLLanguageFeatures}
hardwareConcurrency
: 
8
hid
: 
HID {onconnect: null, ondisconnect: null}
identity
: 
CredentialsContainer {}
ink
: 
Ink {}
keyboard
: 
Keyboard {}
language
: 
"en-US"
languages
: 
(2) ['en-US', 'en']
locks
: 
LockManager {}
login
: 
NavigatorLogin {}
managed
: 
NavigatorManagedData {onmanagedconfigurationchange: null}
maxTouchPoints
: 
0
mediaCapabilities
: 
MediaCapabilities {}
mediaDevices
: 
MediaDevices {ondevicechange: null}
mediaSession
: 
MediaSession {metadata: null, playbackState: 'none'}
mimeTypes
: 
MimeTypeArray {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, length: 2}
onLine
: 
true
pdfViewerEnabled
: 
true
permissions
: 
Permissions {}
platform
: 
"Win32"
plugins
: 
PluginArray {0: Plugin, 1: Plugin, 2: Plugin, 3: Plugin, 4: Plugin, PDF Viewer: Plugin, Chrome PDF Viewer: Plugin, Chromium PDF Viewer: Plugin, Microsoft Edge PDF Viewer: Plugin, WebKit built-in PDF: Plugin, …}
preferences
: 
PreferenceManager {colorScheme: PreferenceObject, contrast: PreferenceObject, reducedMotion: PreferenceObject, reducedTransparency: PreferenceObject, reducedData: PreferenceObject}
presentation
: 
Presentation {defaultRequest: null, receiver: null}
product
: 
"Gecko"
productSub
: 
"20030107"
protectedAudience
: 
ProtectedAudience {}
scheduling
: 
Scheduling {}
serial
: 
Serial {onconnect: null, ondisconnect: null}
serviceWorker
: 
ServiceWorkerContainer {controller: null, ready: Promise, oncontrollerchange: null, onmessage: null, onmessageerror: null}
storage
: 
StorageManager {}
storageBuckets
: 
StorageBucketManager {}
usb
: 
USB {onconnect: null, ondisconnect: null}
userActivation
: 
UserActivation {hasBeenActive: true, isActive: false}
userAgent
: 
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
userAgentData
: 
NavigatorUAData {brands: Array(3), mobile: false, platform: 'Windows'}
vendor
: 
"Google Inc."
vendorSub
: 
""
virtualKeyboard
: 
VirtualKeyboard {boundingRect: DOMRect, overlaysContent: false, ongeometrychange: null}
wakeLock
: 
WakeLock {}
webdriver
: 
false
webkitPersistentStorage
: 
DeprecatedStorageQuota {}
webkitTemporaryStorage
: 
DeprecatedStorageQuota {}
windowControlsOverlay
: 
WindowControlsOverlay {visible: false, ongeometrychange: null}
xr
: 
XRSystem {ondevicechange: null}
[[Prototype]]
: 
Navigator
close
: 
ƒ close()
length
: 
0
name
: 
"close"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
closed
: 
false
confirm
: 
ƒ confirm()
cookieStore
: 
CookieStore {onchange: null}
cr
: 
{webUIResponse: ƒ, webUIListenerCallback: ƒ}
createImageBitmap
: 
ƒ createImageBitmap()
credentialless
: 
false
crossOriginIsolated
: 
false
crypto
: 
Crypto {subtle: SubtleCrypto}
customElements
: 
CustomElementRegistry {}
devicePixelRatio
: 
0.75
document
: 
document
documentPictureInPicture
: 
DocumentPictureInPicture {window: null, onenter: null}
event
: 
undefined
external
: 
External {}
fence
: 
null
fetch
: 
ƒ fetch()
fetchLater
: 
ƒ fetchLater()
find
: 
ƒ find()
focus
: 
ƒ focus()
frameElement
: 
null
frames
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
getComputedStyle
: 
ƒ getComputedStyle()
getScreenDetails
: 
ƒ getScreenDetails()
getSelection
: 
ƒ getSelection()
history
: 
History {length: 2, scrollRestoration: 'auto', state: null}
indexedDB
: 
IDBFactory {}
innerHeight
: 
2109
innerWidth
: 
2689
isSecureContext
: 
true
launchQueue
: 
LaunchQueue {}
length
: 
0
litElementVersions
: 
['4.2.0']
litHtmlVersions
: 
['3.3.0']
litPropertyMetadata
: 
WeakMap {}
localStorage
: 
Storage {length: 0}
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
locationbar
: 
BarProp {visible: true}
matchMedia
: 
ƒ matchMedia()
menubar
: 
BarProp {visible: true}
moveBy
: 
ƒ moveBy()
moveTo
: 
ƒ moveTo()
name
: 
""
navigation
: 
Navigation {currentEntry: NavigationHistoryEntry, transition: null, activation: NavigationActivation, canGoBack: false, canGoForward: false, …}
navigator
: 
Navigator {vendorSub: '', productSub: '20030107', vendor: 'Google Inc.', maxTouchPoints: 0, scheduling: Scheduling, …}
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onappinstalled
: 
null
onauxclick
: 
null
onbeforeinput
: 
null
onbeforeinstallprompt
: 
null
onbeforematch
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncuechange
: 
null
ondblclick
: 
null
ondevicemotion
: 
null
ondeviceorientation
: 
null
ondeviceorientationabsolute
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpagereveal
: 
null
onpageshow
: 
null
onpageswap
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onpopstate
: 
null
onprogress
: 
null
onratechange
: 
null
onrejectionhandled
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onstorage
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontimezonechange
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onunhandledrejection
: 
null
onunload
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
open
: 
ƒ open()
opener
: 
null
origin
: 
"chrome://flags"
originAgentCluster
: 
false
outerHeight
: 
1752
outerWidth
: 
3200
pageXOffset
: 
0
pageYOffset
: 
0
parent
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
performance
: 
Performance {timeOrigin: 1758565909398.9, onresourcetimingbufferfull: null, timing: PerformanceTiming, navigation: PerformanceNavigation, memory: MemoryInfo, …}
personalbar
: 
BarProp {visible: true}
popinContextType
: 
ƒ popinContextType()
popinContextTypesSupported
: 
ƒ popinContextTypesSupported()
postMessage
: 
ƒ postMessage()
print
: 
ƒ print()
privateAttribution
: 
PrivateAttribution {}
prompt
: 
ƒ prompt()
queryLocalFonts
: 
ƒ queryLocalFonts()
(...)
getComputedStyle
: 
ƒ getComputedStyle()
length
: 
1
name
: 
"getComputedStyle"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getScreenDetails
: 
ƒ getScreenDetails()
length
: 
0
name
: 
"getScreenDetails"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getSelection
: 
ƒ getSelection()
length
: 
0
name
: 
"getSelection"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
history
: 
History
length
: 
2
scrollRestoration
: 
"auto"
state
: 
null
[[Prototype]]
: 
History
indexedDB
: 
IDBFactory
[[Prototype]]
: 
IDBFactory
innerHeight
: 
2109
innerWidth
: 
2689
isSecureContext
: 
true
launchQueue
: 
LaunchQueue
[[Prototype]]
: 
LaunchQueue
length
: 
0
litElementVersions
: 
Array(1)
0
: 
"4.2.0"
length
: 
1
[[Prototype]]
: 
Array(0)
at
: 
ƒ at()
concat
: 
ƒ concat()
length
: 
1
name
: 
"concat"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ Array()
from
: 
ƒ from()
fromAsync
: 
ƒ fromAsync()
isArray
: 
ƒ isArray()
length
: 
1
name
: 
"Array"
of
: 
ƒ of()
prototype
: 
[at: ƒ, concat: ƒ, copyWithin: ƒ, fill: ƒ, find: ƒ, …]
Symbol(Symbol.species)
: 
ƒ Array()
Symbol(Symbol.species)
: 
ƒ Array()
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
copyWithin
: 
ƒ copyWithin()
length
: 
2
name
: 
"copyWithin"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
entries
: 
ƒ entries()
length
: 
0
name
: 
"entries"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
every
: 
ƒ every()
fill
: 
ƒ fill()
length
: 
1
name
: 
"fill"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
filter
: 
ƒ filter()
length
: 
1
name
: 
"filter"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
find
: 
ƒ find()
length
: 
1
name
: 
"find"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
findIndex
: 
ƒ findIndex()
length
: 
1
name
: 
"findIndex"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
findLast
: 
ƒ findLast()
length
: 
1
name
: 
"findLast"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
findLastIndex
: 
ƒ findLastIndex()
length
: 
1
name
: 
"findLastIndex"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
flat
: 
ƒ flat()
length
: 
0
name
: 
"flat"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
flatMap
: 
ƒ flatMap()
length
: 
1
name
: 
"flatMap"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
forEach
: 
ƒ forEach()
length
: 
1
name
: 
"forEach"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
includes
: 
ƒ includes()
length
: 
1
name
: 
"includes"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
indexOf
: 
ƒ indexOf()
length
: 
1
name
: 
"indexOf"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
join
: 
ƒ join()
length
: 
1
name
: 
"join"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
keys
: 
ƒ keys()
length
: 
0
name
: 
"keys"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
lastIndexOf
: 
ƒ lastIndexOf()
length
: 
1
name
: 
"lastIndexOf"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
0
map
: 
ƒ map()
pop
: 
ƒ pop()
push
: 
ƒ push()
reduce
: 
ƒ reduce()
reduceRight
: 
ƒ reduceRight()
reverse
: 
ƒ reverse()
shift
: 
ƒ shift()
slice
: 
ƒ slice()
some
: 
ƒ some()
sort
: 
ƒ sort()
splice
: 
ƒ splice()
toLocaleString
: 
ƒ toLocaleString()
toReversed
: 
ƒ toReversed()
toSorted
: 
ƒ toSorted()
toSpliced
: 
ƒ toSpliced()
toString
: 
ƒ toString()
unshift
: 
ƒ unshift()
values
: 
ƒ values()
with
: 
ƒ with()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.unscopables)
: 
{at: true, copyWithin: true, entries: true, fill: true, find: true, …}
[[Prototype]]
: 
Object
litHtmlVersions
: 
Array(1)
0
: 
"3.3.0"
length
: 
1
[[Prototype]]
: 
Array(0)
litPropertyMetadata
: 
WeakMap
[[Entries]]
No properties
[[Prototype]]
: 
WeakMap
localStorage
: 
Storage
length
: 
0
[[Prototype]]
: 
Storage
location
: 
Location
ancestorOrigins
: 
DOMStringList {length: 0}
assign
: 
ƒ assign()
hash
: 
""
host
: 
"flags"
hostname
: 
"flags"
href
: 
"chrome://flags/"
origin
: 
"chrome://flags"
pathname
: 
"/"
port
: 
""
protocol
: 
"chrome:"
reload
: 
ƒ reload()
replace
: 
ƒ replace()
search
: 
""
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
Symbol(Symbol.toPrimitive)
: 
undefined
[[Prototype]]
: 
Location
locationbar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
matchMedia
: 
ƒ matchMedia()
length
: 
1
name
: 
"matchMedia"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
menubar
: 
BarProp
visible
: 
true
[[Prototype]]
: 
BarProp
moveBy
: 
ƒ moveBy()
length
: 
2
name
: 
"moveBy"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
moveTo
: 
ƒ moveTo()
length
: 
2
name
: 
"moveTo"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
name
: 
""
navigation
: 
Navigation
activation
: 
NavigationActivation {entry: NavigationHistoryEntry, from: NavigationHistoryEntry, navigationType: 'traverse'}
canGoBack
: 
false
canGoForward
: 
false
currentEntry
: 
NavigationHistoryEntry {key: 'b4581bbd-628b-4b66-8c1a-b983f0325c4f', id: 'd029303d-ddb4-4d96-9aca-8f2c7e62109f', url: 'chrome://flags/', index: 0, sameDocument: true, …}
oncurrententrychange
: 
null
onnavigate
: 
null
onnavigateerror
: 
null
onnavigatesuccess
: 
null
transition
: 
null
[[Prototype]]
: 
Navigation
navigator
: 
Navigator
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth
onadvertisementreceived
: 
null
[[Prototype]]
: 
Bluetooth
getAvailability
: 
ƒ getAvailability()
length
: 
0
name
: 
"getAvailability"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at getAvailability.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at getAvailability.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getDevices
: 
ƒ getDevices()
length
: 
0
name
: 
"getDevices"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at getDevices.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at getDevices.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
onadvertisementreceived
: 
(...)
requestDevice
: 
ƒ requestDevice()
length
: 
0
name
: 
"requestDevice"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at requestDevice.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at requestDevice.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
requestLEScan
: 
ƒ requestLEScan()
length
: 
0
name
: 
"requestLEScan"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at requestLEScan.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at requestLEScan.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ Bluetooth()
Symbol(Symbol.toStringTag)
: 
"Bluetooth"
get onadvertisementreceived
: 
ƒ onadvertisementreceived()
set onadvertisementreceived
: 
ƒ onadvertisementreceived()
[[Prototype]]
: 
EventTarget
clipboard
: 
Clipboard
[[Prototype]]
: 
Clipboard
read
: 
ƒ read()
length
: 
0
name
: 
"read"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at read.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at read.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
readText
: 
ƒ readText()
length
: 
0
name
: 
"readText"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at readText.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at readText.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
write
: 
ƒ write()
length
: 
1
name
: 
"write"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
writeText
: 
ƒ writeText()
length
: 
1
name
: 
"writeText"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ Clipboard()
Symbol(Symbol.toStringTag)
: 
"Clipboard"
[[Prototype]]
: 
EventTarget
connection
: 
NetworkInformation
downlink
: 
10
downlinkMax
: 
Infinity
effectiveType
: 
"4g"
onchange
: 
null
ontypechange
: 
null
rtt
: 
50
saveData
: 
false
type
: 
"wifi"
[[Prototype]]
: 
NetworkInformation
cookieEnabled
: 
true
credentials
: 
CredentialsContainer
[[Prototype]]
: 
CredentialsContainer
create
: 
ƒ create()
get
: 
ƒ ()
length
: 
0
name
: 
"get"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
preventSilentAccess
: 
ƒ preventSilentAccess()
length
: 
0
name
: 
"preventSilentAccess"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
store
: 
ƒ store()
length
: 
1
name
: 
"store"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ CredentialsContainer()
length
: 
0
name
: 
"CredentialsContainer"
prototype
: 
CredentialsContainer {Symbol(Symbol.toStringTag): 'CredentialsContainer', create: ƒ, get: ƒ, preventSilentAccess: ƒ, store: ƒ}
arguments
: 
null
caller
: 
null
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.toStringTag)
: 
"CredentialsContainer"
[[Prototype]]
: 
Object
deprecatedRunAdAuctionEnforcesKAnonymity
: 
false
deviceMemory
: 
8
devicePosture
: 
DevicePosture
onchange
: 
null
type
: 
"continuous"
[[Prototype]]
: 
DevicePosture
onchange
: 
(...)
type
: 
"continuous"
constructor
: 
ƒ DevicePosture()
Symbol(Symbol.toStringTag)
: 
"DevicePosture"
get onchange
: 
ƒ onchange()
set onchange
: 
ƒ onchange()
get type
: 
ƒ type()
[[Prototype]]
: 
EventTarget
doNotTrack
: 
null
geolocation
: 
Geolocation
[[Prototype]]
: 
Geolocation
clearWatch
: 
ƒ clearWatch()
length
: 
1
name
: 
"clearWatch"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getCurrentPosition
: 
ƒ getCurrentPosition()
length
: 
1
name
: 
"getCurrentPosition"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
watchPosition
: 
ƒ watchPosition()
length
: 
1
name
: 
"watchPosition"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ Geolocation()
Symbol(Symbol.toStringTag)
: 
"Geolocation"
[[Prototype]]
: 
Object
gpu
: 
GPU
wgslLanguageFeatures
: 
WGSLLanguageFeatures {size: 4}
[[Prototype]]
: 
GPU
hardwareConcurrency
: 
8
hid
: 
HID
onconnect
: 
null
ondisconnect
: 
null
[[Prototype]]
: 
HID
identity
: 
CredentialsContainer
[[Prototype]]
: 
CredentialsContainer
ink
: 
Ink
[[Prototype]]
: 
Ink
keyboard
: 
Keyboard
[[Prototype]]
: 
Keyboard
language
: 
"en-US"
languages
: 
Array(2)
0
: 
"en-US"
1
: 
"en"
length
: 
2
[[Prototype]]
: 
Array(0)
locks
: 
LockManager
[[Prototype]]
: 
LockManager
login
: 
NavigatorLogin
[[Prototype]]
: 
NavigatorLogin
managed
: 
NavigatorManagedData
onmanagedconfigurationchange
: 
null
[[Prototype]]
: 
NavigatorManagedData
maxTouchPoints
: 
0
mediaCapabilities
: 
MediaCapabilities
[[Prototype]]
: 
MediaCapabilities
mediaDevices
: 
MediaDevices
ondevicechange
: 
null
[[Prototype]]
: 
MediaDevices
mediaSession
: 
MediaSession
metadata
: 
null
playbackState
: 
"none"
[[Prototype]]
: 
MediaSession
mimeTypes
: 
MimeTypeArray
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
length
: 
2
[[Prototype]]
: 
MimeTypeArray
onLine
: 
true
pdfViewerEnabled
: 
true
permissions
: 
Permissions
[[Prototype]]
: 
Permissions
query
: 
ƒ query()
request
: 
ƒ request()
length
: 
1
name
: 
"request"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
requestAll
: 
ƒ requestAll()
length
: 
1
name
: 
"requestAll"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
revoke
: 
ƒ revoke()
length
: 
1
name
: 
"revoke"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ Permissions()
Symbol(Symbol.toStringTag)
: 
"Permissions"
[[Prototype]]
: 
Object
platform
: 
"Win32"
plugins
: 
PluginArray
0
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"PDF Viewer"
[[Prototype]]
: 
Plugin
1
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"Chrome PDF Viewer"
[[Prototype]]
: 
Plugin
2
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"Chromium PDF Viewer"
[[Prototype]]
: 
Plugin
3
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"Microsoft Edge PDF Viewer"
[[Prototype]]
: 
Plugin
4
: 
Plugin
0
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
1
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
application/pdf
: 
MimeType {type: 'application/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
text/pdf
: 
MimeType {type: 'text/pdf', suffixes: 'pdf', description: 'Portable Document Format', enabledPlugin: Plugin}
description
: 
"Portable Document Format"
filename
: 
"internal-pdf-viewer"
length
: 
2
name
: 
"WebKit built-in PDF"
[[Prototype]]
: 
Plugin
Chrome PDF Viewer
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'Chrome PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
Chromium PDF Viewer
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'Chromium PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
Microsoft Edge PDF Viewer
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'Microsoft Edge PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
PDF Viewer
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'PDF Viewer', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
WebKit built-in PDF
: 
Plugin {0: MimeType, 1: MimeType, application/pdf: MimeType, text/pdf: MimeType, name: 'WebKit built-in PDF', filename: 'internal-pdf-viewer', description: 'Portable Document Format', …}
length
: 
5
[[Prototype]]
: 
PluginArray
preferences
: 
PreferenceManager
colorScheme
: 
PreferenceObject {override: null, value: 'dark', validValues: Array(2), onchange: null}
contrast
: 
PreferenceObject {override: null, value: 'no-preference', validValues: Array(3), onchange: null}
reducedData
: 
PreferenceObject {override: null, value: 'no-preference', validValues: Array(2), onchange: null}
reducedMotion
: 
PreferenceObject {override: null, value: 'no-preference', validValues: Array(2), onchange: null}
reducedTransparency
: 
PreferenceObject {override: null, value: 'no-preference', validValues: Array(2), onchange: null}
[[Prototype]]
: 
PreferenceManager
presentation
: 
Presentation
defaultRequest
: 
null
receiver
: 
null
[[Prototype]]
: 
Presentation
product
: 
"Gecko"
productSub
: 
"20030107"
protectedAudience
: 
ProtectedAudience
[[Prototype]]
: 
ProtectedAudience
scheduling
: 
Scheduling
[[Prototype]]
: 
Scheduling
serial
: 
Serial
onconnect
: 
null
ondisconnect
: 
null
[[Prototype]]
: 
Serial
serviceWorker
: 
ServiceWorkerContainer
controller
: 
null
oncontrollerchange
: 
null
onmessage
: 
null
onmessageerror
: 
null
ready
: 
Promise
[[Prototype]]
: 
Promise
catch
: 
ƒ catch()
length
: 
1
name
: 
"catch"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ Promise()
all
: 
ƒ all()
length
: 
1
name
: 
"all"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
allSettled
: 
ƒ allSettled()
length
: 
1
name
: 
"allSettled"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
any
: 
ƒ any()
length
: 
1
name
: 
"Promise"
prototype
: 
Promise
catch
: 
ƒ catch()
constructor
: 
ƒ Promise()
finally
: 
ƒ finally()
then
: 
ƒ then()
Symbol(Symbol.toStringTag)
: 
"Promise"
[[Prototype]]
: 
Object
race
: 
ƒ race()
length
: 
1
name
: 
"race"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
reject
: 
ƒ reject()
length
: 
1
name
: 
"reject"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
resolve
: 
ƒ resolve()
length
: 
1
name
: 
"resolve"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
try
: 
ƒ try()
length
: 
1
name
: 
"try"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
withResolvers
: 
ƒ withResolvers()
length
: 
0
name
: 
"withResolvers"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.species)
: 
ƒ Promise()
all
: 
ƒ all()
allSettled
: 
ƒ allSettled()
any
: 
ƒ any()
length
: 
1
name
: 
"Promise"
prototype
: 
Promise {Symbol(Symbol.toStringTag): 'Promise', then: ƒ, catch: ƒ, finally: ƒ}
race
: 
ƒ race()
reject
: 
ƒ reject()
resolve
: 
ƒ resolve()
try
: 
ƒ try()
withResolvers
: 
ƒ withResolvers()
Symbol(Symbol.species)
: 
ƒ Promise()
Symbol(Symbol.species)
: 
ƒ Promise()
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.species)
: 
ƒ Promise()
all
: 
ƒ all()
allSettled
: 
ƒ allSettled()
any
: 
ƒ any()
length
: 
1
name
: 
"Promise"
prototype
: 
Promise {Symbol(Symbol.toStringTag): 'Promise', then: ƒ, catch: ƒ, finally: ƒ}
race
: 
ƒ race()
reject
: 
ƒ reject()
resolve
: 
ƒ resolve()
try
: 
ƒ try()
withResolvers
: 
ƒ withResolvers()
Symbol(Symbol.species)
: 
ƒ Promise()
Symbol(Symbol.species)
: 
ƒ Promise()
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
finally
: 
ƒ finally()
length
: 
1
name
: 
"finally"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
then
: 
ƒ then()
length
: 
2
name
: 
"then"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.toStringTag)
: 
"Promise"
[[Prototype]]
: 
Object
[[PromiseState]]
: 
"pending"
[[PromiseResult]]
: 
undefined
[[Prototype]]
: 
ServiceWorkerContainer
storage
: 
StorageManager
[[Prototype]]
: 
StorageManager
estimate
: 
ƒ estimate()
length
: 
0
name
: 
"estimate"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
length
: 
2
name
: 
"apply"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
arguments
: 
(...)
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
getDirectory
: 
ƒ getDirectory()
length
: 
0
name
: 
"getDirectory"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
(...)
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
(...)
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
persist
: 
ƒ persist()
length
: 
0
name
: 
"persist"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
persisted
: 
ƒ persisted()
length
: 
0
name
: 
"persisted"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ StorageManager()
Symbol(Symbol.toStringTag)
: 
"StorageManager"
[[Prototype]]
: 
Object
storageBuckets
: 
StorageBucketManager
[[Prototype]]
: 
StorageBucketManager
delete
: 
ƒ delete()
keys
: 
ƒ keys()
open
: 
ƒ open()
constructor
: 
ƒ StorageBucketManager()
Symbol(Symbol.toStringTag)
: 
"StorageBucketManager"
[[Prototype]]
: 
Object
usb
: 
USB
onconnect
: 
null
ondisconnect
: 
null
[[Prototype]]
: 
USB
userActivation
: 
UserActivation
hasBeenActive
: 
true
isActive
: 
false
[[Prototype]]
: 
UserActivation
hasBeenActive
: 
(...)
isActive
: 
(...)
constructor
: 
ƒ UserActivation()
Symbol(Symbol.toStringTag)
: 
"UserActivation"
get hasBeenActive
: 
ƒ hasBeenActive()
get isActive
: 
ƒ isActive()
[[Prototype]]
: 
Object
userAgent
: 
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
userAgentData
: 
NavigatorUAData
brands
: 
Array(3)
0
: 
{brand: 'Not;A=Brand', version: '99'}
1
: 
{brand: 'Google Chrome', version: '139'}
2
: 
{brand: 'Chromium', version: '139'}
length
: 
3
[[Prototype]]
: 
Array(0)
mobile
: 
false
platform
: 
"Windows"
[[Prototype]]
: 
NavigatorUAData
vendor
: 
"Google Inc."
vendorSub
: 
""
virtualKeyboard
: 
VirtualKeyboard
boundingRect
: 
DOMRect {x: 0, y: 0, width: 0, height: 0, top: 0, …}
ongeometrychange
: 
null
overlaysContent
: 
false
[[Prototype]]
: 
VirtualKeyboard
wakeLock
: 
WakeLock
[[Prototype]]
: 
WakeLock
webdriver
: 
false
webkitPersistentStorage
: 
DeprecatedStorageQuota
[[Prototype]]
: 
DeprecatedStorageQuota
webkitTemporaryStorage
: 
DeprecatedStorageQuota
[[Prototype]]
: 
DeprecatedStorageQuota
windowControlsOverlay
: 
WindowControlsOverlay
ongeometrychange
: 
null
visible
: 
false
[[Prototype]]
: 
WindowControlsOverlay
xr
: 
XRSystem
ondevicechange
: 
null
[[Prototype]]
: 
XRSystem
isSessionSupported
: 
ƒ isSessionSupported()
ondevicechange
: 
null
requestSession
: 
ƒ requestSession()
length
: 
1
name
: 
"requestSession"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at requestSession.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at requestSession.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ XRSystem()
Symbol(Symbol.toStringTag)
: 
"XRSystem"
get ondevicechange
: 
ƒ ondevicechange()
length
: 
0
name
: 
"get ondevicechange"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set ondevicechange
: 
ƒ ondevicechange()
length
: 
1
name
: 
"set ondevicechange"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
[[Prototype]]
: 
EventTarget
[[Prototype]]
: 
Navigator
adAuctionComponents
: 
ƒ adAuctionComponents()
appCodeName
: 
"Mozilla"
appName
: 
"Netscape"
appVersion
: 
"5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"
bluetooth
: 
Bluetooth
onadvertisementreceived
: 
null
[[Prototype]]
: 
Bluetooth
getAvailability
: 
ƒ getAvailability()
length
: 
0
name
: 
"getAvailability"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at getAvailability.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at getAvailability.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
getDevices
: 
ƒ getDevices()
length
: 
0
name
: 
"getDevices"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
onadvertisementreceived
: 
(...)
requestDevice
: 
ƒ requestDevice()
length
: 
0
name
: 
"requestDevice"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
requestLEScan
: 
ƒ requestLEScan()
length
: 
0
name
: 
"requestLEScan"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ Bluetooth()
Symbol(Symbol.toStringTag)
: 
"Bluetooth"
get onadvertisementreceived
: 
ƒ onadvertisementreceived()
set onadvertisementreceived
: 
ƒ onadvertisementreceived()
[[Prototype]]
: 
EventTarget
canLoadAdAuctionFencedFrame
: 
ƒ canLoadAdAuctionFencedFrame()
length
: 
0
name
: 
"canLoadAdAuctionFencedFrame"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
canShare
: 
ƒ canShare()
length
: 
0
name
: 
"canShare"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clearAppBadge
: 
ƒ clearAppBadge()
length
: 
0
name
: 
"clearAppBadge"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clearOriginJoinedAdInterestGroups
: 
ƒ clearOriginJoinedAdInterestGroups()
length
: 
1
name
: 
"clearOriginJoinedAdInterestGroups"
arguments
: 
(...)
caller
: 
(...)
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
clipboard
: 
Clipboard
[[Prototype]]
: 
Clipboard
connection
: 
NetworkInformation
downlink
: 
10
downlinkMax
: 
Infinity
effectiveType
: 
"4g"
onchange
: 
null
ontypechange
: 
null
rtt
: 
50
saveData
: 
false
type
: 
"wifi"
[[Prototype]]
: 
NetworkInformation
downlink
: 
(...)
downlinkMax
: 
(...)
effectiveType
: 
(...)
onchange
: 
(...)
ontypechange
: 
(...)
rtt
: 
(...)
saveData
: 
(...)
type
: 
(...)
constructor
: 
ƒ NetworkInformation()
Symbol(Symbol.toStringTag)
: 
"NetworkInformation"
get downlink
: 
ƒ downlink()
get downlinkMax
: 
ƒ downlinkMax()
get effectiveType
: 
ƒ effectiveType()
get onchange
: 
ƒ onchange()
set onchange
: 
ƒ onchange()
get ontypechange
: 
ƒ ontypechange()
set ontypechange
: 
ƒ ontypechange()
get rtt
: 
ƒ rtt()
get saveData
: 
ƒ saveData()
get type
: 
ƒ type()
[[Prototype]]
: 
EventTarget
cookieEnabled
: 
true
createAuctionNonce
: 
ƒ createAuctionNonce()
createHandwritingRecognizer
: 
ƒ createHandwritingRecognizer()
credentials
: 
CredentialsContainer
deprecatedReplaceInURN
: 
ƒ deprecatedReplaceInURN()
deprecatedRunAdAuctionEnforcesKAnonymity
: 
(...)
deprecatedURNToURL
: 
ƒ deprecatedURNToURL()
deviceMemory
: 
8
devicePosture
: 
DevicePosture
doNotTrack
: 
null
geolocation
: 
Geolocation
getBattery
: 
ƒ getBattery()
getGamepads
: 
ƒ getGamepads()
getInstalledRelatedApps
: 
ƒ getInstalledRelatedApps()
getInterestGroupAdAuctionData
: 
ƒ getInterestGroupAdAuctionData()
getUserMedia
: 
ƒ getUserMedia()
gpu
: 
(...)
hardwareConcurrency
: 
(...)
hid
: 
(...)
identity
: 
(...)
ink
: 
(...)
install
: 
ƒ install()
javaEnabled
: 
ƒ javaEnabled()
joinAdInterestGroup
: 
ƒ joinAdInterestGroup()
keyboard
: 
(...)
language
: 
(...)
languages
: 
(...)
leaveAdInterestGroup
: 
ƒ leaveAdInterestGroup()
locks
: 
(...)
login
: 
(...)
managed
: 
(...)
maxTouchPoints
: 
(...)
mediaCapabilities
: 
(...)
mediaDevices
: 
(...)
mediaSession
: 
(...)
mimeTypes
: 
(...)
onLine
: 
(...)
pdfViewerEnabled
: 
(...)
permissions
: 
(...)
platform
: 
(...)
plugins
: 
(...)
preferences
: 
(...)
presentation
: 
(...)
product
: 
(...)
productSub
: 
(...)
protectedAudience
: 
(...)
queryHandwritingRecognizer
: 
ƒ queryHandwritingRecognizer()
registerProtocolHandler
: 
ƒ registerProtocolHandler()
requestMIDIAccess
: 
ƒ requestMIDIAccess()
requestMediaKeySystemAccess
: 
ƒ requestMediaKeySystemAccess()
runAdAuction
: 
ƒ runAdAuction()
scheduling
: 
(...)
sendBeacon
: 
ƒ sendBeacon()
serial
: 
(...)
serviceWorker
: 
(...)
setAppBadge
: 
ƒ setAppBadge()
share
: 
ƒ share()
storage
: 
(...)
storageBuckets
: 
(...)
unregisterProtocolHandler
: 
ƒ unregisterProtocolHandler()
updateAdInterestGroups
: 
ƒ updateAdInterestGroups()
usb
: 
(...)
userActivation
: 
(...)
userAgent
: 
(...)
userAgentData
: 
(...)
vendor
: 
(...)
vendorSub
: 
(...)
vibrate
: 
ƒ vibrate()
virtualKeyboard
: 
(...)
wakeLock
: 
(...)
webdriver
: 
(...)
webkitGetUserMedia
: 
ƒ webkitGetUserMedia()
webkitPersistentStorage
: 
(...)
webkitTemporaryStorage
: 
(...)
windowControlsOverlay
: 
(...)
xr
: 
(...)
constructor
: 
ƒ Navigator()
Symbol(Symbol.toStringTag)
: 
"Navigator"
get appCodeName
: 
ƒ appCodeName()
get appName
: 
ƒ appName()
get appVersion
: 
ƒ appVersion()
get bluetooth
: 
ƒ bluetooth()
get clipboard
: 
ƒ clipboard()
get connection
: 
ƒ connection()
get cookieEnabled
: 
ƒ cookieEnabled()
get credentials
: 
ƒ credentials()
get deprecatedRunAdAuctionEnforcesKAnonymity
: 
ƒ deprecatedRunAdAuctionEnforcesKAnonymity()
get deviceMemory
: 
ƒ deviceMemory()
get devicePosture
: 
ƒ devicePosture()
get doNotTrack
: 
ƒ doNotTrack()
get geolocation
: 
ƒ geolocation()
get gpu
: 
ƒ gpu()
get hardwareConcurrency
: 
ƒ hardwareConcurrency()
get hid
: 
ƒ hid()
get identity
: 
ƒ identity()
get ink
: 
ƒ ink()
get keyboard
: 
ƒ keyboard()
get language
: 
ƒ language()
get languages
: 
ƒ languages()
get locks
: 
ƒ locks()
get login
: 
ƒ login()
get managed
: 
ƒ managed()
get maxTouchPoints
: 
ƒ maxTouchPoints()
get mediaCapabilities
: 
ƒ mediaCapabilities()
get mediaDevices
: 
ƒ mediaDevices()
get mediaSession
: 
ƒ mediaSession()
get mimeTypes
: 
ƒ mimeTypes()
get onLine
: 
ƒ onLine()
get pdfViewerEnabled
: 
ƒ pdfViewerEnabled()
get permissions
: 
ƒ permissions()
get platform
: 
ƒ platform()
get plugins
: 
ƒ plugins()
get preferences
: 
ƒ preferences()
get presentation
: 
ƒ presentation()
get product
: 
ƒ product()
get productSub
: 
ƒ productSub()
get protectedAudience
: 
ƒ protectedAudience()
get scheduling
: 
ƒ scheduling()
get serial
: 
ƒ serial()
get serviceWorker
: 
ƒ serviceWorker()
get storage
: 
ƒ storage()
get storageBuckets
: 
ƒ storageBuckets()
get usb
: 
ƒ usb()
get userActivation
: 
ƒ userActivation()
get userAgent
: 
ƒ userAgent()
get userAgentData
: 
ƒ userAgentData()
get vendor
: 
ƒ vendor()
get vendorSub
: 
ƒ vendorSub()
get virtualKeyboard
: 
ƒ virtualKeyboard()
get wakeLock
: 
ƒ wakeLock()
get webdriver
: 
ƒ webdriver()
get webkitPersistentStorage
: 
ƒ webkitPersistentStorage()
get webkitTemporaryStorage
: 
ƒ webkitTemporaryStorage()
get windowControlsOverlay
: 
ƒ windowControlsOverlay()
get xr
: 
ƒ xr()
[[Prototype]]
: 
Object
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onappinstalled
: 
null
onauxclick
: 
null
onbeforeinput
: 
null
onbeforeinstallprompt
: 
null
onbeforematch
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncuechange
: 
null
ondblclick
: 
null
ondevicemotion
: 
null
ondeviceorientation
: 
null
ondeviceorientationabsolute
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpagereveal
: 
null
onpageshow
: 
null
onpageswap
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onpopstate
: 
null
onprogress
: 
null
onratechange
: 
null
onrejectionhandled
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onstorage
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontimezonechange
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onunhandledrejection
: 
null
onunload
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
open
: 
ƒ open()
opener
: 
null
origin
: 
"chrome://flags"
originAgentCluster
: 
false
outerHeight
: 
1752
outerWidth
: 
3200
pageXOffset
: 
0
pageYOffset
: 
0
parent
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
performance
: 
Performance {timeOrigin: 1758565909398.9, onresourcetimingbufferfull: null, timing: PerformanceTiming, navigation: PerformanceNavigation, memory: MemoryInfo, …}
personalbar
: 
BarProp {visible: true}
popinContextType
: 
ƒ popinContextType()
popinContextTypesSupported
: 
ƒ popinContextTypesSupported()
postMessage
: 
ƒ postMessage()
print
: 
ƒ print()
privateAttribution
: 
PrivateAttribution {}
prompt
: 
ƒ prompt()
queryLocalFonts
: 
ƒ queryLocalFonts()
(...)
Infinity
: 
Infinity
AbortController
: 
ƒ AbortController()
AbortSignal
: 
ƒ AbortSignal()
AbsoluteOrientationSensor
: 
ƒ AbsoluteOrientationSensor()
AbstractRange
: 
ƒ AbstractRange()
Accelerometer
: 
ƒ Accelerometer()
AggregateError
: 
ƒ AggregateError()
AmbientLightSensor
: 
ƒ AmbientLightSensor()
AnalyserNode
: 
ƒ AnalyserNode()
Animation
: 
ƒ Animation()
AnimationEffect
: 
ƒ AnimationEffect()
AnimationEvent
: 
ƒ AnimationEvent()
AnimationPlaybackEvent
: 
ƒ AnimationPlaybackEvent()
AnimationTimeline
: 
ƒ AnimationTimeline()
AnimationTrigger
: 
ƒ AnimationTrigger()
Array
: 
ƒ Array()
ArrayBuffer
: 
ƒ ArrayBuffer()
AsyncDisposableStack
: 
ƒ AsyncDisposableStack()
Atomics
: 
Atomics {load: ƒ, store: ƒ, add: ƒ, sub: ƒ, and: ƒ, …}
Attr
: 
ƒ Attr()
AttributePart
: 
ƒ AttributePart()
Audio
: 
ƒ Audio()
AudioBuffer
: 
ƒ AudioBuffer()
AudioBufferSourceNode
: 
ƒ AudioBufferSourceNode()
AudioContext
: 
ƒ AudioContext()
AudioData
: 
ƒ AudioData()
AudioDecoder
: 
ƒ AudioDecoder()
AudioDestinationNode
: 
ƒ AudioDestinationNode()
AudioEncoder
: 
ƒ AudioEncoder()
AudioListener
: 
ƒ AudioListener()
AudioNode
: 
ƒ AudioNode()
AudioParam
: 
ƒ AudioParam()
AudioParamMap
: 
ƒ AudioParamMap()
AudioPlayoutStats
: 
ƒ AudioPlayoutStats()
AudioProcessingEvent
: 
ƒ AudioProcessingEvent()
AudioScheduledSourceNode
: 
ƒ AudioScheduledSourceNode()
AudioSinkInfo
: 
ƒ AudioSinkInfo()
AudioTrack
: 
ƒ AudioTrack()
AudioTrackList
: 
ƒ AudioTrackList()
AudioWorklet
: 
ƒ AudioWorklet()
AudioWorkletNode
: 
ƒ AudioWorkletNode()
AuthenticatorAssertionResponse
: 
ƒ AuthenticatorAssertionResponse()
AuthenticatorAttestationResponse
: 
ƒ AuthenticatorAttestationResponse()
AuthenticatorResponse
: 
ƒ AuthenticatorResponse()
BackForwardCacheRestoration
: 
ƒ BackForwardCacheRestoration()
BackgroundFetchManager
: 
ƒ BackgroundFetchManager()
BackgroundFetchRecord
: 
ƒ BackgroundFetchRecord()
BackgroundFetchRegistration
: 
ƒ BackgroundFetchRegistration()
BarProp
: 
ƒ BarProp()
BaseAudioContext
: 
ƒ BaseAudioContext()
BatteryManager
: 
ƒ BatteryManager()
BeforeCreatePolicyEvent
: 
ƒ BeforeCreatePolicyEvent()
BeforeInstallPromptEvent
: 
ƒ BeforeInstallPromptEvent()
BeforeUnloadEvent
: 
ƒ BeforeUnloadEvent()
BigInt
: 
ƒ BigInt()
BigInt64Array
: 
ƒ BigInt64Array()
BigUint64Array
: 
ƒ BigUint64Array()
BiquadFilterNode
: 
ƒ BiquadFilterNode()
Blob
: 
ƒ Blob()
BlobEvent
: 
ƒ BlobEvent()
Bluetooth
: 
ƒ Bluetooth()
BluetoothAdvertisingEvent
: 
ƒ BluetoothAdvertisingEvent()
BluetoothCharacteristicProperties
: 
ƒ BluetoothCharacteristicProperties()
BluetoothDevice
: 
ƒ BluetoothDevice()
BluetoothLEScan
: 
ƒ BluetoothLEScan()
BluetoothManufacturerDataMap
: 
ƒ BluetoothManufacturerDataMap()
BluetoothRemoteGATTCharacteristic
: 
ƒ BluetoothRemoteGATTCharacteristic()
BluetoothRemoteGATTDescriptor
: 
ƒ BluetoothRemoteGATTDescriptor()
BluetoothRemoteGATTServer
: 
ƒ BluetoothRemoteGATTServer()
BluetoothRemoteGATTService
: 
ƒ BluetoothRemoteGATTService()
BluetoothServiceDataMap
: 
ƒ BluetoothServiceDataMap()
BluetoothUUID
: 
ƒ BluetoothUUID()
Boolean
: 
ƒ Boolean()
BroadcastChannel
: 
ƒ BroadcastChannel()
BrowserCaptureMediaStreamTrack
: 
ƒ BrowserCaptureMediaStreamTrack()
ByteLengthQueuingStrategy
: 
ƒ ByteLengthQueuingStrategy()
CDATASection
: 
ƒ CDATASection()
CSPViolationReportBody
: 
ƒ CSPViolationReportBody()
CSS
: 
CSS {highlights: HighlightRegistry, Hz: ƒ, Q: ƒ, cap: ƒ, ch: ƒ, …}
CSSAnimation
: 
ƒ CSSAnimation()
CSSColorValue
: 
ƒ CSSColorValue()
CSSConditionRule
: 
ƒ CSSConditionRule()
CSSContainerRule
: 
ƒ CSSContainerRule()
CSSCounterStyleRule
: 
ƒ CSSCounterStyleRule()
CSSFontFaceRule
: 
ƒ CSSFontFaceRule()
CSSFontFeatureValuesRule
: 
ƒ CSSFontFeatureValuesRule()
CSSFontPaletteValuesRule
: 
ƒ CSSFontPaletteValuesRule()
CSSFunctionDeclarations
: 
ƒ CSSFunctionDeclarations()
CSSFunctionDescriptors
: 
ƒ CSSFunctionDescriptors()
CSSFunctionRule
: 
ƒ CSSFunctionRule()
CSSGroupingRule
: 
ƒ CSSGroupingRule()
CSSHSL
: 
ƒ CSSHSL()
CSSHWB
: 
ƒ CSSHWB()
CSSImageValue
: 
ƒ CSSImageValue()
CSSImportRule
: 
ƒ CSSImportRule()
CSSKeyframeRule
: 
ƒ CSSKeyframeRule()
CSSKeyframesRule
: 
ƒ CSSKeyframesRule()
CSSKeywordValue
: 
ƒ CSSKeywordValue()
CSSLayerBlockRule
: 
ƒ CSSLayerBlockRule()
CSSLayerStatementRule
: 
ƒ CSSLayerStatementRule()
CSSMarginRule
: 
ƒ CSSMarginRule()
CSSMathClamp
: 
ƒ CSSMathClamp()
CSSMathInvert
: 
ƒ CSSMathInvert()
CSSMathMax
: 
ƒ CSSMathMax()
CSSMathMin
: 
ƒ CSSMathMin()
CSSMathNegate
: 
ƒ CSSMathNegate()
CSSMathProduct
: 
ƒ CSSMathProduct()
CSSMathSum
: 
ƒ CSSMathSum()
CSSMathValue
: 
ƒ CSSMathValue()
CSSMatrixComponent
: 
ƒ CSSMatrixComponent()
CSSMediaRule
: 
ƒ CSSMediaRule()
CSSNamespaceRule
: 
ƒ CSSNamespaceRule()
CSSNestedDeclarations
: 
ƒ CSSNestedDeclarations()
CSSNumericArray
: 
ƒ CSSNumericArray()
CSSNumericValue
: 
ƒ CSSNumericValue()
CSSPageRule
: 
ƒ CSSPageRule()
CSSPerspective
: 
ƒ CSSPerspective()
CSSPositionTryDescriptors
: 
ƒ CSSPositionTryDescriptors()
CSSPositionTryRule
: 
ƒ CSSPositionTryRule()
CSSPositionValue
: 
ƒ CSSPositionValue()
CSSPropertyRule
: 
ƒ CSSPropertyRule()
CSSRGB
: 
ƒ CSSRGB()
CSSRotate
: 
ƒ CSSRotate()
CSSRule
: 
ƒ CSSRule()
CSSRuleList
: 
ƒ CSSRuleList()
CSSScale
: 
ƒ CSSScale()
CSSScopeRule
: 
ƒ CSSScopeRule()
CSSSkew
: 
ƒ CSSSkew()
CSSSkewX
: 
ƒ CSSSkewX()
CSSSkewY
: 
ƒ CSSSkewY()
CSSStartingStyleRule
: 
ƒ CSSStartingStyleRule()
CSSStyleDeclaration
: 
ƒ CSSStyleDeclaration()
CSSStyleRule
: 
ƒ CSSStyleRule()
CSSStyleSheet
: 
ƒ CSSStyleSheet()
CSSStyleValue
: 
ƒ CSSStyleValue()
CSSSupportsRule
: 
ƒ CSSSupportsRule()
CSSTransformComponent
: 
ƒ CSSTransformComponent()
CSSTransformValue
: 
ƒ CSSTransformValue()
CSSTransition
: 
ƒ CSSTransition()
CSSTranslate
: 
ƒ CSSTranslate()
CSSUnitValue
: 
ƒ CSSUnitValue()
CSSUnparsedValue
: 
ƒ CSSUnparsedValue()
CSSVariableReferenceValue
: 
ƒ CSSVariableReferenceValue()
CSSViewTransitionRule
: 
ƒ CSSViewTransitionRule()
Cache
: 
ƒ Cache()
CacheStorage
: 
ƒ CacheStorage()
CanvasCaptureMediaStreamTrack
: 
ƒ CanvasCaptureMediaStreamTrack()
CanvasFilter
: 
ƒ CanvasFilter()
CanvasGradient
: 
ƒ CanvasGradient()
CanvasPattern
: 
ƒ CanvasPattern()
CanvasRenderingContext2D
: 
ƒ CanvasRenderingContext2D()
CaptureController
: 
ƒ CaptureController()
CaretPosition
: 
ƒ CaretPosition()
ChannelMergerNode
: 
ƒ ChannelMergerNode()
ChannelSplitterNode
: 
ƒ ChannelSplitterNode()
ChapterInformation
: 
ƒ ChapterInformation()
CharacterBoundsUpdateEvent
: 
ƒ CharacterBoundsUpdateEvent()
CharacterData
: 
ƒ CharacterData()
ChildNodePart
: 
ƒ ChildNodePart()
Clipboard
: 
ƒ Clipboard()
ClipboardEvent
: 
ƒ ClipboardEvent()
ClipboardItem
: 
ƒ ClipboardItem()
CloseEvent
: 
ƒ CloseEvent()
CloseWatcher
: 
ƒ CloseWatcher()
CommandEvent
: 
ƒ CommandEvent()
Comment
: 
ƒ Comment()
CompositionEvent
: 
ƒ CompositionEvent()
CompressionStream
: 
ƒ CompressionStream()
ConstantSourceNode
: 
ƒ ConstantSourceNode()
ContentIndex
: 
ƒ ContentIndex()
ContentVisibilityAutoStateChangeEvent
: 
ƒ ContentVisibilityAutoStateChangeEvent()
ConvolverNode
: 
ƒ ConvolverNode()
CookieChangeEvent
: 
ƒ CookieChangeEvent()
CookieStore
: 
ƒ CookieStore()
CookieStoreManager
: 
ƒ CookieStoreManager()
CountQueuingStrategy
: 
ƒ CountQueuingStrategy()
CreateMonitor
: 
ƒ CreateMonitor()
Credential
: 
ƒ Credential()
CredentialsContainer
: 
ƒ CredentialsContainer()
CropTarget
: 
ƒ CropTarget()
Crypto
: 
ƒ Crypto()
CryptoKey
: 
ƒ CryptoKey()
CustomElementRegistry
: 
ƒ CustomElementRegistry()
CustomEvent
: 
ƒ CustomEvent()
CustomStateSet
: 
ƒ CustomStateSet()
DOMError
: 
ƒ DOMError()
DOMException
: 
ƒ DOMException()
DOMImplementation
: 
ƒ DOMImplementation()
DOMMatrix
: 
ƒ DOMMatrix()
DOMMatrixReadOnly
: 
ƒ DOMMatrixReadOnly()
DOMParser
: 
ƒ DOMParser()
DOMPoint
: 
ƒ DOMPoint()
DOMPointReadOnly
: 
ƒ DOMPointReadOnly()
DOMQuad
: 
ƒ DOMQuad()
DOMRect
: 
ƒ DOMRect()
DOMRectList
: 
ƒ DOMRectList()
DOMRectReadOnly
: 
ƒ DOMRectReadOnly()
DOMStringList
: 
ƒ DOMStringList()
DOMStringMap
: 
ƒ DOMStringMap()
DOMTokenList
: 
ƒ DOMTokenList()
DataTransfer
: 
ƒ DataTransfer()
DataTransferItem
: 
ƒ DataTransferItem()
DataTransferItemList
: 
ƒ DataTransferItemList()
DataView
: 
ƒ DataView()
Date
: 
ƒ Date()
DecompressionStream
: 
ƒ DecompressionStream()
DelayNode
: 
ƒ DelayNode()
DelegatedInkTrailPresenter
: 
ƒ DelegatedInkTrailPresenter()
DeviceMotionEvent
: 
ƒ DeviceMotionEvent()
DeviceMotionEventAcceleration
: 
ƒ DeviceMotionEventAcceleration()
DeviceMotionEventRotationRate
: 
ƒ DeviceMotionEventRotationRate()
DeviceOrientationEvent
: 
ƒ DeviceOrientationEvent()
DevicePosture
: 
ƒ DevicePosture()
DigitalCredential
: 
ƒ DigitalCredential()
Directive
: 
ƒ Directive()
DisposableStack
: 
ƒ DisposableStack()
Document
: 
ƒ Document()
DocumentFragment
: 
ƒ DocumentFragment()
DocumentPartRoot
: 
ƒ DocumentPartRoot()
DocumentPictureInPicture
: 
ƒ DocumentPictureInPicture()
DocumentPictureInPictureEvent
: 
ƒ DocumentPictureInPictureEvent()
DocumentTimeline
: 
ƒ DocumentTimeline()
DocumentType
: 
ƒ DocumentType()
DragEvent
: 
ƒ DragEvent()
DynamicsCompressorNode
: 
ƒ DynamicsCompressorNode()
EditContext
: 
ƒ EditContext()
Element
: 
ƒ Element()
ElementInternals
: 
ƒ ElementInternals()
EncodedAudioChunk
: 
ƒ EncodedAudioChunk()
EncodedVideoChunk
: 
ƒ EncodedVideoChunk()
Error
: 
ƒ Error()
ErrorEvent
: 
ƒ ErrorEvent()
EvalError
: 
ƒ EvalError()
Event
: 
ƒ Event()
EventCounts
: 
ƒ EventCounts()
EventSource
: 
ƒ EventSource()
EventTarget
: 
ƒ EventTarget()
External
: 
ƒ External()
EyeDropper
: 
ƒ EyeDropper()
FaceDetector
: 
ƒ FaceDetector()
FeaturePolicy
: 
ƒ FeaturePolicy()
FederatedCredential
: 
ƒ FederatedCredential()
Fence
: 
ƒ Fence()
FencedFrameConfig
: 
ƒ FencedFrameConfig()
FetchLaterResult
: 
ƒ FetchLaterResult()
File
: 
ƒ File()
FileList
: 
ƒ FileList()
FileReader
: 
ƒ FileReader()
FileSystemDirectoryHandle
: 
ƒ FileSystemDirectoryHandle()
FileSystemFileHandle
: 
ƒ FileSystemFileHandle()
FileSystemHandle
: 
ƒ FileSystemHandle()
FileSystemObserver
: 
ƒ FileSystemObserver()
FileSystemWritableFileStream
: 
ƒ FileSystemWritableFileStream()
FinalizationRegistry
: 
ƒ FinalizationRegistry()
Float16Array
: 
ƒ Float16Array()
Float32Array
: 
ƒ Float32Array()
Float64Array
: 
ƒ Float64Array()
FocusEvent
: 
ƒ FocusEvent()
FontData
: 
ƒ FontData()
FontFace
: 
ƒ FontFace()
FontFaceSetLoadEvent
: 
ƒ FontFaceSetLoadEvent()
FormData
: 
ƒ FormData()
FormDataEvent
: 
ƒ FormDataEvent()
FragmentDirective
: 
ƒ FragmentDirective()
Function
: 
ƒ Function()
GPU
: 
ƒ GPU()
GPUAdapter
: 
ƒ GPUAdapter()
GPUAdapterInfo
: 
ƒ GPUAdapterInfo()
GPUBindGroup
: 
ƒ GPUBindGroup()
GPUBindGroupLayout
: 
ƒ GPUBindGroupLayout()
GPUBuffer
: 
ƒ GPUBuffer()
GPUBufferUsage
: 
GPUBufferUsage {MAP_READ: 1, MAP_WRITE: 2, COPY_SRC: 4, COPY_DST: 8, INDEX: 16, …}
GPUCanvasContext
: 
ƒ GPUCanvasContext()
GPUColorWrite
: 
GPUColorWrite {RED: 1, GREEN: 2, BLUE: 4, ALPHA: 8, ALL: 15, …}
GPUCommandBuffer
: 
ƒ GPUCommandBuffer()
GPUCommandEncoder
: 
ƒ GPUCommandEncoder()
GPUCompilationInfo
: 
ƒ GPUCompilationInfo()
GPUCompilationMessage
: 
ƒ GPUCompilationMessage()
GPUComputePassEncoder
: 
ƒ GPUComputePassEncoder()
GPUComputePipeline
: 
ƒ GPUComputePipeline()
GPUDevice
: 
ƒ GPUDevice()
GPUDeviceLostInfo
: 
ƒ GPUDeviceLostInfo()
GPUError
: 
ƒ GPUError()
GPUExternalTexture
: 
ƒ GPUExternalTexture()
GPUInternalError
: 
ƒ GPUInternalError()
GPUMapMode
: 
GPUMapMode {READ: 1, WRITE: 2, Symbol(Symbol.toStringTag): 'GPUMapMode'}
GPUOutOfMemoryError
: 
ƒ GPUOutOfMemoryError()
GPUPipelineError
: 
ƒ GPUPipelineError()
GPUPipelineLayout
: 
ƒ GPUPipelineLayout()
GPUQuerySet
: 
ƒ GPUQuerySet()
GPUQueue
: 
ƒ GPUQueue()
GPURenderBundle
: 
ƒ GPURenderBundle()
GPURenderBundleEncoder
: 
ƒ GPURenderBundleEncoder()
GPURenderPassEncoder
: 
ƒ GPURenderPassEncoder()
GPURenderPipeline
: 
ƒ GPURenderPipeline()
GPUSampler
: 
ƒ GPUSampler()
GPUShaderModule
: 
ƒ GPUShaderModule()
GPUShaderStage
: 
GPUShaderStage {VERTEX: 1, FRAGMENT: 2, COMPUTE: 4, Symbol(Symbol.toStringTag): 'GPUShaderStage'}
GPUSubgroupMatrixConfig
: 
ƒ GPUSubgroupMatrixConfig()
GPUSupportedFeatures
: 
ƒ GPUSupportedFeatures()
GPUSupportedLimits
: 
ƒ GPUSupportedLimits()
GPUTexture
: 
ƒ GPUTexture()
GPUTextureUsage
: 
GPUTextureUsage {COPY_SRC: 1, COPY_DST: 2, TEXTURE_BINDING: 4, STORAGE_BINDING: 8, RENDER_ATTACHMENT: 16, …}
GPUTextureView
: 
ƒ GPUTextureView()
GPUUncapturedErrorEvent
: 
ƒ GPUUncapturedErrorEvent()
GPUValidationError
: 
ƒ GPUValidationError()
GainNode
: 
ƒ GainNode()
Gamepad
: 
ƒ Gamepad()
GamepadButton
: 
ƒ GamepadButton()
GamepadEvent
: 
ƒ GamepadEvent()
GamepadHapticActuator
: 
ƒ GamepadHapticActuator()
GamepadTouch
: 
ƒ GamepadTouch()
Geolocation
: 
ƒ Geolocation()
GeolocationCoordinates
: 
ƒ GeolocationCoordinates()
GeolocationPosition
: 
ƒ GeolocationPosition()
GeolocationPositionError
: 
ƒ GeolocationPositionError()
GravitySensor
: 
ƒ GravitySensor()
Gyroscope
: 
ƒ Gyroscope()
HID
: 
ƒ HID()
HIDConnectionEvent
: 
ƒ HIDConnectionEvent()
HIDDevice
: 
ƒ HIDDevice()
HIDInputReportEvent
: 
ƒ HIDInputReportEvent()
HTMLAllCollection
: 
ƒ HTMLAllCollection()
HTMLAnchorElement
: 
ƒ HTMLAnchorElement()
HTMLAreaElement
: 
ƒ HTMLAreaElement()
HTMLAudioElement
: 
ƒ HTMLAudioElement()
HTMLBRElement
: 
ƒ HTMLBRElement()
HTMLBaseElement
: 
ƒ HTMLBaseElement()
HTMLBodyElement
: 
ƒ HTMLBodyElement()
HTMLButtonElement
: 
ƒ HTMLButtonElement()
HTMLCanvasElement
: 
ƒ HTMLCanvasElement()
HTMLCollection
: 
ƒ HTMLCollection()
HTMLDListElement
: 
ƒ HTMLDListElement()
HTMLDataElement
: 
ƒ HTMLDataElement()
HTMLDataListElement
: 
ƒ HTMLDataListElement()
HTMLDetailsElement
: 
ƒ HTMLDetailsElement()
HTMLDialogElement
: 
ƒ HTMLDialogElement()
HTMLDirectoryElement
: 
ƒ HTMLDirectoryElement()
HTMLDivElement
: 
ƒ HTMLDivElement()
HTMLDocument
: 
ƒ HTMLDocument()
HTMLElement
: 
ƒ HTMLElement()
HTMLEmbedElement
: 
ƒ HTMLEmbedElement()
HTMLFencedFrameElement
: 
ƒ HTMLFencedFrameElement()
HTMLFieldSetElement
: 
ƒ HTMLFieldSetElement()
HTMLFontElement
: 
ƒ HTMLFontElement()
HTMLFormControlsCollection
: 
ƒ HTMLFormControlsCollection()
HTMLFormElement
: 
ƒ HTMLFormElement()
HTMLFrameElement
: 
ƒ HTMLFrameElement()
HTMLFrameSetElement
: 
ƒ HTMLFrameSetElement()
HTMLHRElement
: 
ƒ HTMLHRElement()
HTMLHeadElement
: 
ƒ HTMLHeadElement()
HTMLHeadingElement
: 
ƒ HTMLHeadingElement()
HTMLHtmlElement
: 
ƒ HTMLHtmlElement()
HTMLIFrameElement
: 
ƒ HTMLIFrameElement()
HTMLImageElement
: 
ƒ HTMLImageElement()
HTMLInputElement
: 
ƒ HTMLInputElement()
HTMLLIElement
: 
ƒ HTMLLIElement()
HTMLLabelElement
: 
ƒ HTMLLabelElement()
HTMLLegendElement
: 
ƒ HTMLLegendElement()
HTMLLinkElement
: 
ƒ HTMLLinkElement()
HTMLMapElement
: 
ƒ HTMLMapElement()
HTMLMarqueeElement
: 
ƒ HTMLMarqueeElement()
HTMLMediaElement
: 
ƒ HTMLMediaElement()
HTMLMenuElement
: 
ƒ HTMLMenuElement()
HTMLMetaElement
: 
ƒ HTMLMetaElement()
HTMLMeterElement
: 
ƒ HTMLMeterElement()
HTMLModElement
: 
ƒ HTMLModElement()
HTMLOListElement
: 
ƒ HTMLOListElement()
HTMLObjectElement
: 
ƒ HTMLObjectElement()
HTMLOptGroupElement
: 
ƒ HTMLOptGroupElement()
HTMLOptionElement
: 
ƒ HTMLOptionElement()
HTMLOptionsCollection
: 
ƒ HTMLOptionsCollection()
HTMLOutputElement
: 
ƒ HTMLOutputElement()
HTMLParagraphElement
: 
ƒ HTMLParagraphElement()
HTMLParamElement
: 
ƒ HTMLParamElement()
HTMLPermissionElement
: 
ƒ HTMLPermissionElement()
HTMLPictureElement
: 
ƒ HTMLPictureElement()
HTMLPreElement
: 
ƒ HTMLPreElement()
HTMLProgressElement
: 
ƒ HTMLProgressElement()
HTMLQuoteElement
: 
ƒ HTMLQuoteElement()
HTMLScriptElement
: 
ƒ HTMLScriptElement()
HTMLSelectElement
: 
ƒ HTMLSelectElement()
HTMLSelectedContentElement
: 
ƒ HTMLSelectedContentElement()
HTMLSlotElement
: 
ƒ HTMLSlotElement()
HTMLSourceElement
: 
ƒ HTMLSourceElement()
HTMLSpanElement
: 
ƒ HTMLSpanElement()
HTMLStyleElement
: 
ƒ HTMLStyleElement()
HTMLTableCaptionElement
: 
ƒ HTMLTableCaptionElement()
HTMLTableCellElement
: 
ƒ HTMLTableCellElement()
HTMLTableColElement
: 
ƒ HTMLTableColElement()
HTMLTableElement
: 
ƒ HTMLTableElement()
HTMLTableRowElement
: 
ƒ HTMLTableRowElement()
HTMLTableSectionElement
: 
ƒ HTMLTableSectionElement()
HTMLTemplateElement
: 
ƒ HTMLTemplateElement()
HTMLTextAreaElement
: 
ƒ HTMLTextAreaElement()
HTMLTimeElement
: 
ƒ HTMLTimeElement()
HTMLTitleElement
: 
ƒ HTMLTitleElement()
HTMLTrackElement
: 
ƒ HTMLTrackElement()
HTMLUListElement
: 
ƒ HTMLUListElement()
HTMLUnknownElement
: 
ƒ HTMLUnknownElement()
HTMLVideoElement
: 
ƒ HTMLVideoElement()
HandwritingStroke
: 
ƒ HandwritingStroke()
HashChangeEvent
: 
ƒ HashChangeEvent()
Headers
: 
ƒ Headers()
Highlight
: 
ƒ Highlight()
HighlightRegistry
: 
ƒ HighlightRegistry()
History
: 
ƒ History()
IDBCursor
: 
ƒ IDBCursor()
IDBCursorWithValue
: 
ƒ IDBCursorWithValue()
IDBDatabase
: 
ƒ IDBDatabase()
IDBFactory
: 
ƒ IDBFactory()
IDBIndex
: 
ƒ IDBIndex()
IDBKeyRange
: 
ƒ IDBKeyRange()
IDBObjectStore
: 
ƒ IDBObjectStore()
IDBOpenDBRequest
: 
ƒ IDBOpenDBRequest()
IDBRecord
: 
ƒ IDBRecord()
IDBRequest
: 
ƒ IDBRequest()
IDBTransaction
: 
ƒ IDBTransaction()
IDBVersionChangeEvent
: 
ƒ IDBVersionChangeEvent()
IIRFilterNode
: 
ƒ IIRFilterNode()
IdentityCredential
: 
ƒ IdentityCredential()
IdentityCredentialError
: 
ƒ IdentityCredentialError()
IdentityProvider
: 
ƒ IdentityProvider()
IdleDeadline
: 
ƒ IdleDeadline()
IdleDetector
: 
ƒ IdleDetector()
Image
: 
ƒ Image()
ImageBitmap
: 
ƒ ImageBitmap()
ImageBitmapRenderingContext
: 
ƒ ImageBitmapRenderingContext()
ImageCapture
: 
ƒ ImageCapture()
ImageData
: 
ƒ ImageData()
ImageDecoder
: 
ƒ ImageDecoder()
ImageTrack
: 
ƒ ImageTrack()
ImageTrackList
: 
ƒ ImageTrackList()
Ink
: 
ƒ Ink()
InputDeviceCapabilities
: 
ƒ InputDeviceCapabilities()
InputDeviceInfo
: 
ƒ InputDeviceInfo()
InputEvent
: 
ƒ InputEvent()
Int8Array
: 
ƒ Int8Array()
Int16Array
: 
ƒ Int16Array()
Int32Array
: 
ƒ Int32Array()
IntegrityViolationReportBody
: 
ƒ IntegrityViolationReportBody()
InteractionContentfulPaint
: 
ƒ InteractionContentfulPaint()
InterestEvent
: 
ƒ InterestEvent()
IntersectionObserver
: 
ƒ IntersectionObserver()
IntersectionObserverEntry
: 
ƒ IntersectionObserverEntry()
Intl
: 
Intl {getCanonicalLocales: ƒ, supportedValuesOf: ƒ, DateTimeFormat: ƒ, NumberFormat: ƒ, Collator: ƒ, …}
Iterator
: 
ƒ Iterator()
JSON
: 
JSON {Symbol(Symbol.toStringTag): 'JSON', parse: ƒ, stringify: ƒ, rawJSON: ƒ, isRawJSON: ƒ}
Keyboard
: 
ƒ Keyboard()
KeyboardEvent
: 
ƒ KeyboardEvent()
KeyboardLayoutMap
: 
ƒ KeyboardLayoutMap()
KeyframeEffect
: 
ƒ KeyframeEffect()
LanguageDetector
: 
ƒ LanguageDetector()
LanguageModel
: 
ƒ LanguageModel()
LanguageModelParams
: 
ƒ LanguageModelParams()
LargestContentfulPaint
: 
ƒ LargestContentfulPaint()
LaunchParams
: 
ƒ LaunchParams()
LaunchQueue
: 
ƒ LaunchQueue()
LayoutShift
: 
ƒ LayoutShift()
LayoutShiftAttribution
: 
ƒ LayoutShiftAttribution()
LinearAccelerationSensor
: 
ƒ LinearAccelerationSensor()
Location
: 
ƒ Location()
Lock
: 
ƒ Lock()
LockManager
: 
ƒ LockManager()
MIDIAccess
: 
ƒ MIDIAccess()
MIDIConnectionEvent
: 
ƒ MIDIConnectionEvent()
MIDIInput
: 
ƒ MIDIInput()
MIDIInputMap
: 
ƒ MIDIInputMap()
MIDIMessageEvent
: 
ƒ MIDIMessageEvent()
MIDIOutput
: 
ƒ MIDIOutput()
MIDIOutputMap
: 
ƒ MIDIOutputMap()
MIDIPort
: 
ƒ MIDIPort()
Magnetometer
: 
ƒ Magnetometer()
Map
: 
ƒ Map()
Math
: 
Math {abs: ƒ, acos: ƒ, acosh: ƒ, asin: ƒ, asinh: ƒ, …}
MathMLElement
: 
ƒ MathMLElement()
MediaCapabilities
: 
ƒ MediaCapabilities()
MediaDeviceInfo
: 
ƒ MediaDeviceInfo()
MediaDevices
: 
ƒ MediaDevices()
MediaElementAudioSourceNode
: 
ƒ MediaElementAudioSourceNode()
MediaEncryptedEvent
: 
ƒ MediaEncryptedEvent()
MediaError
: 
ƒ MediaError()
MediaKeyMessageEvent
: 
ƒ MediaKeyMessageEvent()
MediaKeySession
: 
ƒ MediaKeySession()
MediaKeyStatusMap
: 
ƒ MediaKeyStatusMap()
MediaKeySystemAccess
: 
ƒ MediaKeySystemAccess()
MediaKeys
: 
ƒ MediaKeys()
MediaList
: 
ƒ MediaList()
MediaMetadata
: 
ƒ MediaMetadata()
MediaQueryList
: 
ƒ MediaQueryList()
MediaQueryListEvent
: 
ƒ MediaQueryListEvent()
MediaRecorder
: 
ƒ MediaRecorder()
MediaSession
: 
ƒ MediaSession()
MediaSource
: 
ƒ MediaSource()
MediaSourceHandle
: 
ƒ MediaSourceHandle()
MediaStream
: 
ƒ MediaStream()
MediaStreamAudioDestinationNode
: 
ƒ MediaStreamAudioDestinationNode()
MediaStreamAudioSourceNode
: 
ƒ MediaStreamAudioSourceNode()
MediaStreamEvent
: 
ƒ MediaStreamEvent()
MediaStreamTrack
: 
ƒ MediaStreamTrack()
MediaStreamTrackAudioStats
: 
ƒ MediaStreamTrackAudioStats()
MediaStreamTrackEvent
: 
ƒ MediaStreamTrackEvent()
MediaStreamTrackGenerator
: 
ƒ MediaStreamTrackGenerator()
MediaStreamTrackProcessor
: 
ƒ MediaStreamTrackProcessor()
MediaStreamTrackVideoStats
: 
ƒ MediaStreamTrackVideoStats()
MessageChannel
: 
ƒ MessageChannel()
MessageEvent
: 
ƒ MessageEvent()
MessagePort
: 
ƒ MessagePort()
MimeType
: 
ƒ MimeType()
MimeTypeArray
: 
ƒ MimeTypeArray()
MouseEvent
: 
ƒ MouseEvent()
MutationObserver
: 
ƒ MutationObserver()
MutationRecord
: 
ƒ MutationRecord()
NaN
: 
NaN
NamedNodeMap
: 
ƒ NamedNodeMap()
NavigateEvent
: 
ƒ NavigateEvent()
Navigation
: 
ƒ Navigation()
NavigationActivation
: 
ƒ NavigationActivation()
NavigationCurrentEntryChangeEvent
: 
ƒ NavigationCurrentEntryChangeEvent()
NavigationDestination
: 
ƒ NavigationDestination()
NavigationHistoryEntry
: 
ƒ NavigationHistoryEntry()
NavigationPrecommitController
: 
ƒ NavigationPrecommitController()
NavigationPreloadManager
: 
ƒ NavigationPreloadManager()
NavigationTransition
: 
ƒ NavigationTransition()
Navigator
: 
ƒ Navigator()
NavigatorLogin
: 
ƒ NavigatorLogin()
NavigatorManagedData
: 
ƒ NavigatorManagedData()
NavigatorUAData
: 
ƒ NavigatorUAData()
NetworkInformation
: 
ƒ NetworkInformation()
Node
: 
ƒ Node()
NodeFilter
: 
ƒ NodeFilter()
NodeIterator
: 
ƒ NodeIterator()
NodeList
: 
ƒ NodeList()
NodePart
: 
ƒ NodePart()
NotRestoredReasonDetails
: 
ƒ NotRestoredReasonDetails()
NotRestoredReasons
: 
ƒ NotRestoredReasons()
Notification
: 
ƒ Notification()
Number
: 
ƒ Number()
OTPCredential
: 
ƒ OTPCredential()
Object
: 
ƒ Object()
Observable
: 
ƒ Observable()
OfflineAudioCompletionEvent
: 
ƒ OfflineAudioCompletionEvent()
OfflineAudioContext
: 
ƒ OfflineAudioContext()
OffscreenCanvas
: 
ƒ OffscreenCanvas()
OffscreenCanvasRenderingContext2D
: 
ƒ OffscreenCanvasRenderingContext2D()
Option
: 
ƒ Option()
OrientationSensor
: 
ƒ OrientationSensor()
OscillatorNode
: 
ƒ OscillatorNode()
OverconstrainedError
: 
ƒ OverconstrainedError()
OverscrollEvent
: 
ƒ OverscrollEvent()
PageRevealEvent
: 
ƒ PageRevealEvent()
PageSwapEvent
: 
ƒ PageSwapEvent()
PageTransitionEvent
: 
ƒ PageTransitionEvent()
PannerNode
: 
ƒ PannerNode()
Part
: 
ƒ Part()
PasswordCredential
: 
ƒ PasswordCredential()
Path2D
: 
ƒ Path2D()
PaymentAddress
: 
ƒ PaymentAddress()
PaymentManager
: 
ƒ PaymentManager()
PaymentMethodChangeEvent
: 
ƒ PaymentMethodChangeEvent()
PaymentRequest
: 
ƒ PaymentRequest()
PaymentRequestUpdateEvent
: 
ƒ PaymentRequestUpdateEvent()
PaymentResponse
: 
ƒ PaymentResponse()
Performance
: 
ƒ Performance()
PerformanceContainerTiming
: 
ƒ PerformanceContainerTiming()
PerformanceElementTiming
: 
ƒ PerformanceElementTiming()
PerformanceEntry
: 
ƒ PerformanceEntry()
PerformanceEventTiming
: 
ƒ PerformanceEventTiming()
PerformanceLongAnimationFrameTiming
: 
ƒ PerformanceLongAnimationFrameTiming()
PerformanceLongTaskTiming
: 
ƒ PerformanceLongTaskTiming()
PerformanceMark
: 
ƒ PerformanceMark()
PerformanceMeasure
: 
ƒ PerformanceMeasure()
PerformanceNavigation
: 
ƒ PerformanceNavigation()
PerformanceNavigationTiming
: 
ƒ PerformanceNavigationTiming()
PerformanceObserver
: 
ƒ PerformanceObserver()
PerformanceObserverEntryList
: 
ƒ PerformanceObserverEntryList()
PerformancePaintTiming
: 
ƒ PerformancePaintTiming()
PerformanceResourceTiming
: 
ƒ PerformanceResourceTiming()
PerformanceScriptTiming
: 
ƒ PerformanceScriptTiming()
PerformanceServerTiming
: 
ƒ PerformanceServerTiming()
PerformanceTiming
: 
ƒ PerformanceTiming()
PerformanceTimingConfidence
: 
ƒ PerformanceTimingConfidence()
PeriodicSyncManager
: 
ƒ PeriodicSyncManager()
PeriodicWave
: 
ƒ PeriodicWave()
PermissionStatus
: 
ƒ PermissionStatus()
Permissions
: 
ƒ Permissions()
PictureInPictureEvent
: 
ƒ PictureInPictureEvent()
PictureInPictureWindow
: 
ƒ PictureInPictureWindow()
Plugin
: 
ƒ Plugin()
PluginArray
: 
ƒ PluginArray()
PointerEvent
: 
ƒ PointerEvent()
PopStateEvent
: 
ƒ PopStateEvent()
PreferenceManager
: 
ƒ PreferenceManager()
PreferenceObject
: 
ƒ PreferenceObject()
Presentation
: 
ƒ Presentation()
PresentationAvailability
: 
ƒ PresentationAvailability()
PresentationConnection
: 
ƒ PresentationConnection()
PresentationConnectionAvailableEvent
: 
ƒ PresentationConnectionAvailableEvent()
PresentationConnectionCloseEvent
: 
ƒ PresentationConnectionCloseEvent()
PresentationConnectionList
: 
ƒ PresentationConnectionList()
PresentationReceiver
: 
ƒ PresentationReceiver()
PresentationRequest
: 
ƒ PresentationRequest()
PressureObserver
: 
ƒ PressureObserver()
PressureRecord
: 
ƒ PressureRecord()
PrivateAttribution
: 
ƒ PrivateAttribution()
ProcessingInstruction
: 
ƒ ProcessingInstruction()
Profiler
: 
ƒ Profiler()
ProgressEvent
: 
ƒ ProgressEvent()
Promise
: 
ƒ Promise()
PromiseRejectionEvent
: 
ƒ PromiseRejectionEvent()
Proofreader
: 
ƒ Proofreader()
ProtectedAudience
: 
ƒ ProtectedAudience()
Proxy
: 
ƒ Proxy()
PublicKeyCredential
: 
ƒ PublicKeyCredential()
PushManager
: 
ƒ PushManager()
PushSubscription
: 
ƒ PushSubscription()
PushSubscriptionOptions
: 
ƒ PushSubscriptionOptions()
QuotaExceededError
: 
ƒ QuotaExceededError()
RTCCertificate
: 
ƒ RTCCertificate()
RTCDTMFSender
: 
ƒ RTCDTMFSender()
RTCDTMFToneChangeEvent
: 
ƒ RTCDTMFToneChangeEvent()
RTCDataChannel
: 
ƒ RTCDataChannel()
RTCDataChannelEvent
: 
ƒ RTCDataChannelEvent()
RTCDtlsTransport
: 
ƒ RTCDtlsTransport()
RTCEncodedAudioFrame
: 
ƒ RTCEncodedAudioFrame()
RTCEncodedVideoFrame
: 
ƒ RTCEncodedVideoFrame()
RTCError
: 
ƒ RTCError()
RTCErrorEvent
: 
ƒ RTCErrorEvent()
RTCIceCandidate
: 
ƒ RTCIceCandidate()
RTCIceTransport
: 
ƒ RTCIceTransport()
RTCPeerConnection
: 
ƒ RTCPeerConnection()
RTCPeerConnectionIceErrorEvent
: 
ƒ RTCPeerConnectionIceErrorEvent()
RTCPeerConnectionIceEvent
: 
ƒ RTCPeerConnectionIceEvent()
RTCRtpReceiver
: 
ƒ RTCRtpReceiver()
RTCRtpScriptTransform
: 
ƒ RTCRtpScriptTransform()
RTCRtpSender
: 
ƒ RTCRtpSender()
RTCRtpTransceiver
: 
ƒ RTCRtpTransceiver()
RTCSctpTransport
: 
ƒ RTCSctpTransport()
RTCSessionDescription
: 
ƒ RTCSessionDescription()
RTCStatsReport
: 
ƒ RTCStatsReport()
RTCTrackEvent
: 
ƒ RTCTrackEvent()
RadioNodeList
: 
ƒ RadioNodeList()
Range
: 
ƒ Range()
RangeError
: 
ƒ RangeError()
ReadableByteStreamController
: 
ƒ ReadableByteStreamController()
ReadableStream
: 
ƒ ReadableStream()
ReadableStreamBYOBReader
: 
ƒ ReadableStreamBYOBReader()
ReadableStreamBYOBRequest
: 
ƒ ReadableStreamBYOBRequest()
ReadableStreamDefaultController
: 
ƒ ReadableStreamDefaultController()
ReadableStreamDefaultReader
: 
ƒ ReadableStreamDefaultReader()
ReferenceError
: 
ƒ ReferenceError()
Reflect
: 
Reflect {defineProperty: ƒ, deleteProperty: ƒ, apply: ƒ, construct: ƒ, get: ƒ, …}
RegExp
: 
ƒ RegExp()
RelativeOrientationSensor
: 
ƒ RelativeOrientationSensor()
RemotePlayback
: 
ƒ RemotePlayback()
ReportBody
: 
ƒ ReportBody()
ReportingObserver
: 
ƒ ReportingObserver()
Request
: 
ƒ Request()
ResizeObserver
: 
ƒ ResizeObserver()
ResizeObserverEntry
: 
ƒ ResizeObserverEntry()
ResizeObserverSize
: 
ƒ ResizeObserverSize()
Response
: 
ƒ Response()
RestrictionTarget
: 
ƒ RestrictionTarget()
Rewriter
: 
ƒ Rewriter()
SVGAElement
: 
ƒ SVGAElement()
SVGAngle
: 
ƒ SVGAngle()
SVGAnimateElement
: 
ƒ SVGAnimateElement()
SVGAnimateMotionElement
: 
ƒ SVGAnimateMotionElement()
SVGAnimateTransformElement
: 
ƒ SVGAnimateTransformElement()
SVGAnimatedAngle
: 
ƒ SVGAnimatedAngle()
SVGAnimatedBoolean
: 
ƒ SVGAnimatedBoolean()
SVGAnimatedEnumeration
: 
ƒ SVGAnimatedEnumeration()
SVGAnimatedInteger
: 
ƒ SVGAnimatedInteger()
SVGAnimatedLength
: 
ƒ SVGAnimatedLength()
SVGAnimatedLengthList
: 
ƒ SVGAnimatedLengthList()
SVGAnimatedNumber
: 
ƒ SVGAnimatedNumber()
SVGAnimatedNumberList
: 
ƒ SVGAnimatedNumberList()
SVGAnimatedPreserveAspectRatio
: 
ƒ SVGAnimatedPreserveAspectRatio()
SVGAnimatedRect
: 
ƒ SVGAnimatedRect()
SVGAnimatedString
: 
ƒ SVGAnimatedString()
SVGAnimatedTransformList
: 
ƒ SVGAnimatedTransformList()
SVGAnimationElement
: 
ƒ SVGAnimationElement()
SVGCircleElement
: 
ƒ SVGCircleElement()
SVGClipPathElement
: 
ƒ SVGClipPathElement()
SVGComponentTransferFunctionElement
: 
ƒ SVGComponentTransferFunctionElement()
SVGDefsElement
: 
ƒ SVGDefsElement()
SVGDescElement
: 
ƒ SVGDescElement()
SVGElement
: 
ƒ SVGElement()
SVGEllipseElement
: 
ƒ SVGEllipseElement()
SVGFEBlendElement
: 
ƒ SVGFEBlendElement()
SVGFEColorMatrixElement
: 
ƒ SVGFEColorMatrixElement()
SVGFEComponentTransferElement
: 
ƒ SVGFEComponentTransferElement()
SVGFECompositeElement
: 
ƒ SVGFECompositeElement()
SVGFEConvolveMatrixElement
: 
ƒ SVGFEConvolveMatrixElement()
SVGFEDiffuseLightingElement
: 
ƒ SVGFEDiffuseLightingElement()
SVGFEDisplacementMapElement
: 
ƒ SVGFEDisplacementMapElement()
SVGFEDistantLightElement
: 
ƒ SVGFEDistantLightElement()
SVGFEDropShadowElement
: 
ƒ SVGFEDropShadowElement()
SVGFEFloodElement
: 
ƒ SVGFEFloodElement()
SVGFEFuncAElement
: 
ƒ SVGFEFuncAElement()
SVGFEFuncBElement
: 
ƒ SVGFEFuncBElement()
SVGFEFuncGElement
: 
ƒ SVGFEFuncGElement()
SVGFEFuncRElement
: 
ƒ SVGFEFuncRElement()
SVGFEGaussianBlurElement
: 
ƒ SVGFEGaussianBlurElement()
SVGFEImageElement
: 
ƒ SVGFEImageElement()
SVGFEMergeElement
: 
ƒ SVGFEMergeElement()
SVGFEMergeNodeElement
: 
ƒ SVGFEMergeNodeElement()
SVGFEMorphologyElement
: 
ƒ SVGFEMorphologyElement()
SVGFEOffsetElement
: 
ƒ SVGFEOffsetElement()
SVGFEPointLightElement
: 
ƒ SVGFEPointLightElement()
SVGFESpecularLightingElement
: 
ƒ SVGFESpecularLightingElement()
SVGFESpotLightElement
: 
ƒ SVGFESpotLightElement()
SVGFETileElement
: 
ƒ SVGFETileElement()
SVGFETurbulenceElement
: 
ƒ SVGFETurbulenceElement()
SVGFilterElement
: 
ƒ SVGFilterElement()
SVGForeignObjectElement
: 
ƒ SVGForeignObjectElement()
SVGGElement
: 
ƒ SVGGElement()
SVGGeometryElement
: 
ƒ SVGGeometryElement()
SVGGradientElement
: 
ƒ SVGGradientElement()
SVGGraphicsElement
: 
ƒ SVGGraphicsElement()
SVGImageElement
: 
ƒ SVGImageElement()
SVGLength
: 
ƒ SVGLength()
SVGLengthList
: 
ƒ SVGLengthList()
SVGLineElement
: 
ƒ SVGLineElement()
SVGLinearGradientElement
: 
ƒ SVGLinearGradientElement()
SVGMPathElement
: 
ƒ SVGMPathElement()
SVGMarkerElement
: 
ƒ SVGMarkerElement()
SVGMaskElement
: 
ƒ SVGMaskElement()
SVGMatrix
: 
ƒ SVGMatrix()
SVGMetadataElement
: 
ƒ SVGMetadataElement()
SVGNumber
: 
ƒ SVGNumber()
SVGNumberList
: 
ƒ SVGNumberList()
SVGPathElement
: 
ƒ SVGPathElement()
SVGPatternElement
: 
ƒ SVGPatternElement()
SVGPoint
: 
ƒ SVGPoint()
SVGPointList
: 
ƒ SVGPointList()
SVGPolygonElement
: 
ƒ SVGPolygonElement()
SVGPolylineElement
: 
ƒ SVGPolylineElement()
SVGPreserveAspectRatio
: 
ƒ SVGPreserveAspectRatio()
SVGRadialGradientElement
: 
ƒ SVGRadialGradientElement()
SVGRect
: 
ƒ SVGRect()
SVGRectElement
: 
ƒ SVGRectElement()
SVGSVGElement
: 
ƒ SVGSVGElement()
SVGScriptElement
: 
ƒ SVGScriptElement()
SVGSetElement
: 
ƒ SVGSetElement()
SVGStopElement
: 
ƒ SVGStopElement()
SVGStringList
: 
ƒ SVGStringList()
SVGStyleElement
: 
ƒ SVGStyleElement()
SVGSwitchElement
: 
ƒ SVGSwitchElement()
SVGSymbolElement
: 
ƒ SVGSymbolElement()
SVGTSpanElement
: 
ƒ SVGTSpanElement()
SVGTextContentElement
: 
ƒ SVGTextContentElement()
SVGTextElement
: 
ƒ SVGTextElement()
SVGTextPathElement
: 
ƒ SVGTextPathElement()
SVGTextPositioningElement
: 
ƒ SVGTextPositioningElement()
SVGTitleElement
: 
ƒ SVGTitleElement()
SVGTransform
: 
ƒ SVGTransform()
SVGTransformList
: 
ƒ SVGTransformList()
SVGUnitTypes
: 
ƒ SVGUnitTypes()
SVGUseElement
: 
ƒ SVGUseElement()
SVGViewElement
: 
ƒ SVGViewElement()
Scheduler
: 
ƒ Scheduler()
Scheduling
: 
ƒ Scheduling()
Screen
: 
ƒ Screen()
ScreenDetailed
: 
ƒ ScreenDetailed()
ScreenDetails
: 
ƒ ScreenDetails()
ScreenOrientation
: 
ƒ ScreenOrientation()
ScriptProcessorNode
: 
ƒ ScriptProcessorNode()
ScrollTimeline
: 
ƒ ScrollTimeline()
SecurityPolicyViolationEvent
: 
ƒ SecurityPolicyViolationEvent()
Selection
: 
ƒ Selection()
SelectorDirective
: 
ƒ SelectorDirective()
Sensor
: 
ƒ Sensor()
SensorErrorEvent
: 
ƒ SensorErrorEvent()
Serial
: 
ƒ Serial()
SerialPort
: 
ƒ SerialPort()
ServiceWorker
: 
ƒ ServiceWorker()
ServiceWorkerContainer
: 
ƒ ServiceWorkerContainer()
ServiceWorkerRegistration
: 
ƒ ServiceWorkerRegistration()
Set
: 
ƒ Set()
ShadowRoot
: 
ƒ ShadowRoot()
SharedStorage
: 
ƒ SharedStorage()
SharedStorageAppendMethod
: 
ƒ SharedStorageAppendMethod()
SharedStorageClearMethod
: 
ƒ SharedStorageClearMethod()
SharedStorageDeleteMethod
: 
ƒ SharedStorageDeleteMethod()
SharedStorageModifierMethod
: 
ƒ SharedStorageModifierMethod()
SharedStorageSetMethod
: 
ƒ SharedStorageSetMethod()
SharedStorageWorklet
: 
ƒ SharedStorageWorklet()
SharedWorker
: 
ƒ SharedWorker()
SnapEvent
: 
ƒ SnapEvent()
SoftNavigationEntry
: 
ƒ SoftNavigationEntry()
SourceBuffer
: 
ƒ SourceBuffer()
SourceBufferList
: 
ƒ SourceBufferList()
SpeechGrammar
: 
ƒ SpeechGrammar()
SpeechGrammarList
: 
ƒ SpeechGrammarList()
SpeechRecognition
: 
ƒ SpeechRecognition()
SpeechRecognitionContext
: 
ƒ SpeechRecognitionContext()
SpeechRecognitionErrorEvent
: 
ƒ SpeechRecognitionErrorEvent()
SpeechRecognitionEvent
: 
ƒ SpeechRecognitionEvent()
SpeechRecognitionPhrase
: 
ƒ SpeechRecognitionPhrase()
SpeechRecognitionPhraseList
: 
ƒ SpeechRecognitionPhraseList()
SpeechSynthesis
: 
ƒ SpeechSynthesis()
SpeechSynthesisErrorEvent
: 
ƒ SpeechSynthesisErrorEvent()
SpeechSynthesisEvent
: 
ƒ SpeechSynthesisEvent()
SpeechSynthesisUtterance
: 
ƒ SpeechSynthesisUtterance()
SpeechSynthesisVoice
: 
ƒ SpeechSynthesisVoice()
StaticRange
: 
ƒ StaticRange()
StereoPannerNode
: 
ƒ StereoPannerNode()
Storage
: 
ƒ Storage()
StorageBucket
: 
ƒ StorageBucket()
StorageBucketManager
: 
ƒ StorageBucketManager()
StorageEvent
: 
ƒ StorageEvent()
StorageManager
: 
ƒ StorageManager()
String
: 
ƒ String()
StylePropertyMap
: 
ƒ StylePropertyMap()
StylePropertyMapReadOnly
: 
ƒ StylePropertyMapReadOnly()
StyleSheet
: 
ƒ StyleSheet()
StyleSheetList
: 
ƒ StyleSheetList()
SubmitEvent
: 
ƒ SubmitEvent()
Subscriber
: 
ƒ Subscriber()
SubtleCrypto
: 
ƒ SubtleCrypto()
Summarizer
: 
ƒ Summarizer()
SuppressedError
: 
ƒ SuppressedError()
Symbol
: 
ƒ Symbol()
SyncManager
: 
ƒ SyncManager()
SyntaxError
: 
ƒ SyntaxError()
TaskAttributionTiming
: 
ƒ TaskAttributionTiming()
TaskController
: 
ƒ TaskController()
TaskPriorityChangeEvent
: 
ƒ TaskPriorityChangeEvent()
TaskSignal
: 
ƒ TaskSignal()
Text
: 
ƒ Text()
TextCluster
: 
ƒ TextCluster()
TextDecoder
: 
ƒ TextDecoder()
TextDecoderStream
: 
ƒ TextDecoderStream()
TextDetector
: 
ƒ TextDetector()
TextDirective
: 
ƒ TextDirective()
TextEncoder
: 
ƒ TextEncoder()
TextEncoderStream
: 
ƒ TextEncoderStream()
TextEvent
: 
ƒ TextEvent()
TextFormat
: 
ƒ TextFormat()
TextFormatUpdateEvent
: 
ƒ TextFormatUpdateEvent()
TextMetrics
: 
ƒ TextMetrics()
TextTrack
: 
ƒ TextTrack()
TextTrackCue
: 
ƒ TextTrackCue()
TextTrackCueList
: 
ƒ TextTrackCueList()
TextTrackList
: 
ƒ TextTrackList()
TextUpdateEvent
: 
ƒ TextUpdateEvent()
TimeRanges
: 
ƒ TimeRanges()
TimestampTrigger
: 
ƒ TimestampTrigger()
ToggleEvent
: 
ƒ ToggleEvent()
Touch
: 
ƒ Touch()
TouchEvent
: 
ƒ TouchEvent()
TouchList
: 
ƒ TouchList()
TrackDefault
: 
ƒ TrackDefault()
TrackDefaultList
: 
ƒ TrackDefaultList()
TrackEvent
: 
ƒ TrackEvent()
TransformStream
: 
ƒ TransformStream()
TransformStreamDefaultController
: 
ƒ TransformStreamDefaultController()
TransitionEvent
: 
ƒ TransitionEvent()
Translator
: 
ƒ Translator()
TreeWalker
: 
ƒ TreeWalker()
TrustedHTML
: 
ƒ TrustedHTML()
TrustedScript
: 
ƒ TrustedScript()
TrustedScriptURL
: 
ƒ TrustedScriptURL()
TrustedTypePolicy
: 
ƒ TrustedTypePolicy()
TrustedTypePolicyFactory
: 
ƒ TrustedTypePolicyFactory()
TypeError
: 
ƒ TypeError()
UIEvent
: 
ƒ UIEvent()
URIError
: 
ƒ URIError()
URL
: 
ƒ URL()
URLPattern
: 
ƒ URLPattern()
URLSearchParams
: 
ƒ URLSearchParams()
USB
: 
ƒ USB()
USBAlternateInterface
: 
ƒ USBAlternateInterface()
USBConfiguration
: 
ƒ USBConfiguration()
USBConnectionEvent
: 
ƒ USBConnectionEvent()
USBDevice
: 
ƒ USBDevice()
USBEndpoint
: 
ƒ USBEndpoint()
USBInTransferResult
: 
ƒ USBInTransferResult()
USBInterface
: 
ƒ USBInterface()
USBIsochronousInTransferPacket
: 
ƒ USBIsochronousInTransferPacket()
USBIsochronousInTransferResult
: 
ƒ USBIsochronousInTransferResult()
USBIsochronousOutTransferPacket
: 
ƒ USBIsochronousOutTransferPacket()
USBIsochronousOutTransferResult
: 
ƒ USBIsochronousOutTransferResult()
USBOutTransferResult
: 
ƒ USBOutTransferResult()
Uint8Array
: 
ƒ Uint8Array()
Uint8ClampedArray
: 
ƒ Uint8ClampedArray()
Uint16Array
: 
ƒ Uint16Array()
Uint32Array
: 
ƒ Uint32Array()
UserActivation
: 
ƒ UserActivation()
VTTCue
: 
ƒ VTTCue()
VTTRegion
: 
ƒ VTTRegion()
ValidityState
: 
ƒ ValidityState()
VideoColorSpace
: 
ƒ VideoColorSpace()
VideoDecoder
: 
ƒ VideoDecoder()
VideoEncoder
: 
ƒ VideoEncoder()
VideoEncoderBuffer
: 
ƒ VideoEncoderBuffer()
VideoFrame
: 
ƒ VideoFrame()
VideoPlaybackQuality
: 
ƒ VideoPlaybackQuality()
VideoTrack
: 
ƒ VideoTrack()
VideoTrackList
: 
ƒ VideoTrackList()
ViewTimeline
: 
ƒ ViewTimeline()
ViewTransition
: 
ƒ ViewTransition()
ViewTransitionTypeSet
: 
ƒ ViewTransitionTypeSet()
Viewport
: 
ƒ Viewport()
VirtualKeyboard
: 
ƒ VirtualKeyboard()
VirtualKeyboardGeometryChangeEvent
: 
ƒ VirtualKeyboardGeometryChangeEvent()
VisibilityStateEntry
: 
ƒ VisibilityStateEntry()
VisualViewport
: 
ƒ VisualViewport()
WGSLLanguageFeatures
: 
ƒ WGSLLanguageFeatures()
WakeLock
: 
ƒ WakeLock()
WakeLockSentinel
: 
ƒ WakeLockSentinel()
WaveShaperNode
: 
ƒ WaveShaperNode()
WeakMap
: 
ƒ WeakMap()
WeakRef
: 
ƒ WeakRef()
WeakSet
: 
ƒ WeakSet()
WebAssembly
: 
WebAssembly {compile: ƒ, validate: ƒ, instantiate: ƒ, compileStreaming: ƒ, instantiateStreaming: ƒ, …}
WebGL2RenderingContext
: 
ƒ WebGL2RenderingContext()
WebGLActiveInfo
: 
ƒ WebGLActiveInfo()
WebGLBuffer
: 
ƒ WebGLBuffer()
WebGLContextEvent
: 
ƒ WebGLContextEvent()
WebGLFramebuffer
: 
ƒ WebGLFramebuffer()
WebGLObject
: 
ƒ WebGLObject()
WebGLProgram
: 
ƒ WebGLProgram()
WebGLQuery
: 
ƒ WebGLQuery()
WebGLRenderbuffer
: 
ƒ WebGLRenderbuffer()
WebGLRenderingContext
: 
ƒ WebGLRenderingContext()
WebGLSampler
: 
ƒ WebGLSampler()
WebGLShader
: 
ƒ WebGLShader()
WebGLShaderPrecisionFormat
: 
ƒ WebGLShaderPrecisionFormat()
WebGLSync
: 
ƒ WebGLSync()
WebGLTexture
: 
ƒ WebGLTexture()
WebGLTransformFeedback
: 
ƒ WebGLTransformFeedback()
WebGLUniformLocation
: 
ƒ WebGLUniformLocation()
WebGLVertexArrayObject
: 
ƒ WebGLVertexArrayObject()
WebKitCSSMatrix
: 
ƒ DOMMatrix()
WebKitMutationObserver
: 
ƒ MutationObserver()
WebSocket
: 
ƒ WebSocket()
WebSocketError
: 
ƒ WebSocketError()
WebSocketStream
: 
ƒ WebSocketStream()
WebTransport
: 
ƒ WebTransport()
WebTransportBidirectionalStream
: 
ƒ WebTransportBidirectionalStream()
WebTransportDatagramDuplexStream
: 
ƒ WebTransportDatagramDuplexStream()
WebTransportError
: 
ƒ WebTransportError()
WheelEvent
: 
ƒ WheelEvent()
Window
: 
ƒ Window()
WindowControlsOverlay
: 
ƒ WindowControlsOverlay()
WindowControlsOverlayGeometryChangeEvent
: 
ƒ WindowControlsOverlayGeometryChangeEvent()
Worker
: 
ƒ Worker()
Worklet
: 
ƒ Worklet()
WritableStream
: 
ƒ WritableStream()
WritableStreamDefaultController
: 
ƒ WritableStreamDefaultController()
WritableStreamDefaultWriter
: 
ƒ WritableStreamDefaultWriter()
Writer
: 
ƒ Writer()
XMLDocument
: 
ƒ XMLDocument()
XMLHttpRequest
: 
ƒ XMLHttpRequest()
XMLHttpRequestEventTarget
: 
ƒ XMLHttpRequestEventTarget()
XMLHttpRequestUpload
: 
ƒ XMLHttpRequestUpload()
XMLSerializer
: 
ƒ XMLSerializer()
XPathEvaluator
: 
ƒ XPathEvaluator()
XPathExpression
: 
ƒ XPathExpression()
XPathResult
: 
ƒ XPathResult()
XRAnchor
: 
ƒ XRAnchor()
XRAnchorSet
: 
ƒ XRAnchorSet()
XRBoundedReferenceSpace
: 
ƒ XRBoundedReferenceSpace()
XRCPUDepthInformation
: 
ƒ XRCPUDepthInformation()
XRCamera
: 
ƒ XRCamera()
XRCompositionLayer
: 
ƒ XRCompositionLayer()
XRDOMOverlayState
: 
ƒ XRDOMOverlayState()
XRDepthInformation
: 
ƒ XRDepthInformation()
XRFrame
: 
ƒ XRFrame()
XRGPUBinding
: 
ƒ XRGPUBinding()
XRGPUSubImage
: 
ƒ XRGPUSubImage()
XRHand
: 
ƒ XRHand()
XRHitTestResult
: 
ƒ XRHitTestResult()
XRHitTestSource
: 
ƒ XRHitTestSource()
XRImageTrackingResult
: 
ƒ XRImageTrackingResult()
XRInputSource
: 
ƒ XRInputSource()
XRInputSourceArray
: 
ƒ XRInputSourceArray()
XRInputSourceEvent
: 
ƒ XRInputSourceEvent()
XRInputSourcesChangeEvent
: 
ƒ XRInputSourcesChangeEvent()
XRJointPose
: 
ƒ XRJointPose()
XRJointSpace
: 
ƒ XRJointSpace()
XRLayer
: 
ƒ XRLayer()
XRLightEstimate
: 
ƒ XRLightEstimate()
XRLightProbe
: 
ƒ XRLightProbe()
XRPlane
: 
ƒ XRPlane()
XRPlaneSet
: 
ƒ XRPlaneSet()
XRPose
: 
ƒ XRPose()
XRProjectionLayer
: 
ƒ XRProjectionLayer()
XRRay
: 
ƒ XRRay()
XRReferenceSpace
: 
ƒ XRReferenceSpace()
XRReferenceSpaceEvent
: 
ƒ XRReferenceSpaceEvent()
XRRenderState
: 
ƒ XRRenderState()
XRRigidTransform
: 
ƒ XRRigidTransform()
XRSession
: 
ƒ XRSession()
XRSessionEvent
: 
ƒ XRSessionEvent()
XRSpace
: 
ƒ XRSpace()
XRSubImage
: 
ƒ XRSubImage()
XRSystem
: 
ƒ XRSystem()
XRTransientInputHitTestResult
: 
ƒ XRTransientInputHitTestResult()
XRTransientInputHitTestSource
: 
ƒ XRTransientInputHitTestSource()
XRView
: 
ƒ XRView()
XRViewerPose
: 
ƒ XRViewerPose()
XRViewport
: 
ƒ XRViewport()
XRWebGLBinding
: 
ƒ XRWebGLBinding()
XRWebGLDepthInformation
: 
ƒ XRWebGLDepthInformation()
XRWebGLLayer
: 
ƒ XRWebGLLayer()
XRWebGLSubImage
: 
ƒ XRWebGLSubImage()
XSLTProcessor
: 
ƒ XSLTProcessor()
console
: 
console {debug: ƒ, error: ƒ, info: ƒ, log: ƒ, warn: ƒ, …}
decodeURI
: 
ƒ decodeURI()
decodeURIComponent
: 
ƒ decodeURIComponent()
encodeURI
: 
ƒ encodeURI()
encodeURIComponent
: 
ƒ encodeURIComponent()
escape
: 
ƒ escape()
eval
: 
ƒ eval()
globalThis
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
isFinite
: 
ƒ isFinite()
isNaN
: 
ƒ isNaN()
offscreenBuffering
: 
true
parseFloat
: 
ƒ parseFloat()
parseInt
: 
ƒ parseInt()
undefined
: 
undefined
unescape
: 
ƒ unescape()
webkitMediaStream
: 
ƒ MediaStream()
webkitRTCPeerConnection
: 
ƒ RTCPeerConnection()
webkitSpeechGrammar
: 
ƒ SpeechGrammar()
webkitSpeechGrammarList
: 
ƒ SpeechGrammarList()
webkitSpeechRecognition
: 
ƒ SpeechRecognition()
webkitSpeechRecognitionError
: 
ƒ SpeechRecognitionErrorEvent()
webkitSpeechRecognitionEvent
: 
ƒ SpeechRecognitionEvent()
webkitURL
: 
ƒ URL()
[[Prototype]]
: 
Window
designMode
: 
"off"
dir
: 
""
doctype
: 
<!DOCTYPE html>
documentElement
: 
html
documentURI
: 
"chrome://flags/"
domain
: 
"flags"
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection []
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html
lastElementChild
: 
html
lastModified
: 
"09/22/2025 11:46:03"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection [script]
scrollingElement
: 
html
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, length: 2}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 854123.722, duration: null}
title
: 
"Experiments"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
(...)
parentElement
: 
null
parentNode
: 
document
previousSibling
: 
null
publicId
: 
""
systemId
: 
""
textContent
: 
null
[[Prototype]]
: 
DocumentType
firstElementChild
: 
html
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection []
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html
lastElementChild
: 
html
lastModified
: 
"09/22/2025 11:45:53"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection [script]
scrollingElement
: 
html
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, length: 2}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 844157.454, duration: null}
title
: 
"Experiments"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
(...)
parentElement
: 
null
parentNode
: 
document
previousElementSibling
: 
null
previousSibling
: 
comment
textContent
: 
" so don't mark it with direction or language attributes. "
[[Prototype]]
: 
Comment
role
: 
null
scrollHeight
: 
2109
scrollLeft
: 
0
scrollTop
: 
0
scrollWidth
: 
2689
shadowRoot
: 
null
slot
: 
""
tagName
: 
"HTML"
textContent
: 
"\n\n\n\n  \n  \n\nExperiments\n\n\n\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n\n\n\n  \n  \n\n\n"
get accessKey
: 
ƒ accessKey()
set accessKey
: 
ƒ accessKey()
get attributeStyleMap
: 
ƒ attributeStyleMap()
get autocapitalize
: 
ƒ autocapitalize()
set autocapitalize
: 
ƒ autocapitalize()
get autofocus
: 
ƒ autofocus()
set autofocus
: 
ƒ autofocus()
get contentEditable
: 
ƒ contentEditable()
set contentEditable
: 
ƒ contentEditable()
get dataset
: 
ƒ dataset()
get dir
: 
ƒ dir()
set dir
: 
ƒ dir()
get draggable
: 
ƒ draggable()
set draggable
: 
ƒ draggable()
get editContext
: 
ƒ editContext()
set editContext
: 
ƒ editContext()
get enterKeyHint
: 
ƒ enterKeyHint()
set enterKeyHint
: 
ƒ enterKeyHint()
get focusgroup
: 
ƒ focusgroup()
set focusgroup
: 
ƒ focusgroup()
get hidden
: 
ƒ hidden()
set hidden
: 
ƒ hidden()
get inert
: 
ƒ inert()
set inert
: 
ƒ inert()
get innerText
: 
ƒ innerText()
set innerText
: 
ƒ innerText()
get inputMode
: 
ƒ inputMode()
set inputMode
: 
ƒ inputMode()
get isContentEditable
: 
ƒ isContentEditable()
get lang
: 
ƒ lang()
set lang
: 
ƒ lang()
get nonce
: 
ƒ nonce()
set nonce
: 
ƒ nonce()
get offsetHeight
: 
ƒ offsetHeight()
get offsetLeft
: 
ƒ offsetLeft()
get offsetParent
: 
ƒ offsetParent()
get offsetTop
: 
ƒ offsetTop()
get offsetWidth
: 
ƒ offsetWidth()
get onabort
: 
ƒ onabort()
set onabort
: 
ƒ onabort()
get onanimationend
: 
ƒ onanimationend()
set onanimationend
: 
ƒ onanimationend()
get onanimationiteration
: 
ƒ onanimationiteration()
set onanimationiteration
: 
ƒ onanimationiteration()
get onanimationstart
: 
ƒ onanimationstart()
set onanimationstart
: 
ƒ onanimationstart()
get onauxclick
: 
ƒ onauxclick()
set onauxclick
: 
ƒ onauxclick()
get onbeforeinput
: 
ƒ onbeforeinput()
set onbeforeinput
: 
ƒ onbeforeinput()
get onbeforematch
: 
ƒ onbeforematch()
set onbeforematch
: 
ƒ onbeforematch()
get onbeforetoggle
: 
ƒ onbeforetoggle()
set onbeforetoggle
: 
ƒ onbeforetoggle()
get onbeforexrselect
: 
ƒ onbeforexrselect()
set onbeforexrselect
: 
ƒ onbeforexrselect()
get onblur
: 
ƒ onblur()
set onblur
: 
ƒ onblur()
get oncancel
: 
ƒ oncancel()
set oncancel
: 
ƒ oncancel()
get oncanplay
: 
ƒ oncanplay()
set oncanplay
: 
ƒ oncanplay()
get oncanplaythrough
: 
ƒ oncanplaythrough()
set oncanplaythrough
: 
ƒ oncanplaythrough()
get onchange
: 
ƒ onchange()
set onchange
: 
ƒ onchange()
get onclick
: 
ƒ onclick()
set onclick
: 
ƒ onclick()
get onclose
: 
ƒ onclose()
set onclose
: 
ƒ onclose()
get oncommand
: 
ƒ oncommand()
set oncommand
: 
ƒ oncommand()
get oncontentvisibilityautostatechange
: 
ƒ oncontentvisibilityautostatechange()
set oncontentvisibilityautostatechange
: 
ƒ oncontentvisibilityautostatechange()
get oncontextlost
: 
ƒ oncontextlost()
set oncontextlost
: 
ƒ oncontextlost()
get oncontextmenu
: 
ƒ oncontextmenu()
set oncontextmenu
: 
ƒ oncontextmenu()
get oncontextrestored
: 
ƒ oncontextrestored()
set oncontextrestored
: 
ƒ oncontextrestored()
get oncopy
: 
ƒ oncopy()
set oncopy
: 
ƒ oncopy()
get oncuechange
: 
ƒ oncuechange()
set oncuechange
: 
ƒ oncuechange()
get oncut
: 
ƒ oncut()
set oncut
: 
ƒ oncut()
get ondblclick
: 
ƒ ondblclick()
set ondblclick
: 
ƒ ondblclick()
get ondrag
: 
ƒ ondrag()
set ondrag
: 
ƒ ondrag()
get ondragend
: 
ƒ ondragend()
set ondragend
: 
ƒ ondragend()
get ondragenter
: 
ƒ ondragenter()
set ondragenter
: 
ƒ ondragenter()
get ondragleave
: 
ƒ ondragleave()
set ondragleave
: 
ƒ ondragleave()
get ondragover
: 
ƒ ondragover()
set ondragover
: 
ƒ ondragover()
get ondragstart
: 
ƒ ondragstart()
set ondragstart
: 
ƒ ondragstart()
get ondrop
: 
ƒ ondrop()
set ondrop
: 
ƒ ondrop()
get ondurationchange
: 
ƒ ondurationchange()
set ondurationchange
: 
ƒ ondurationchange()
get onemptied
: 
ƒ onemptied()
set onemptied
: 
ƒ onemptied()
get onended
: 
ƒ onended()
set onended
: 
ƒ onended()
get onerror
: 
ƒ onerror()
set onerror
: 
ƒ onerror()
get onfocus
: 
ƒ onfocus()
set onfocus
: 
ƒ onfocus()
get onformdata
: 
ƒ onformdata()
set onformdata
: 
ƒ onformdata()
get ongotpointercapture
: 
ƒ ongotpointercapture()
set ongotpointercapture
: 
ƒ ongotpointercapture()
get oninput
: 
ƒ oninput()
set oninput
: 
ƒ oninput()
get oninvalid
: 
ƒ oninvalid()
set oninvalid
: 
ƒ oninvalid()
get onkeydown
: 
ƒ onkeydown()
set onkeydown
: 
ƒ onkeydown()
get onkeypress
: 
ƒ onkeypress()
set onkeypress
: 
ƒ onkeypress()
get onkeyup
: 
ƒ onkeyup()
set onkeyup
: 
ƒ onkeyup()
get onload
: 
ƒ onload()
set onload
: 
ƒ onload()
get onloadeddata
: 
ƒ onloadeddata()
set onloadeddata
: 
ƒ onloadeddata()
get onloadedmetadata
: 
ƒ onloadedmetadata()
set onloadedmetadata
: 
ƒ onloadedmetadata()
get onloadstart
: 
ƒ onloadstart()
set onloadstart
: 
ƒ onloadstart()
get onlostpointercapture
: 
ƒ onlostpointercapture()
set onlostpointercapture
: 
ƒ onlostpointercapture()
get onmousedown
: 
ƒ onmousedown()
set onmousedown
: 
ƒ onmousedown()
get onmousemove
: 
ƒ onmousemove()
set onmousemove
: 
ƒ onmousemove()
get onmouseout
: 
ƒ onmouseout()
set onmouseout
: 
ƒ onmouseout()
get onmouseover
: 
ƒ onmouseover()
set onmouseover
: 
ƒ onmouseover()
get onmouseup
: 
ƒ onmouseup()
set onmouseup
: 
ƒ onmouseup()
get onmousewheel
: 
ƒ onmousewheel()
set onmousewheel
: 
ƒ onmousewheel()
get onoverscroll
: 
ƒ onoverscroll()
set onoverscroll
: 
ƒ onoverscroll()
get onpaste
: 
ƒ onpaste()
set onpaste
: 
ƒ onpaste()
get onpause
: 
ƒ onpause()
set onpause
: 
ƒ onpause()
get onplay
: 
ƒ onplay()
set onplay
: 
ƒ onplay()
get onplaying
: 
ƒ onplaying()
set onplaying
: 
ƒ onplaying()
get onpointercancel
: 
ƒ onpointercancel()
set onpointercancel
: 
ƒ onpointercancel()
get onpointerdown
: 
ƒ onpointerdown()
set onpointerdown
: 
ƒ onpointerdown()
get onpointerenter
: 
ƒ onpointerenter()
set onpointerenter
: 
ƒ onpointerenter()
get onpointerleave
: 
ƒ onpointerleave()
set onpointerleave
: 
ƒ onpointerleave()
get onpointermove
: 
ƒ onpointermove()
set onpointermove
: 
ƒ onpointermove()
get onpointerout
: 
ƒ onpointerout()
set onpointerout
: 
ƒ onpointerout()
get onpointerover
: 
ƒ onpointerover()
set onpointerover
: 
ƒ onpointerover()
get onpointerrawupdate
: 
ƒ onpointerrawupdate()
set onpointerrawupdate
: 
ƒ onpointerrawupdate()
get onpointerup
: 
ƒ onpointerup()
set onpointerup
: 
ƒ onpointerup()
get onprogress
: 
ƒ onprogress()
set onprogress
: 
ƒ onprogress()
get onratechange
: 
ƒ onratechange()
set onratechange
: 
ƒ onratechange()
get onreset
: 
ƒ onreset()
set onreset
: 
ƒ onreset()
get onresize
: 
ƒ onresize()
set onresize
: 
ƒ onresize()
get onscroll
: 
ƒ onscroll()
set onscroll
: 
ƒ onscroll()
get onscrollend
: 
ƒ onscrollend()
set onscrollend
: 
ƒ onscrollend()
get onscrollsnapchange
: 
ƒ onscrollsnapchange()
set onscrollsnapchange
: 
ƒ onscrollsnapchange()
get onscrollsnapchanging
: 
ƒ onscrollsnapchanging()
set onscrollsnapchanging
: 
ƒ onscrollsnapchanging()
get onsecuritypolicyviolation
: 
ƒ onsecuritypolicyviolation()
set onsecuritypolicyviolation
: 
ƒ onsecuritypolicyviolation()
get onseeked
: 
ƒ onseeked()
set onseeked
: 
ƒ onseeked()
get onseeking
: 
ƒ onseeking()
set onseeking
: 
ƒ onseeking()
get onselect
: 
ƒ onselect()
set onselect
: 
ƒ onselect()
get onselectionchange
: 
ƒ onselectionchange()
set onselectionchange
: 
ƒ onselectionchange()
get onselectstart
: 
ƒ onselectstart()
set onselectstart
: 
ƒ onselectstart()
get onslotchange
: 
ƒ onslotchange()
set onslotchange
: 
ƒ onslotchange()
get onstalled
: 
ƒ onstalled()
set onstalled
: 
ƒ onstalled()
get onsubmit
: 
ƒ onsubmit()
set onsubmit
: 
ƒ onsubmit()
get onsuspend
: 
ƒ onsuspend()
set onsuspend
: 
ƒ onsuspend()
get ontimeupdate
: 
ƒ ontimeupdate()
set ontimeupdate
: 
ƒ ontimeupdate()
get ontoggle
: 
ƒ ontoggle()
set ontoggle
: 
ƒ ontoggle()
get ontransitioncancel
: 
ƒ ontransitioncancel()
set ontransitioncancel
: 
ƒ ontransitioncancel()
get ontransitionend
: 
ƒ ontransitionend()
set ontransitionend
: 
ƒ ontransitionend()
get ontransitionrun
: 
ƒ ontransitionrun()
set ontransitionrun
: 
ƒ ontransitionrun()
get ontransitionstart
: 
ƒ ontransitionstart()
set ontransitionstart
: 
ƒ ontransitionstart()
get onvolumechange
: 
ƒ onvolumechange()
set onvolumechange
: 
ƒ onvolumechange()
get onwaiting
: 
ƒ onwaiting()
set onwaiting
: 
ƒ onwaiting()
get onwebkitanimationend
: 
ƒ onwebkitanimationend()
set onwebkitanimationend
: 
ƒ onwebkitanimationend()
get onwebkitanimationiteration
: 
ƒ onwebkitanimationiteration()
set onwebkitanimationiteration
: 
ƒ onwebkitanimationiteration()
get onwebkitanimationstart
: 
ƒ onwebkitanimationstart()
set onwebkitanimationstart
: 
ƒ onwebkitanimationstart()
get onwebkittransitionend
: 
ƒ onwebkittransitionend()
set onwebkittransitionend
: 
ƒ onwebkittransitionend()
get onwheel
: 
ƒ onwheel()
set onwheel
: 
ƒ onwheel()
get outerText
: 
ƒ outerText()
set outerText
: 
ƒ outerText()
get popover
: 
ƒ popover()
set popover
: 
ƒ popover()
get scrollParent
: 
ƒ scrollParent()
get spellcheck
: 
ƒ spellcheck()
set spellcheck
: 
ƒ spellcheck()
get style
: 
ƒ style()
set style
: 
ƒ style()
get tabIndex
: 
ƒ tabIndex()
set tabIndex
: 
ƒ tabIndex()
get title
: 
ƒ title()
set title
: 
ƒ title()
get translate
: 
ƒ translate()
set translate
: 
ƒ translate()
get virtualKeyboardPolicy
: 
ƒ virtualKeyboardPolicy()
set virtualKeyboardPolicy
: 
ƒ virtualKeyboardPolicy()
get writingSuggestions
: 
ƒ writingSuggestions()
set writingSuggestions
: 
ƒ writingSuggestions()
[[Prototype]]
: 
Element
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
previousSibling
: 
null
textContent
: 
null
get URL
: 
ƒ URL()
get activeElement
: 
ƒ activeElement()
get adoptedStyleSheets
: 
ƒ adoptedStyleSheets()
set adoptedStyleSheets
: 
ƒ adoptedStyleSheets()
get alinkColor
: 
ƒ alinkColor()
set alinkColor
: 
ƒ alinkColor()
get all
: 
ƒ all()
get anchors
: 
ƒ anchors()
get applets
: 
ƒ applets()
get bgColor
: 
ƒ bgColor()
set bgColor
: 
ƒ bgColor()
get body
: 
ƒ body()
set body
: 
ƒ body()
get characterSet
: 
ƒ characterSet()
get charset
: 
ƒ charset()
get childElementCount
: 
ƒ childElementCount()
get children
: 
ƒ children()
get compatMode
: 
ƒ compatMode()
get contentType
: 
ƒ contentType()
get cookie
: 
ƒ cookie()
set cookie
: 
ƒ cookie()
get currentScript
: 
ƒ currentScript()
get defaultView
: 
ƒ defaultView()
get designMode
: 
ƒ designMode()
set designMode
: 
ƒ designMode()
get dir
: 
ƒ dir()
set dir
: 
ƒ dir()
get doctype
: 
ƒ doctype()
get documentElement
: 
ƒ documentElement()
get documentURI
: 
ƒ documentURI()
get domain
: 
ƒ domain()
set domain
: 
ƒ domain()
get embeds
: 
ƒ embeds()
get featurePolicy
: 
ƒ featurePolicy()
get fgColor
: 
ƒ fgColor()
set fgColor
: 
ƒ fgColor()
get firstElementChild
: 
ƒ firstElementChild()
get fonts
: 
ƒ fonts()
get forms
: 
ƒ forms()
get fragmentDirective
: 
ƒ fragmentDirective()
get fullscreen
: 
ƒ fullscreen()
set fullscreen
: 
ƒ fullscreen()
get fullscreenElement
: 
ƒ fullscreenElement()
set fullscreenElement
: 
ƒ fullscreenElement()
get fullscreenEnabled
: 
ƒ fullscreenEnabled()
set fullscreenEnabled
: 
ƒ fullscreenEnabled()
get head
: 
ƒ head()
get hidden
: 
ƒ hidden()
get images
: 
ƒ images()
get implementation
: 
ƒ implementation()
get inputEncoding
: 
ƒ inputEncoding()
get lastElementChild
: 
ƒ lastElementChild()
get lastModified
: 
ƒ lastModified()
get linkColor
: 
ƒ linkColor()
set linkColor
: 
ƒ linkColor()
get links
: 
ƒ links()
get onabort
: 
ƒ onabort()
set onabort
: 
ƒ onabort()
get onanimationend
: 
ƒ onanimationend()
set onanimationend
: 
ƒ onanimationend()
get onanimationiteration
: 
ƒ onanimationiteration()
set onanimationiteration
: 
ƒ onanimationiteration()
get onanimationstart
: 
ƒ onanimationstart()
set onanimationstart
: 
ƒ onanimationstart()
get onauxclick
: 
ƒ onauxclick()
set onauxclick
: 
ƒ onauxclick()
get onbeforecopy
: 
ƒ onbeforecopy()
set onbeforecopy
: 
ƒ onbeforecopy()
get onbeforecut
: 
ƒ onbeforecut()
set onbeforecut
: 
ƒ onbeforecut()
get onbeforeinput
: 
ƒ onbeforeinput()
set onbeforeinput
: 
ƒ onbeforeinput()
get onbeforematch
: 
ƒ onbeforematch()
set onbeforematch
: 
ƒ onbeforematch()
get onbeforepaste
: 
ƒ onbeforepaste()
set onbeforepaste
: 
ƒ onbeforepaste()
get onbeforetoggle
: 
ƒ onbeforetoggle()
set onbeforetoggle
: 
ƒ onbeforetoggle()
get onbeforexrselect
: 
ƒ onbeforexrselect()
set onbeforexrselect
: 
ƒ onbeforexrselect()
get onblur
: 
ƒ onblur()
set onblur
: 
ƒ onblur()
get oncancel
: 
ƒ oncancel()
set oncancel
: 
ƒ oncancel()
get oncanplay
: 
ƒ oncanplay()
set oncanplay
: 
ƒ oncanplay()
get oncanplaythrough
: 
ƒ oncanplaythrough()
set oncanplaythrough
: 
ƒ oncanplaythrough()
get onchange
: 
ƒ onchange()
set onchange
: 
ƒ onchange()
get onclick
: 
ƒ onclick()
set onclick
: 
ƒ onclick()
get onclose
: 
ƒ onclose()
set onclose
: 
ƒ onclose()
get oncommand
: 
ƒ oncommand()
set oncommand
: 
ƒ oncommand()
get oncontentvisibilityautostatechange
: 
ƒ oncontentvisibilityautostatechange()
set oncontentvisibilityautostatechange
: 
ƒ oncontentvisibilityautostatechange()
get oncontextlost
: 
ƒ oncontextlost()
set oncontextlost
: 
ƒ oncontextlost()
get oncontextmenu
: 
ƒ oncontextmenu()
set oncontextmenu
: 
ƒ oncontextmenu()
get oncontextrestored
: 
ƒ oncontextrestored()
set oncontextrestored
: 
ƒ oncontextrestored()
get oncopy
: 
ƒ oncopy()
set oncopy
: 
ƒ oncopy()
get oncuechange
: 
ƒ oncuechange()
set oncuechange
: 
ƒ oncuechange()
get oncut
: 
ƒ oncut()
set oncut
: 
ƒ oncut()
get ondblclick
: 
ƒ ondblclick()
set ondblclick
: 
ƒ ondblclick()
get ondrag
: 
ƒ ondrag()
set ondrag
: 
ƒ ondrag()
get ondragend
: 
ƒ ondragend()
set ondragend
: 
ƒ ondragend()
get ondragenter
: 
ƒ ondragenter()
set ondragenter
: 
ƒ ondragenter()
get ondragleave
: 
ƒ ondragleave()
set ondragleave
: 
ƒ ondragleave()
get ondragover
: 
ƒ ondragover()
set ondragover
: 
ƒ ondragover()
get ondragstart
: 
ƒ ondragstart()
set ondragstart
: 
ƒ ondragstart()
get ondrop
: 
ƒ ondrop()
set ondrop
: 
ƒ ondrop()
get ondurationchange
: 
ƒ ondurationchange()
set ondurationchange
: 
ƒ ondurationchange()
get onemptied
: 
ƒ onemptied()
set onemptied
: 
ƒ onemptied()
get onended
: 
ƒ onended()
set onended
: 
ƒ onended()
get onerror
: 
ƒ onerror()
set onerror
: 
ƒ onerror()
get onfocus
: 
ƒ onfocus()
set onfocus
: 
ƒ onfocus()
get onformdata
: 
ƒ onformdata()
set onformdata
: 
ƒ onformdata()
get onfreeze
: 
ƒ onfreeze()
set onfreeze
: 
ƒ onfreeze()
get onfullscreenchange
: 
ƒ onfullscreenchange()
set onfullscreenchange
: 
ƒ onfullscreenchange()
get onfullscreenerror
: 
ƒ onfullscreenerror()
set onfullscreenerror
: 
ƒ onfullscreenerror()
get ongotpointercapture
: 
ƒ ongotpointercapture()
set ongotpointercapture
: 
ƒ ongotpointercapture()
get oninput
: 
ƒ oninput()
set oninput
: 
ƒ oninput()
get oninvalid
: 
ƒ oninvalid()
set oninvalid
: 
ƒ oninvalid()
get onkeydown
: 
ƒ onkeydown()
set onkeydown
: 
ƒ onkeydown()
get onkeypress
: 
ƒ onkeypress()
set onkeypress
: 
ƒ onkeypress()
get onkeyup
: 
ƒ onkeyup()
set onkeyup
: 
ƒ onkeyup()
get onload
: 
ƒ onload()
set onload
: 
ƒ onload()
get onloadeddata
: 
ƒ onloadeddata()
set onloadeddata
: 
ƒ onloadeddata()
get onloadedmetadata
: 
ƒ onloadedmetadata()
set onloadedmetadata
: 
ƒ onloadedmetadata()
get onloadstart
: 
ƒ onloadstart()
set onloadstart
: 
ƒ onloadstart()
get onlostpointercapture
: 
ƒ onlostpointercapture()
set onlostpointercapture
: 
ƒ onlostpointercapture()
get onmousedown
: 
ƒ onmousedown()
set onmousedown
: 
ƒ onmousedown()
get onmousemove
: 
ƒ onmousemove()
set onmousemove
: 
ƒ onmousemove()
get onmouseout
: 
ƒ onmouseout()
set onmouseout
: 
ƒ onmouseout()
get onmouseover
: 
ƒ onmouseover()
set onmouseover
: 
ƒ onmouseover()
get onmouseup
: 
ƒ onmouseup()
set onmouseup
: 
ƒ onmouseup()
get onmousewheel
: 
ƒ onmousewheel()
set onmousewheel
: 
ƒ onmousewheel()
get onoverscroll
: 
ƒ onoverscroll()
set onoverscroll
: 
ƒ onoverscroll()
get onpaste
: 
ƒ onpaste()
set onpaste
: 
ƒ onpaste()
get onpause
: 
ƒ onpause()
set onpause
: 
ƒ onpause()
get onplay
: 
ƒ onplay()
set onplay
: 
ƒ onplay()
get onplaying
: 
ƒ onplaying()
set onplaying
: 
ƒ onplaying()
get onpointercancel
: 
ƒ onpointercancel()
set onpointercancel
: 
ƒ onpointercancel()
get onpointerdown
: 
ƒ onpointerdown()
set onpointerdown
: 
ƒ onpointerdown()
get onpointerenter
: 
ƒ onpointerenter()
set onpointerenter
: 
ƒ onpointerenter()
get onpointerleave
: 
ƒ onpointerleave()
set onpointerleave
: 
ƒ onpointerleave()
get onpointerlockchange
: 
ƒ onpointerlockchange()
set onpointerlockchange
: 
ƒ onpointerlockchange()
get onpointerlockerror
: 
ƒ onpointerlockerror()
set onpointerlockerror
: 
ƒ onpointerlockerror()
get onpointermove
: 
ƒ onpointermove()
set onpointermove
: 
ƒ onpointermove()
get onpointerout
: 
ƒ onpointerout()
set onpointerout
: 
ƒ onpointerout()
get onpointerover
: 
ƒ onpointerover()
set onpointerover
: 
ƒ onpointerover()
get onpointerrawupdate
: 
ƒ onpointerrawupdate()
set onpointerrawupdate
: 
ƒ onpointerrawupdate()
get onpointerup
: 
ƒ onpointerup()
set onpointerup
: 
ƒ onpointerup()
get onprerenderingchange
: 
ƒ onprerenderingchange()
set onprerenderingchange
: 
ƒ onprerenderingchange()
get onprogress
: 
ƒ onprogress()
set onprogress
: 
ƒ onprogress()
get onratechange
: 
ƒ onratechange()
set onratechange
: 
ƒ onratechange()
get onreset
: 
ƒ onreset()
set onreset
: 
ƒ onreset()
get onresize
: 
ƒ onresize()
set onresize
: 
ƒ onresize()
get onresume
: 
ƒ onresume()
set onresume
: 
ƒ onresume()
get onscroll
: 
ƒ onscroll()
set onscroll
: 
ƒ onscroll()
get onscrollend
: 
ƒ onscrollend()
set onscrollend
: 
ƒ onscrollend()
get onscrollsnapchange
: 
ƒ onscrollsnapchange()
set onscrollsnapchange
: 
ƒ onscrollsnapchange()
get onscrollsnapchanging
: 
ƒ onscrollsnapchanging()
set onscrollsnapchanging
: 
ƒ onscrollsnapchanging()
get onsearch
: 
ƒ onsearch()
set onsearch
: 
ƒ onsearch()
get onsecuritypolicyviolation
: 
ƒ onsecuritypolicyviolation()
set onsecuritypolicyviolation
: 
ƒ onsecuritypolicyviolation()
get onseeked
: 
ƒ onseeked()
set onseeked
: 
ƒ onseeked()
get onseeking
: 
ƒ onseeking()
set onseeking
: 
ƒ onseeking()
get onselect
: 
ƒ onselect()
set onselect
: 
ƒ onselect()
get onselectionchange
: 
ƒ onselectionchange()
set onselectionchange
: 
ƒ onselectionchange()
get onselectstart
: 
ƒ onselectstart()
set onselectstart
: 
ƒ onselectstart()
get onslotchange
: 
ƒ onslotchange()
set onslotchange
: 
ƒ onslotchange()
get onstalled
: 
ƒ onstalled()
set onstalled
: 
ƒ onstalled()
get onsubmit
: 
ƒ onsubmit()
set onsubmit
: 
ƒ onsubmit()
get onsuspend
: 
ƒ onsuspend()
set onsuspend
: 
ƒ onsuspend()
get ontimeupdate
: 
ƒ ontimeupdate()
set ontimeupdate
: 
ƒ ontimeupdate()
get ontoggle
: 
ƒ ontoggle()
set ontoggle
: 
ƒ ontoggle()
get ontransitioncancel
: 
ƒ ontransitioncancel()
set ontransitioncancel
: 
ƒ ontransitioncancel()
get ontransitionend
: 
ƒ ontransitionend()
set ontransitionend
: 
ƒ ontransitionend()
get ontransitionrun
: 
ƒ ontransitionrun()
set ontransitionrun
: 
ƒ ontransitionrun()
get ontransitionstart
: 
ƒ ontransitionstart()
set ontransitionstart
: 
ƒ ontransitionstart()
get onvisibilitychange
: 
ƒ onvisibilitychange()
set onvisibilitychange
: 
ƒ onvisibilitychange()
get onvolumechange
: 
ƒ onvolumechange()
set onvolumechange
: 
ƒ onvolumechange()
get onwaiting
: 
ƒ onwaiting()
set onwaiting
: 
ƒ onwaiting()
get onwebkitanimationend
: 
ƒ onwebkitanimationend()
set onwebkitanimationend
: 
ƒ onwebkitanimationend()
get onwebkitanimationiteration
: 
ƒ onwebkitanimationiteration()
set onwebkitanimationiteration
: 
ƒ onwebkitanimationiteration()
get onwebkitanimationstart
: 
ƒ onwebkitanimationstart()
set onwebkitanimationstart
: 
ƒ onwebkitanimationstart()
get onwebkitfullscreenchange
: 
ƒ onwebkitfullscreenchange()
set onwebkitfullscreenchange
: 
ƒ onwebkitfullscreenchange()
get onwebkitfullscreenerror
: 
ƒ onwebkitfullscreenerror()
set onwebkitfullscreenerror
: 
ƒ onwebkitfullscreenerror()
get onwebkittransitionend
: 
ƒ onwebkittransitionend()
set onwebkittransitionend
: 
ƒ onwebkittransitionend()
get onwheel
: 
ƒ onwheel()
set onwheel
: 
ƒ onwheel()
get pictureInPictureElement
: 
ƒ pictureInPictureElement()
get pictureInPictureEnabled
: 
ƒ pictureInPictureEnabled()
get plugins
: 
ƒ plugins()
get pointerLockElement
: 
ƒ pointerLockElement()
get prerendering
: 
ƒ prerendering()
get readyState
: 
ƒ readyState()
get referrer
: 
ƒ referrer()
get rootElement
: 
ƒ rootElement()
get scripts
: 
ƒ scripts()
get scrollingElement
: 
ƒ scrollingElement()
get softNavigations
: 
ƒ softNavigations()
get styleSheets
: 
ƒ styleSheets()
get timeline
: 
ƒ timeline()
get title
: 
ƒ title()
set title
: 
ƒ title()
get visibilityState
: 
ƒ visibilityState()
get vlinkColor
: 
ƒ vlinkColor()
set vlinkColor
: 
ƒ vlinkColor()
get wasDiscarded
: 
ƒ wasDiscarded()
get webkitCurrentFullScreenElement
: 
ƒ webkitCurrentFullScreenElement()
get webkitFullscreenElement
: 
ƒ webkitFullscreenElement()
get webkitFullscreenEnabled
: 
ƒ webkitFullscreenEnabled()
get webkitHidden
: 
ƒ webkitHidden()
get webkitIsFullScreen
: 
ƒ webkitIsFullScreen()
get webkitVisibilityState
: 
ƒ webkitVisibilityState()
get xmlEncoding
: 
ƒ xmlEncoding()
get xmlStandalone
: 
ƒ xmlStandalone()
set xmlStandalone
: 
ƒ xmlStandalone()
get xmlVersion
: 
ƒ xmlVersion()
set xmlVersion
: 
ƒ xmlVersion()
[[Prototype]]
: 
Node
parentElement
: 
null
parentNode
: 
document
previousElementSibling
: 
(...)
previousSibling
: 
comment
textContent
: 
" so don't mark it with direction or language attributes. "
[[Prototype]]
: 
CharacterData
3
: 
html
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, class: class, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(3) [head, text, body]
children
: 
HTMLCollection(2) [head, body]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
head
firstElementChild
: 
head
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"<head>\n<meta charset=\"utf-8\">\n<meta name=\"color-scheme\" content=\"light dark\">\n\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <link rel=\"stylesheet\" href=\"chrome://resources/css/text_defaults_md.css\">\n\n<title>Experiments</title>\n\n\n<style>\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n</style>\n</head>\n<body>\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n</body>"
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
body
lastElementChild
: 
body
localName
: 
"html"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"HTML"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
(...)
length
: 
4
[[Prototype]]
: 
NodeList
firstChild
: 
<!DOCTYPE html>
isConnected
: 
true
lastChild
: 
html
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
previousSibling
: 
null
textContent
: 
null
get URL
: 
ƒ URL()
get activeElement
: 
ƒ activeElement()
get adoptedStyleSheets
: 
ƒ adoptedStyleSheets()
set adoptedStyleSheets
: 
ƒ adoptedStyleSheets()
get alinkColor
: 
ƒ alinkColor()
set alinkColor
: 
ƒ alinkColor()
get all
: 
ƒ all()
get anchors
: 
ƒ anchors()
get applets
: 
ƒ applets()
get bgColor
: 
ƒ bgColor()
set bgColor
: 
ƒ bgColor()
get body
: 
ƒ body()
set body
: 
ƒ body()
get characterSet
: 
ƒ characterSet()
get charset
: 
ƒ charset()
get childElementCount
: 
ƒ childElementCount()
get children
: 
ƒ children()
get compatMode
: 
ƒ compatMode()
get contentType
: 
ƒ contentType()
get cookie
: 
ƒ cookie()
set cookie
: 
ƒ cookie()
get currentScript
: 
ƒ currentScript()
get defaultView
: 
ƒ defaultView()
get designMode
: 
ƒ designMode()
set designMode
: 
ƒ designMode()
get dir
: 
ƒ dir()
set dir
: 
ƒ dir()
get doctype
: 
ƒ doctype()
get documentElement
: 
ƒ documentElement()
get documentURI
: 
ƒ documentURI()
get domain
: 
ƒ domain()
set domain
: 
ƒ domain()
get embeds
: 
ƒ embeds()
get featurePolicy
: 
ƒ featurePolicy()
get fgColor
: 
ƒ fgColor()
set fgColor
: 
ƒ fgColor()
get firstElementChild
: 
ƒ firstElementChild()
get fonts
: 
ƒ fonts()
get forms
: 
ƒ forms()
get fragmentDirective
: 
ƒ fragmentDirective()
get fullscreen
: 
ƒ fullscreen()
set fullscreen
: 
ƒ fullscreen()
get fullscreenElement
: 
ƒ fullscreenElement()
set fullscreenElement
: 
ƒ fullscreenElement()
get fullscreenEnabled
: 
ƒ fullscreenEnabled()
set fullscreenEnabled
: 
ƒ fullscreenEnabled()
get head
: 
ƒ head()
get hidden
: 
ƒ hidden()
get images
: 
ƒ images()
get implementation
: 
ƒ implementation()
get inputEncoding
: 
ƒ inputEncoding()
get lastElementChild
: 
ƒ lastElementChild()
get lastModified
: 
ƒ lastModified()
get linkColor
: 
ƒ linkColor()
set linkColor
: 
ƒ linkColor()
get links
: 
ƒ links()
get onabort
: 
ƒ onabort()
set onabort
: 
ƒ onabort()
get onanimationend
: 
ƒ onanimationend()
set onanimationend
: 
ƒ onanimationend()
get onanimationiteration
: 
ƒ onanimationiteration()
set onanimationiteration
: 
ƒ onanimationiteration()
get onanimationstart
: 
ƒ onanimationstart()
set onanimationstart
: 
ƒ onanimationstart()
get onauxclick
: 
ƒ onauxclick()
set onauxclick
: 
ƒ onauxclick()
get onbeforecopy
: 
ƒ onbeforecopy()
set onbeforecopy
: 
ƒ onbeforecopy()
get onbeforecut
: 
ƒ onbeforecut()
set onbeforecut
: 
ƒ onbeforecut()
get onbeforeinput
: 
ƒ onbeforeinput()
set onbeforeinput
: 
ƒ onbeforeinput()
get onbeforematch
: 
ƒ onbeforematch()
set onbeforematch
: 
ƒ onbeforematch()
get onbeforepaste
: 
ƒ onbeforepaste()
set onbeforepaste
: 
ƒ onbeforepaste()
get onbeforetoggle
: 
ƒ onbeforetoggle()
set onbeforetoggle
: 
ƒ onbeforetoggle()
get onbeforexrselect
: 
ƒ onbeforexrselect()
set onbeforexrselect
: 
ƒ onbeforexrselect()
get onblur
: 
ƒ onblur()
set onblur
: 
ƒ onblur()
get oncancel
: 
ƒ oncancel()
set oncancel
: 
ƒ oncancel()
get oncanplay
: 
ƒ oncanplay()
set oncanplay
: 
ƒ oncanplay()
get oncanplaythrough
: 
ƒ oncanplaythrough()
set oncanplaythrough
: 
ƒ oncanplaythrough()
get onchange
: 
ƒ onchange()
set onchange
: 
ƒ onchange()
get onclick
: 
ƒ onclick()
set onclick
: 
ƒ onclick()
get onclose
: 
ƒ onclose()
set onclose
: 
ƒ onclose()
get oncommand
: 
ƒ oncommand()
set oncommand
: 
ƒ oncommand()
get oncontentvisibilityautostatechange
: 
ƒ oncontentvisibilityautostatechange()
set oncontentvisibilityautostatechange
: 
ƒ oncontentvisibilityautostatechange()
get oncontextlost
: 
ƒ oncontextlost()
set oncontextlost
: 
ƒ oncontextlost()
get oncontextmenu
: 
ƒ oncontextmenu()
set oncontextmenu
: 
ƒ oncontextmenu()
get oncontextrestored
: 
ƒ oncontextrestored()
set oncontextrestored
: 
ƒ oncontextrestored()
get oncopy
: 
ƒ oncopy()
set oncopy
: 
ƒ oncopy()
get oncuechange
: 
ƒ oncuechange()
set oncuechange
: 
ƒ oncuechange()
get oncut
: 
ƒ oncut()
set oncut
: 
ƒ oncut()
get ondblclick
: 
ƒ ondblclick()
set ondblclick
: 
ƒ ondblclick()
get ondrag
: 
ƒ ondrag()
set ondrag
: 
ƒ ondrag()
get ondragend
: 
ƒ ondragend()
set ondragend
: 
ƒ ondragend()
get ondragenter
: 
ƒ ondragenter()
set ondragenter
: 
ƒ ondragenter()
get ondragleave
: 
ƒ ondragleave()
set ondragleave
: 
ƒ ondragleave()
get ondragover
: 
ƒ ondragover()
set ondragover
: 
ƒ ondragover()
get ondragstart
: 
ƒ ondragstart()
set ondragstart
: 
ƒ ondragstart()
get ondrop
: 
ƒ ondrop()
set ondrop
: 
ƒ ondrop()
get ondurationchange
: 
ƒ ondurationchange()
set ondurationchange
: 
ƒ ondurationchange()
get onemptied
: 
ƒ onemptied()
set onemptied
: 
ƒ onemptied()
get onended
: 
ƒ onended()
set onended
: 
ƒ onended()
get onerror
: 
ƒ onerror()
set onerror
: 
ƒ onerror()
get onfocus
: 
ƒ onfocus()
set onfocus
: 
ƒ onfocus()
get onformdata
: 
ƒ onformdata()
set onformdata
: 
ƒ onformdata()
get onfreeze
: 
ƒ onfreeze()
set onfreeze
: 
ƒ onfreeze()
get onfullscreenchange
: 
ƒ onfullscreenchange()
set onfullscreenchange
: 
ƒ onfullscreenchange()
get onfullscreenerror
: 
ƒ onfullscreenerror()
set onfullscreenerror
: 
ƒ onfullscreenerror()
get ongotpointercapture
: 
ƒ ongotpointercapture()
set ongotpointercapture
: 
ƒ ongotpointercapture()
get oninput
: 
ƒ oninput()
set oninput
: 
ƒ oninput()
get oninvalid
: 
ƒ oninvalid()
set oninvalid
: 
ƒ oninvalid()
get onkeydown
: 
ƒ onkeydown()
set onkeydown
: 
ƒ onkeydown()
get onkeypress
: 
ƒ onkeypress()
set onkeypress
: 
ƒ onkeypress()
get onkeyup
: 
ƒ onkeyup()
set onkeyup
: 
ƒ onkeyup()
get onload
: 
ƒ onload()
set onload
: 
ƒ onload()
get onloadeddata
: 
ƒ onloadeddata()
set onloadeddata
: 
ƒ onloadeddata()
get onloadedmetadata
: 
ƒ onloadedmetadata()
set onloadedmetadata
: 
ƒ onloadedmetadata()
get onloadstart
: 
ƒ onloadstart()
set onloadstart
: 
ƒ onloadstart()
get onlostpointercapture
: 
ƒ onlostpointercapture()
set onlostpointercapture
: 
ƒ onlostpointercapture()
get onmousedown
: 
ƒ onmousedown()
set onmousedown
: 
ƒ onmousedown()
get onmousemove
: 
ƒ onmousemove()
set onmousemove
: 
ƒ onmousemove()
get onmouseout
: 
ƒ onmouseout()
set onmouseout
: 
ƒ onmouseout()
get onmouseover
: 
ƒ onmouseover()
set onmouseover
: 
ƒ onmouseover()
get onmouseup
: 
ƒ onmouseup()
set onmouseup
: 
ƒ onmouseup()
get onmousewheel
: 
ƒ onmousewheel()
set onmousewheel
: 
ƒ onmousewheel()
get onoverscroll
: 
ƒ onoverscroll()
set onoverscroll
: 
ƒ onoverscroll()
get onpaste
: 
ƒ onpaste()
set onpaste
: 
ƒ onpaste()
get onpause
: 
ƒ onpause()
set onpause
: 
ƒ onpause()
get onplay
: 
ƒ onplay()
set onplay
: 
ƒ onplay()
get onplaying
: 
ƒ onplaying()
set onplaying
: 
ƒ onplaying()
get onpointercancel
: 
ƒ onpointercancel()
set onpointercancel
: 
ƒ onpointercancel()
get onpointerdown
: 
ƒ onpointerdown()
set onpointerdown
: 
ƒ onpointerdown()
get onpointerenter
: 
ƒ onpointerenter()
set onpointerenter
: 
ƒ onpointerenter()
get onpointerleave
: 
ƒ onpointerleave()
set onpointerleave
: 
ƒ onpointerleave()
get onpointerlockchange
: 
ƒ onpointerlockchange()
set onpointerlockchange
: 
ƒ onpointerlockchange()
get onpointerlockerror
: 
ƒ onpointerlockerror()
set onpointerlockerror
: 
ƒ onpointerlockerror()
get onpointermove
: 
ƒ onpointermove()
set onpointermove
: 
ƒ onpointermove()
get onpointerout
: 
ƒ onpointerout()
set onpointerout
: 
ƒ onpointerout()
get onpointerover
: 
ƒ onpointerover()
set onpointerover
: 
ƒ onpointerover()
get onpointerrawupdate
: 
ƒ onpointerrawupdate()
set onpointerrawupdate
: 
ƒ onpointerrawupdate()
get onpointerup
: 
ƒ onpointerup()
set onpointerup
: 
ƒ onpointerup()
get onprerenderingchange
: 
ƒ onprerenderingchange()
set onprerenderingchange
: 
ƒ onprerenderingchange()
get onprogress
: 
ƒ onprogress()
set onprogress
: 
ƒ onprogress()
get onratechange
: 
ƒ onratechange()
set onratechange
: 
ƒ onratechange()
get onreset
: 
ƒ onreset()
set onreset
: 
ƒ onreset()
get onresize
: 
ƒ onresize()
set onresize
: 
ƒ onresize()
get onresume
: 
ƒ onresume()
set onresume
: 
ƒ onresume()
get onscroll
: 
ƒ onscroll()
set onscroll
: 
ƒ onscroll()
get onscrollend
: 
ƒ onscrollend()
set onscrollend
: 
ƒ onscrollend()
get onscrollsnapchange
: 
ƒ onscrollsnapchange()
set onscrollsnapchange
: 
ƒ onscrollsnapchange()
get onscrollsnapchanging
: 
ƒ onscrollsnapchanging()
set onscrollsnapchanging
: 
ƒ onscrollsnapchanging()
get onsearch
: 
ƒ onsearch()
set onsearch
: 
ƒ onsearch()
get onsecuritypolicyviolation
: 
ƒ onsecuritypolicyviolation()
set onsecuritypolicyviolation
: 
ƒ onsecuritypolicyviolation()
get onseeked
: 
ƒ onseeked()
set onseeked
: 
ƒ onseeked()
get onseeking
: 
ƒ onseeking()
set onseeking
: 
ƒ onseeking()
get onselect
: 
ƒ onselect()
set onselect
: 
ƒ onselect()
get onselectionchange
: 
ƒ onselectionchange()
set onselectionchange
: 
ƒ onselectionchange()
get onselectstart
: 
ƒ onselectstart()
set onselectstart
: 
ƒ onselectstart()
get onslotchange
: 
ƒ onslotchange()
set onslotchange
: 
ƒ onslotchange()
get onstalled
: 
ƒ onstalled()
set onstalled
: 
ƒ onstalled()
get onsubmit
: 
ƒ onsubmit()
set onsubmit
: 
ƒ onsubmit()
get onsuspend
: 
ƒ onsuspend()
set onsuspend
: 
ƒ onsuspend()
get ontimeupdate
: 
ƒ ontimeupdate()
set ontimeupdate
: 
ƒ ontimeupdate()
get ontoggle
: 
ƒ ontoggle()
set ontoggle
: 
ƒ ontoggle()
get ontransitioncancel
: 
ƒ ontransitioncancel()
set ontransitioncancel
: 
ƒ ontransitioncancel()
get ontransitionend
: 
ƒ ontransitionend()
set ontransitionend
: 
ƒ ontransitionend()
get ontransitionrun
: 
ƒ ontransitionrun()
set ontransitionrun
: 
ƒ ontransitionrun()
get ontransitionstart
: 
ƒ ontransitionstart()
set ontransitionstart
: 
ƒ ontransitionstart()
get onvisibilitychange
: 
ƒ onvisibilitychange()
set onvisibilitychange
: 
ƒ onvisibilitychange()
get onvolumechange
: 
ƒ onvolumechange()
set onvolumechange
: 
ƒ onvolumechange()
get onwaiting
: 
ƒ onwaiting()
set onwaiting
: 
ƒ onwaiting()
get onwebkitanimationend
: 
ƒ onwebkitanimationend()
set onwebkitanimationend
: 
ƒ onwebkitanimationend()
get onwebkitanimationiteration
: 
ƒ onwebkitanimationiteration()
set onwebkitanimationiteration
: 
ƒ onwebkitanimationiteration()
get onwebkitanimationstart
: 
ƒ onwebkitanimationstart()
set onwebkitanimationstart
: 
ƒ onwebkitanimationstart()
get onwebkitfullscreenchange
: 
ƒ onwebkitfullscreenchange()
set onwebkitfullscreenchange
: 
ƒ onwebkitfullscreenchange()
get onwebkitfullscreenerror
: 
ƒ onwebkitfullscreenerror()
set onwebkitfullscreenerror
: 
ƒ onwebkitfullscreenerror()
get onwebkittransitionend
: 
ƒ onwebkittransitionend()
set onwebkittransitionend
: 
ƒ onwebkittransitionend()
get onwheel
: 
ƒ onwheel()
set onwheel
: 
ƒ onwheel()
get pictureInPictureElement
: 
ƒ pictureInPictureElement()
get pictureInPictureEnabled
: 
ƒ pictureInPictureEnabled()
get plugins
: 
ƒ plugins()
get pointerLockElement
: 
ƒ pointerLockElement()
get prerendering
: 
ƒ prerendering()
get readyState
: 
ƒ readyState()
get referrer
: 
ƒ referrer()
get rootElement
: 
ƒ rootElement()
get scripts
: 
ƒ scripts()
get scrollingElement
: 
ƒ scrollingElement()
get softNavigations
: 
ƒ softNavigations()
get styleSheets
: 
ƒ styleSheets()
get timeline
: 
ƒ timeline()
get title
: 
ƒ title()
set title
: 
ƒ title()
get visibilityState
: 
ƒ visibilityState()
get vlinkColor
: 
ƒ vlinkColor()
set vlinkColor
: 
ƒ vlinkColor()
get wasDiscarded
: 
ƒ wasDiscarded()
get webkitCurrentFullScreenElement
: 
ƒ webkitCurrentFullScreenElement()
get webkitFullscreenElement
: 
ƒ webkitFullscreenElement()
get webkitFullscreenEnabled
: 
ƒ webkitFullscreenEnabled()
get webkitHidden
: 
ƒ webkitHidden()
get webkitIsFullScreen
: 
ƒ webkitIsFullScreen()
get webkitVisibilityState
: 
ƒ webkitVisibilityState()
get xmlEncoding
: 
ƒ xmlEncoding()
get xmlStandalone
: 
ƒ xmlStandalone()
set xmlStandalone
: 
ƒ xmlStandalone()
get xmlVersion
: 
ƒ xmlVersion()
set xmlVersion
: 
ƒ xmlVersion()
[[Prototype]]
: 
Node
parentElement
: 
div#header
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, div.flex-container, text, div#screen-reader-status-message.screen-reader-only, text]
children
: 
HTMLCollection(2) [div.flex-container, div#screen-reader-status-message.screen-reader-only, screen-reader-status-message: div#screen-reader-status-message.screen-reader-only]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
57
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"header"
inert
: 
false
innerHTML
: 
"\n  <div class=\"flex-container\">\n    <div class=\"flex search-container\">\n      <input type=\"text\" id=\"search\" aria-label=\"Search flags\" placeholder=\"Search flags\" autocomplete=\"off\" spellcheck=\"false\">\n      <button class=\"clear-search\" title=\"Clear search\">\n        <div class=\"clear-search-icon\"></div>\n      </button>\n    </div>\n    <div class=\"flex\">\n      <cr-button id=\"experiment-reset-all\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\">\n        Reset all\n      </cr-button>\n    </div>\n  </div>\n  <div class=\"screen-reader-only\" id=\"screen-reader-status-message\" role=\"status\"></div>\n"
innerText
: 
"Reset all"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#screen-reader-status-message.screen-reader-only
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
div#body-container
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
59
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
parentNode
: 
div#header
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, div.flex-container, text, div#screen-reader-status-message.screen-reader-only, text]
children
: 
HTMLCollection(2) [div.flex-container, div#screen-reader-status-message.screen-reader-only, screen-reader-status-message: div#screen-reader-status-message.screen-reader-only]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
57
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"header"
inert
: 
false
innerHTML
: 
"\n  <div class=\"flex-container\">\n    <div class=\"flex search-container\">\n      <input type=\"text\" id=\"search\" aria-label=\"Search flags\" placeholder=\"Search flags\" autocomplete=\"off\" spellcheck=\"false\">\n      <button class=\"clear-search\" title=\"Clear search\">\n        <div class=\"clear-search-icon\"></div>\n      </button>\n    </div>\n    <div class=\"flex\">\n      <cr-button id=\"experiment-reset-all\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\">\n        Reset all\n      </cr-button>\n    </div>\n  </div>\n  <div class=\"screen-reader-only\" id=\"screen-reader-status-message\" role=\"status\"></div>\n"
innerText
: 
"Reset all"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#screen-reader-status-message.screen-reader-only
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
div#body-container
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
59
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
previousElementSibling
: 
div#screen-reader-status-message.screen-reader-only
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, 1: id, 2: role, class: class, id: id, role: role, length: 3}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList ['screen-reader-only', value: 'screen-reader-only']
className
: 
"screen-reader-only"
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
"status"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"screen-reader-status-message"
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
57
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
previousSibling
: 
div#screen-reader-status-message.screen-reader-only
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, 1: id, 2: role, class: class, id: id, role: role, length: 3}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList ['screen-reader-only', value: 'screen-reader-only']
className
: 
"screen-reader-only"
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
"status"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"screen-reader-status-message"
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
57
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
textContent
: 
"\n"
wholeText
: 
"\n"
[[Prototype]]
: 
Text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
57
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
length
: 
2
[[Prototype]]
: 
HTMLCollection
item
: 
ƒ item()
length
: 
2
namedItem
: 
ƒ namedItem()
constructor
: 
ƒ HTMLCollection()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.toStringTag)
: 
"HTMLCollection"
get length
: 
ƒ length()
[[Prototype]]
: 
Object
constructor
: 
ƒ Object()
hasOwnProperty
: 
ƒ hasOwnProperty()
isPrototypeOf
: 
ƒ isPrototypeOf()
propertyIsEnumerable
: 
ƒ propertyIsEnumerable()
toLocaleString
: 
ƒ toLocaleString()
toString
: 
ƒ toString()
valueOf
: 
ƒ valueOf()
__defineGetter__
: 
ƒ __defineGetter__()
__defineSetter__
: 
ƒ __defineSetter__()
__lookupGetter__
: 
ƒ __lookupGetter__()
__lookupSetter__
: 
ƒ __lookupSetter__()
__proto__
: 
HTMLCollection
item
: 
ƒ item()
length
: 
1
name
: 
"item"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at item.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at item.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
[Exception: TypeError: Illegal invocation at HTMLCollection.invokeGetter (<anonymous>:3:28)]
namedItem
: 
ƒ namedItem()
constructor
: 
ƒ HTMLCollection()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.toStringTag)
: 
"HTMLCollection"
get length
: 
ƒ length()
[[Prototype]]
: 
Object
get __proto__
: 
ƒ __proto__()
set __proto__
: 
ƒ __proto__()
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
57
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"header"
inert
: 
false
innerHTML
: 
"\n  <div class=\"flex-container\">\n    <div class=\"flex search-container\">\n      <input type=\"text\" id=\"search\" aria-label=\"Search flags\" placeholder=\"Search flags\" autocomplete=\"off\" spellcheck=\"false\">\n      <button class=\"clear-search\" title=\"Clear search\">\n        <div class=\"clear-search-icon\"></div>\n      </button>\n    </div>\n    <div class=\"flex\">\n      <cr-button id=\"experiment-reset-all\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\">\n        Reset all\n      </cr-button>\n    </div>\n  </div>\n  <div class=\"screen-reader-only\" id=\"screen-reader-status-message\" role=\"status\"></div>\n"
innerText
: 
"Reset all"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#screen-reader-status-message.screen-reader-only
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
div#body-container
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
59
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
nextSibling
: 
comment
nodeName
: 
"#comment"
nodeType
: 
8
nodeValue
: 
""
ownerDocument
: 
document
parentElement
: 
null
parentNode
: 
document-fragment
previousElementSibling
: 
null
previousSibling
: 
null
textContent
: 
""
[[Prototype]]
: 
Comment
firstElementChild
: 
div#header
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, div.flex-container, text, div#screen-reader-status-message.screen-reader-only, text]
children
: 
HTMLCollection(2) [div.flex-container, div#screen-reader-status-message.screen-reader-only, screen-reader-status-message: div#screen-reader-status-message.screen-reader-only]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
57
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"header"
inert
: 
false
innerHTML
: 
"\n  <div class=\"flex-container\">\n    <div class=\"flex search-container\">\n      <input type=\"text\" id=\"search\" aria-label=\"Search flags\" placeholder=\"Search flags\" autocomplete=\"off\" spellcheck=\"false\">\n      <button class=\"clear-search\" title=\"Clear search\">\n        <div class=\"clear-search-icon\"></div>\n      </button>\n    </div>\n    <div class=\"flex\">\n      <cr-button id=\"experiment-reset-all\" role=\"button\" tabindex=\"0\" aria-disabled=\"false\">\n        Reset all\n      </cr-button>\n    </div>\n  </div>\n  <div class=\"screen-reader-only\" id=\"screen-reader-status-message\" role=\"status\"></div>\n"
innerText
: 
"Reset all"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#screen-reader-status-message.screen-reader-only
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
div#body-container
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
59
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
fullscreenElement
: 
null
host
: 
flags-app
$
: 
Proxy(Object) {search: input#search}
announceStatusDelayMs
: 
100
enableUpdating
: 
ƒ ()
eventTracker_
: 
EventTracker {listeners_: Array(2)}
featuresResolver
: 
PromiseResolver {isFulfilled_: true, promise_: Promise, resolve_: ƒ, reject_: ƒ}
flagSearch
: 
FlagSearch {flagsAppElement: flags-app, searchIntervalId: null, searchDebounceDelayMs: 150}
hasUpdated
: 
true
isFlagsDeprecatedUrl_
: 
false
isUpdatePending
: 
false
lastChanged
: 
null
lastFocused
: 
null
renderOptions
: 
{host: flags-app, renderBefore: null, isConnected: true}
renderRoot
: 
document-fragment
willUpdatePending_
: 
false
_$AL
: 
Map(0) {size: 0}
_$Do
: 
R {type: 2, _$AH: M, _$AN: undefined, _$AA: comment, _$AB: null, …}
_$ES
: 
Promise {<fulfilled>: true}
_$Em
: 
null
_$Ep
: 
undefined
_$Eq
: 
undefined
#data_accessor_storage
: 
Object
#defaultFeatures_accessor_storage
: 
Array(358)
#needsRestart_accessor_storage
: 
false
#nonDefaultFeatures_accessor_storage
: 
Array(130)
#searching_accessor_storage
: 
false
#selectedTabIndex__accessor_storage
: 
0
#tabNames__accessor_storage
: 
Array(2)
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
data
: 
(...)
dataset
: 
DOMStringMap {}
defaultFeatures
: 
(...)
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"flags-app"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
needsRestart
: 
(...)
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"FLAGS-APP"
nodeType
: 
1
nodeValue
: 
null
nonDefaultFeatures
: 
(...)
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
(...)
innerHTML
: 
"<!----><!--_html_template_start_-->\n<div id=\"he
isConnected
: 
true
lastChild
: 
comment
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
"_html_template_end_"
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
19
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"#comment"
nodeType
: 
8
nodeValue
: 
"_html_template_end_"
ownerDocument
: 
document
parentElement
: 
null
parentNode
: 
document-fragment
previousElementSibling
: 
div#body-container
previousSibling
: 
text
textContent
: 
"_html_template_end_"
[[Prototype]]
: 
Comment
lastElementChild
: 
div#body-container
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
1
childNodes
: 
NodeList(3) [text, div#flagsTemplate, text]
children
: 
HTMLCollection [div#flagsTemplate, flagsTemplate: div#flagsTemplate]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2051
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2669
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div#flagsTemplate
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"body-container"
inert
: 
false
innerHTML
: 
"\n  <div id=\"flagsTemplate\">\n    <div class=\"
innerText
: 
"Experiments\n139.1.7258.139\nWARNING: EXPERIMENTAL FEATURES AHEAD! By enabling these features, you could lose browser data or compromise your security or privacy. Enabled features apply to all users of this browser. If you are an enterprise admin you should not be using these flags in production.\n\nInterested in cool new Chrome features? Try our beta channel. Interested in cool new Chrome features? Try our dev channel\n\nYour changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#flagsTemplate
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2051
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
59
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
mode
: 
"open"
nextSibling
: 
null
nodeName
: 
"#document-fragment"
nodeType
: 
11
nodeValue
: 
null
onslotchange
: 
null
ownerDocument
: 
document
location
: 
Location {ancestorOrigins: DOMStringList, href: 'chrome://flags/', origin: 'chrome://flags', protocol: 'chrome:', host: 'flags', …}
URL
: 
"chrome://flags/"
activeElement
: 
body
adoptedStyleSheets
: 
Proxy(Array) {}
alinkColor
: 
""
all
: 
HTMLAllCollection(11) [html, head, meta, meta, meta, link, title, style, body, script, flags-app, color-scheme: meta, viewport: meta]
anchors
: 
HTMLCollection []
applets
: 
HTMLCollection []
baseURI
: 
"chrome://flags/"
bgColor
: 
""
body
: 
body
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(4) [<!DOCTYPE html>, comment, comment, html]
children
: 
HTMLCollection [html]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
""
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
""
doctype
: 
<!DOCTYPE html>
documentElement
: 
html
documentURI
: 
"chrome://flags/"
domain
: 
"flags"
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection []
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html
lastElementChild
: 
html
lastModified
: 
"09/22/2025 11:36:02"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection [script]
scrollingElement
: 
html
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, length: 2}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 253468.866, duration: null}
title
: 
"Experiments"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
(...)
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pointerLockElement
: 
null
previousSibling
: 
null
referenceTarget
: 
""
serializable
: 
false
slotAssignment
: 
"named"
styleSheets
: 
StyleSheetList {length: 0}
textContent
: 
"\n\n  \n    \n      \n      \n        \n      \n 
[[Prototype]]
: 
ShadowRoot
startNode
: 
comment
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
""
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
0
nextElementSibling
: 
div#header
nextSibling
: 
comment
nodeName
: 
"#comment"
nodeType
: 
8
nodeValue
: 
""
ownerDocument
: 
document
parentElement
: 
null
parentNode
: 
document-fragment
previousElementSibling
: 
null
previousSibling
: 
null
textContent
: 
""
[[Prototype]]
: 
Comment
_$AU
: 
true
[[Prototype]]
: 
Object
_$ES
: 
Promise
[[Prototype]]
: 
Promise
[[PromiseState]]
: 
"fulfilled"
[[PromiseResult]]
: 
true
_$Em
: 
null
_$Ep
: 
undefined
_$Eq
: 
undefined
#data_accessor_storage
: 
Object
#defaultFeatures_accessor_storage
: 
Array(358)
#needsRestart_accessor_storage
: 
false
#nonDefaultFeatures_accessor_storage
: 
Array(130)
#searching_accessor_storage
: 
false
#selectedTabIndex__accessor_storage
: 
0
#tabNames__accessor_storage
: 
Array(2)
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
data
: 
(...)
dataset
: 
DOMStringMap {}
defaultFeatures
: 
(...)
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"flags-app"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
needsRestart
: 
(...)
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"FLAGS-APP"
nodeType
: 
1
nodeValue
: 
null
nonDefaultFeatures
: 
(...)
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
(...)
length
: 
2
[[Prototype]]
: 
HTMLCollection
item
: 
ƒ item()
length
: 
1
name
: 
"item"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at item.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at item.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
2
namedItem
: 
ƒ namedItem()
length
: 
1
name
: 
"namedItem"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at namedItem.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at namedItem.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
constructor
: 
ƒ HTMLCollection()
length
: 
0
name
: 
"HTMLCollection"
prototype
: 
HTMLCollection {Symbol(Symbol.toStringTag): 'HTMLCollection', item: ƒ, namedItem: ƒ, Symbol(Symbol.iterator): ƒ}
arguments
: 
null
caller
: 
null
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.iterator)
: 
ƒ values()
length
: 
0
name
: 
"values"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at values.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at values.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
Symbol(Symbol.toStringTag)
: 
"HTMLCollection"
get length
: 
ƒ length()
length
: 
0
name
: 
"get length"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at get length.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at get length.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
(...)
bind
: 
ƒ bind()
length
: 
1
name
: 
"bind"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at bind.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
call
: 
ƒ call()
length
: 
1
name
: 
"call"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at call.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at get length.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
1
name
: 
"Function"
prototype
: 
ƒ ()
apply
: 
ƒ apply()
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
bind
: 
ƒ bind()
call
: 
ƒ call()
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
constructor
: 
ƒ Function()
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
get arguments
: 
ƒ arguments()
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at Function.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
length
: 
0
name
: 
""
toString
: 
ƒ toString()
Symbol(Symbol.hasInstance)
: 
ƒ [Symbol.hasInstance]()
length
: 
1
name
: 
"[Symbol.hasInstance]"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at [Symbol.hasInstance].invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at [Symbol.hasInstance].invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
get arguments
: 
ƒ arguments()
length
: 
0
name
: 
"get arguments"
arguments
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get arguments (<anonymous>) at get arguments.invokeGetter (<anonymous>:3:28)]
caller
: 
[Exception: TypeError: 'caller', 'callee', and 'arguments' properties may not be accessed on strict mode functions or the arguments objects for calls to them at get caller (<anonymous>) at get arguments.invokeGetter (<anonymous>:3:28)]
[[Prototype]]
: 
ƒ ()
[[Scopes]]
: 
Scopes[0]
set arguments
: 
ƒ arguments()
get caller
: 
ƒ caller()
set caller
: 
ƒ caller()
[[FunctionLocation]]
: 
<unknown>
[[Prototype]]
: 
Object
[[Scopes]]
: 
Scopes[0]
[[Scopes]]
: 
Scopes[0]
[[Prototype]]
: 
Object
classList
: 
DOMTokenList(0)
length
: 
0
value
: 
""
[[Prototype]]
: 
DOMTokenList
add
: 
ƒ add()
contains
: 
ƒ contains()
entries
: 
ƒ entries()
forEach
: 
ƒ forEach()
item
: 
ƒ item()
keys
: 
ƒ keys()
length
: 
0
remove
: 
ƒ remove()
replace
: 
ƒ replace()
supports
: 
ƒ supports()
toString
: 
ƒ toString()
toggle
: 
ƒ toggle()
value
: 
""
values
: 
ƒ values()
constructor
: 
ƒ DOMTokenList()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.toStringTag)
: 
"DOMTokenList"
get length
: 
ƒ length()
get value
: 
ƒ value()
set value
: 
ƒ value()
[[Prototype]]
: 
Object
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
script
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n"
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
flags-app
link
: 
""
localName
: 
"body"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"BODY"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpageshow
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
(...)
adoptedStyleSheets
: 
Proxy(Array)
[[Handler]]
: 
Object
[[Target]]
: 
Array(0)
[[IsRevoked]]
: 
false
alinkColor
: 
""
all
: 
HTMLAllCollection(11)
0
: 
html
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, class: class, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(3) [head, text, body]
children
: 
HTMLCollection(2) [head, body]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
head
firstElementChild
: 
head
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"<head>\n<meta charset=\"utf-8\">\n<meta name=\"color-scheme\" content=\"light dark\">\n\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <link rel=\"stylesheet\" href=\"chrome://resources/css/text_defaults_md.css\">\n\n<title>Experiments</title>\n\n\n<style>\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n</style>\n</head>\n<body>\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n</body>"
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
body
lastElementChild
: 
body
localName
: 
"html"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"HTML"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
(...)
1
: 
head
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
6
childNodes
: 
NodeList(13) [text, meta, text, meta, text, meta, text, link, text, title, text, style, text]
children
: 
HTMLCollection(6) [meta, meta, meta, link, title, style, color-scheme: meta, viewport: meta]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
meta
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n<meta charset=\"utf-8\">\n<meta name=\"color-scheme\" content=\"light dark\">\n\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <link rel=\"stylesheet\" href=\"chrome://resources/css/text_defaults_md.css\">\n\n<title>Experiments</title>\n\n\n<style>\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n</style>\n"
innerText
: 
"\n\n\n\n  \n  \n\nExperiments\n\n\n\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n\n"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
style
localName
: 
"head"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
body
nextSibling
: 
text
nodeName
: 
"HEAD"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
(...)
2
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: charset, charset: charset, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
""
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
meta
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
3
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"light dark"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"color-scheme"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
meta
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
4
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"width=device-width, initial-scale=1.0"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"viewport"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
link
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
5
: 
link
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
as
: 
""
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: rel, 1: href, rel: rel, href: href, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
blocking
: 
DOMTokenList [value: '']
charset
: 
""
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
crossOrigin
: 
null
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
disabled
: 
false
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
fetchPriority
: 
"auto"
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
href
: 
"chrome://resources/css/text_defaults_md.css"
hreflang
: 
""
id
: 
""
imageSizes
: 
""
imageSrcset
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
integrity
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"link"
media
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
title
nextSibling
: 
text
nodeName
: 
"LINK"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
(...)
6
: 
title
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList [text]
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"Experiments"
innerText
: 
"Experiments"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
null
localName
: 
"title"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
style
nextSibling
: 
text
nodeName
: 
"TITLE"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
(...)
7
: 
style
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
blocking
: 
DOMTokenList [value: '']
childElementCount
: 
0
childNodes
: 
NodeList [text]
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
disabled
: 
false
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n"
innerText
: 
"\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
null
localName
: 
"style"
media
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"STYLE"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
(...)
8
: 
body
aLink
: 
""
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
background
: 
""
baseURI
: 
"chrome://flags/"
bgColor
: 
""
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, script, text, flags-app, text]
children
: 
HTMLCollection(2) [script, flags-app]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
script
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n"
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
flags-app
link
: 
""
localName
: 
"body"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"BODY"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpageshow
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
(...)
9
: 
script
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
async
: 
false
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: src, 1: type, src: src, type: type, length: 2}
attributionSrc
: 
""
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
blocking
: 
DOMTokenList [value: '']
charset
: 
""
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
crossOrigin
: 
null
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
defer
: 
false
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
event
: 
""
fetchPriority
: 
"auto"
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
htmlFor
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
integrity
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"script"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
flags-app
nextSibling
: 
text
noModule
: 
false
nodeName
: 
"SCRIPT"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
(...)
10
: 
flags-app
$
: 
Proxy(Object) {search: input#search}
announceStatusDelayMs
: 
100
enableUpdating
: 
ƒ ()
eventTracker_
: 
EventTracker {listeners_: Array(2)}
featuresResolver
: 
PromiseResolver {isFulfilled_: true, promise_: Promise, resolve_: ƒ, reject_: ƒ}
flagSearch
: 
FlagSearch {flagsAppElement: flags-app, searchIntervalId: null, searchDebounceDelayMs: 150}
hasUpdated
: 
true
isFlagsDeprecatedUrl_
: 
false
isUpdatePending
: 
false
lastChanged
: 
null
lastFocused
: 
null
renderOptions
: 
{host: flags-app, renderBefore: null, isConnected: true}
renderRoot
: 
document-fragment
willUpdatePending_
: 
false
_$AL
: 
Map(0) {size: 0}
_$Do
: 
R {type: 2, _$AH: M, _$AN: undefined, _$AA: comment, _$AB: null, …}
_$ES
: 
Promise {<fulfilled>: true}
_$Em
: 
null
_$Ep
: 
undefined
_$Eq
: 
undefined
#data_accessor_storage
: 
Object
#defaultFeatures_accessor_storage
: 
Array(358)
#needsRestart_accessor_storage
: 
false
#nonDefaultFeatures_accessor_storage
: 
Array(130)
#searching_accessor_storage
: 
false
#selectedTabIndex__accessor_storage
: 
0
#tabNames__accessor_storage
: 
Array(2)
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
data
: 
(...)
dataset
: 
DOMStringMap {}
defaultFeatures
: 
(...)
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"flags-app"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
needsRestart
: 
(...)
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"FLAGS-APP"
nodeType
: 
1
nodeValue
: 
null
nonDefaultFeatures
: 
(...)
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
(...)
color-scheme
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"light dark"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"color-scheme"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
meta
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
viewport
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"width=device-width, initial-scale=1.0"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"viewport"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
link
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
length
: 
11
[[Prototype]]
: 
HTMLAllCollection
anchors
: 
HTMLCollection(0)
length
: 
0
[[Prototype]]
: 
HTMLCollection
item
: 
ƒ item()
length
: 
0
namedItem
: 
ƒ namedItem()
constructor
: 
ƒ HTMLCollection()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.toStringTag)
: 
"HTMLCollection"
get length
: 
ƒ length()
[[Prototype]]
: 
Object
applets
: 
HTMLCollection []
baseURI
: 
"chrome://flags/"
bgColor
: 
""
body
: 
body
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(4) [<!DOCTYPE html>, comment, comment, html]
children
: 
HTMLCollection [html]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
""
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
""
doctype
: 
<!DOCTYPE html>
documentElement
: 
html
documentURI
: 
"chrome://flags/"
domain
: 
"flags"
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection []
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html
lastElementChild
: 
html
lastModified
: 
"09/22/2025 11:34:12"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection [script]
scrollingElement
: 
html
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, length: 2}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 142771.244, duration: null}
title
: 
"Experiments"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
(...)
ownerElement
: 
html
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, class: class, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(3) [head, text, body]
children
: 
HTMLCollection(2) [head, body]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
head
firstElementChild
: 
head
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"<head>\n<meta charset=\"utf-8\">\n<meta name=\"color-scheme\" content=\"light dark\">\n\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <link rel=\"stylesheet\" href=\"chrome://resources/css/text_defaults_md.css\">\n\n<title>Experiments</title>\n\n\n<style>\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n</style>\n</head>\n<body>\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n</body>"
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
body
lastElementChild
: 
body
localName
: 
"html"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"HTML"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
(...)
parentElement
: 
null
parentNode
: 
null
prefix
: 
null
previousSibling
: 
null
specified
: 
true
textContent
: 
""
value
: 
""
[[Prototype]]
: 
Attr
length
: 
1
[[Prototype]]
: 
NamedNodeMap
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(3)
0
: 
head
1
: 
text
2
: 
body
length
: 
3
[[Prototype]]
: 
NodeList
children
: 
HTMLCollection(2)
0
: 
head
1
: 
body
length
: 
2
[[Prototype]]
: 
HTMLCollection
classList
: 
DOMTokenList(0)
length
: 
0
value
: 
""
[[Prototype]]
: 
DOMTokenList
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
head
firstElementChild
: 
head
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"<head>\n<meta charset=\"utf-8\">\n<meta name=\"color-scheme\" content=\"light dark\">\n\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <link rel=\"stylesheet\" href=\"chrome://resources/css/text_defaults_md.css\">\n\n<title>Experiments</title>\n\n\n<style>\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n</style>\n</head>\n<body>\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n</body>"
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
body
lastElementChild
: 
body
localName
: 
"html"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"HTML"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
(...)
1
: 
head
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
6
childNodes
: 
NodeList(13) [text, meta, text, meta, text, meta, text, link, text, title, text, style, text]
children
: 
HTMLCollection(6) [meta, meta, meta, link, title, style, color-scheme: meta, viewport: meta]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
meta
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n<meta charset=\"utf-8\">\n<meta name=\"color-scheme\" content=\"light dark\">\n\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n  <link rel=\"stylesheet\" href=\"chrome://resources/css/text_defaults_md.css\">\n\n<title>Experiments</title>\n\n\n<style>\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n</style>\n"
innerText
: 
"\n\n\n\n  \n  \n\nExperiments\n\n\n\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n\n"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
style
localName
: 
"head"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
body
nextSibling
: 
text
nodeName
: 
"HEAD"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
(...)
2
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: charset, charset: charset, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
""
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
meta
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
3
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"light dark"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"color-scheme"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
meta
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
4
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"width=device-width, initial-scale=1.0"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"viewport"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
link
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
5
: 
link
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
as
: 
""
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: rel, 1: href, rel: rel, href: href, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
blocking
: 
DOMTokenList [value: '']
charset
: 
""
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
crossOrigin
: 
null
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
disabled
: 
false
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
fetchPriority
: 
"auto"
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
href
: 
"chrome://resources/css/text_defaults_md.css"
hreflang
: 
""
id
: 
""
imageSizes
: 
""
imageSrcset
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
integrity
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"link"
media
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
title
nextSibling
: 
text
nodeName
: 
"LINK"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
(...)
6
: 
title
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList [text]
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"Experiments"
innerText
: 
"Experiments"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
null
localName
: 
"title"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
style
nextSibling
: 
text
nodeName
: 
"TITLE"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
(...)
7
: 
style
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
blocking
: 
DOMTokenList [value: '']
childElementCount
: 
0
childNodes
: 
NodeList [text]
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
disabled
: 
false
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n"
innerText
: 
"\n  html,\n  body {\n    height: 100%;\n    overflow: hidden;\n    margin: 0;\n  }\n"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
null
localName
: 
"style"
media
: 
""
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"STYLE"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
(...)
8
: 
body
aLink
: 
""
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
background
: 
""
baseURI
: 
"chrome://flags/"
bgColor
: 
""
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, script, text, flags-app, text]
children
: 
HTMLCollection(2) [script, flags-app]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
script
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n  <script src=\"app.js\" type=\"module\"></script>\n  <flags-app></flags-app>\n\n\n"
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
flags-app
link
: 
""
localName
: 
"body"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"BODY"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onafterprint
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforeprint
: 
null
onbeforetoggle
: 
null
onbeforeunload
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
onhashchange
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onlanguagechange
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmessage
: 
null
onmessageerror
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onmove
: 
null
onoffline
: 
null
ononline
: 
null
onoverscroll
: 
null
onpagehide
: 
null
onpageshow
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
(...)
9
: 
script
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
async
: 
false
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: src, 1: type, src: src, type: type, length: 2}
attributionSrc
: 
""
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
blocking
: 
DOMTokenList [value: '']
charset
: 
""
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
crossOrigin
: 
null
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
defer
: 
false
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
event
: 
""
fetchPriority
: 
"auto"
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
htmlFor
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
integrity
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"script"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
flags-app
nextSibling
: 
text
noModule
: 
false
nodeName
: 
"SCRIPT"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
(...)
10
: 
flags-app
$
: 
Proxy(Object) {search: input#search}
announceStatusDelayMs
: 
100
enableUpdating
: 
ƒ ()
eventTracker_
: 
EventTracker {listeners_: Array(2)}
featuresResolver
: 
PromiseResolver {isFulfilled_: true, promise_: Promise, resolve_: ƒ, reject_: ƒ}
flagSearch
: 
FlagSearch {flagsAppElement: flags-app, searchIntervalId: null, searchDebounceDelayMs: 150}
hasUpdated
: 
true
isFlagsDeprecatedUrl_
: 
false
isUpdatePending
: 
false
lastChanged
: 
null
lastFocused
: 
null
renderOptions
: 
{host: flags-app, renderBefore: null, isConnected: true}
renderRoot
: 
document-fragment
willUpdatePending_
: 
false
_$AL
: 
Map(0) {size: 0}
_$Do
: 
R {type: 2, _$AH: M, _$AN: undefined, _$AA: comment, _$AB: null, …}
_$ES
: 
Promise {<fulfilled>: true}
_$Em
: 
null
_$Ep
: 
undefined
_$Eq
: 
undefined
#data_accessor_storage
: 
Object
#defaultFeatures_accessor_storage
: 
Array(358)
#needsRestart_accessor_storage
: 
false
#nonDefaultFeatures_accessor_storage
: 
Array(130)
#searching_accessor_storage
: 
false
#selectedTabIndex__accessor_storage
: 
0
#tabNames__accessor_storage
: 
Array(2)
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {length: 0}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2109
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
data
: 
(...)
dataset
: 
DOMStringMap {}
defaultFeatures
: 
(...)
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"flags-app"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
needsRestart
: 
(...)
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"FLAGS-APP"
nodeType
: 
1
nodeValue
: 
null
nonDefaultFeatures
: 
(...)
nonce
: 
""
offsetHeight
: 
2109
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
0
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
(...)
color-scheme
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"light dark"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"color-scheme"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
meta
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
viewport
: 
meta
accessKey
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: name, 1: content, name: name, content: content, length: 2}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
0
childNodes
: 
NodeList []
children
: 
HTMLCollection []
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
0
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
0
computedName
: 
""
computedRole
: 
null
containerTiming
: 
""
containerTimingIgnore
: 
false
content
: 
"width=device-width, initial-scale=1.0"
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
null
firstElementChild
: 
null
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
httpEquiv
: 
""
id
: 
""
inert
: 
false
innerHTML
: 
""
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
null
lastElementChild
: 
null
localName
: 
"meta"
media
: 
""
name
: 
"viewport"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
link
nextSibling
: 
text
nodeName
: 
"META"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
0
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
0
offsetWidth
: 
0
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
(...)
length
: 
11
[[Prototype]]
: 
HTMLAllCollection
anchors
: 
HTMLCollection(0)
length
: 
0
[[Prototype]]
: 
HTMLCollection
applets
: 
HTMLCollection(0)
length
: 
0
[[Prototype]]
: 
HTMLCollection
baseURI
: 
"chrome://flags/"
bgColor
: 
""
body
: 
body
characterSet
: 
"UTF-8"
charset
: 
"UTF-8"
childElementCount
: 
1
childNodes
: 
NodeList(4) [<!DOCTYPE html>, comment, comment, html]
children
: 
HTMLCollection [html]
compatMode
: 
"CSS1Compat"
contentType
: 
"text/html"
cookie
: 
""
currentScript
: 
null
defaultView
: 
Window {window: Window, self: Window, document: document, name: '', location: Location, …}
designMode
: 
"off"
dir
: 
""
doctype
: 
<!DOCTYPE html>
documentElement
: 
html
documentURI
: 
"chrome://flags/"
domain
: 
"flags"
embeds
: 
HTMLCollection []
featurePolicy
: 
FeaturePolicy {}
fgColor
: 
""
firstChild
: 
<!DOCTYPE html>
firstElementChild
: 
html
fonts
: 
FontFaceSet {onloading: null, onloadingdone: null, onloadingerror: null, ready: Promise, status: 'loaded', …}
forms
: 
HTMLCollection []
fragmentDirective
: 
FragmentDirective {items: Array(0)}
fullscreen
: 
false
fullscreenElement
: 
null
fullscreenEnabled
: 
true
head
: 
head
hidden
: 
false
images
: 
HTMLCollection []
implementation
: 
DOMImplementation {}
inputEncoding
: 
"UTF-8"
isConnected
: 
true
lastChild
: 
html
lastElementChild
: 
html
lastModified
: 
"09/22/2025 11:33:41"
linkColor
: 
""
links
: 
HTMLCollection []
nextSibling
: 
null
nodeName
: 
"#document"
nodeType
: 
9
nodeValue
: 
null
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfreeze
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointerlockchange
: 
null
onpointerlockerror
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprerenderingchange
: 
null
onprogress
: 
null
onratechange
: 
null
onreadystatechange
: 
null
onreset
: 
null
onresize
: 
null
onresume
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
onselectionchange
: 
null
onselectstart
: 
null
onslotchange
: 
null
onstalled
: 
null
onsubmit
: 
null
onsuspend
: 
null
ontimeupdate
: 
null
ontoggle
: 
null
ontransitioncancel
: 
null
ontransitionend
: 
null
ontransitionrun
: 
null
ontransitionstart
: 
null
onvisibilitychange
: 
null
onvolumechange
: 
null
onwaiting
: 
null
onwebkitanimationend
: 
null
onwebkitanimationiteration
: 
null
onwebkitanimationstart
: 
null
onwebkitfullscreenchange
: 
null
onwebkitfullscreenerror
: 
null
onwebkittransitionend
: 
null
onwheel
: 
null
ownerDocument
: 
null
parentElement
: 
null
parentNode
: 
null
pictureInPictureElement
: 
null
pictureInPictureEnabled
: 
true
plugins
: 
HTMLCollection []
pointerLockElement
: 
null
prerendering
: 
false
previousSibling
: 
null
readyState
: 
"complete"
referrer
: 
""
rootElement
: 
null
scripts
: 
HTMLCollection [script]
scrollingElement
: 
html
softNavigations
: 
0
styleSheets
: 
StyleSheetList {0: CSSStyleSheet, 1: CSSStyleSheet, length: 2}
textContent
: 
null
timeline
: 
DocumentTimeline {currentTime: 112347.588, duration: null}
title
: 
"Experiments"
visibilityState
: 
"visible"
vlinkColor
: 
""
wasDiscarded
: 
false
webkitCurrentFullScreenElement
: 
null
webkitFullscreenElement
: 
null
webkitFullscreenEnabled
: 
true
webkitHidden
: 
false
webkitIsFullScreen
: 
false
webkitVisibilityState
: 
"visible"
xmlEncoding
: 
null
xmlStandalone
: 
false
(...)
parentElement
: 
div#flagsTemplate
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
6
childNodes
: 
NodeList(13) [text, div.flex-container, text, div.blurb-container, text, p#promos, text, cr-tabs#tabs, text, div#tabpanels, text, div#needs-restart, text]
children
: 
HTMLCollection(6) [div.flex-container, div.blurb-container, p#promos, cr-tabs#tabs, div#tabpanels, div#needs-restart, promos: p#promos, tabs: cr-tabs#tabs, tabpanels: div#tabpanels, needs-restart: div#needs-restart]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
56933
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
740
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"flagsTemplate"
inert
: 
false
innerHTML
: 
"\n    <div class=\"flex-container\">\n      <div 
innerText
: 
"Experiments\n139.1.7258.139\nWARNING: EXPERIMENTAL FEATURES AHEAD! By enabling these features, you could lose browser data or compromise your security or privacy. Enabled features apply to all users of this browser. If you are an enterprise admin you should not be using these flags in production.\n\nInterested in cool new Chrome features? Try our beta channel. Interested in cool new Chrome features? Try our dev channel\n\nYour changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#needs-restart
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
56933
offsetLeft
: 
965
offsetParent
: 
body
offsetTop
: 
59
offsetWidth
: 
740
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
parentNode
: 
div#flagsTemplate
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
6
childNodes
: 
NodeList(13) [text, div.flex-container, text, div.blurb-container, text, p#promos, text, cr-tabs#tabs, text, div#tabpanels, text, div#needs-restart, text]
children
: 
HTMLCollection(6) [div.flex-container, div.blurb-container, p#promos, cr-tabs#tabs, div#tabpanels, div#needs-restart, promos: p#promos, tabs: cr-tabs#tabs, tabpanels: div#tabpanels, needs-restart: div#needs-restart]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
56933
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
740
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"flagsTemplate"
inert
: 
false
innerHTML
: 
"\n    <div class=\"flex-container\">\n      <div 
innerText
: 
"Experiments\n139.1.7258.139\nWARNING: EXPERIMENTAL FEATURES AHEAD! By enabling these features, you could lose browser data or compromise your security or privacy. Enabled features apply to all users of this browser. If you are an enterprise admin you should not be using these flags in production.\n\nInterested in cool new Chrome features? Try our beta channel. Interested in cool new Chrome features? Try our dev channel\n\nYour changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#needs-restart
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
56933
offsetLeft
: 
965
offsetParent
: 
body
offsetTop
: 
59
offsetWidth
: 
740
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
part
: 
DOMTokenList(0)
length
: 
0
value
: 
""
[[Prototype]]
: 
DOMTokenList
popover
: 
null
prefix
: 
null
previousElementSibling
: 
div#tabpanels
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: id, id: id, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, div#tab-content-available.tab-content, text, div#tab-content-unavailable.tab-content, text]
children
: 
HTMLCollection(2) [div#tab-content-available.tab-content, div#tab-content-unavailable.tab-content, tab-content-available: div#tab-content-available.tab-content, tab-content-unavailable: div#tab-content-unavailable.tab-content]
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
56690
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
700
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div#tab-content-available.tab-content
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"tabpanels"
inert
: 
false
innerHTML
: 
"\n      <div id=\"tab-content-available\" class=\
innerText
: 
""
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#tab-content-unavailable.tab-content
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
div#needs-restart
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
56690
offsetLeft
: 
985
offsetParent
: 
body
offsetTop
: 
294
offsetWidth
: 
700
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
previousSibling
: 
text
assignedSlot
: 
null
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
"\n    "
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
5
nextElementSibling
: 
div#needs-restart
nextSibling
: 
div#needs-restart
nodeName
: 
"#text"
nodeType
: 
3
nodeValue
: 
"\n    "
ownerDocument
: 
document
parentElement
: 
div#flagsTemplate
parentNode
: 
div#flagsTemplate
previousElementSibling
: 
div#tabpanels
previousSibling
: 
div#tabpanels
textContent
: 
"\n    "
wholeText
: 
"\n    "
[[Prototype]]
: 
Text
role
: 
"none"
scrollHeight
: 
84
scrollLeft
: 
0
scrollParent
: 
null
scrollTop
: 
0
scrollWidth
: 
2689
shadowRoot
: 
null
slot
: 
""
spellcheck
: 
true
style
: 
CSSStyleDeclaration {accentColor: '', additiveSymbols: '', alignContent: '', alignItems: '', alignSelf: '', …}
tabIndex
: 
-1
tagName
: 
"DIV"
textContent
: 
"\n      \n        Your changes will take effect the next time you relaunch Comet.\n        \n\n          \n            Relaunch\n          \n\n        \n      \n    "
title
: 
""
translate
: 
true
virtualKeyboardPolicy
: 
""
writingSuggestions
: 
"true"
[[Prototype]]
: 
HTMLDivElement
offsetTop
: 
16
offsetWidth
: 
2657
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
2
: 
text
assignedSlot
: 
null
baseURI
: 
"chrome://flags/"
childNodes
: 
NodeList []
data
: 
"\n    "
firstChild
: 
null
isConnected
: 
true
lastChild
: 
null
length
: 
5
nextElementSibling
: 
null
nextSibling
: 
null
nodeName
: 
"#text"
nodeType
: 
3
nodeValue
: 
"\n    "
ownerDocument
: 
document
parentElement
: 
div#needs-restart
parentNode
: 
div#needs-restart
previousElementSibling
: 
div.flex-container
previousSibling
: 
div.flex-container
textContent
: 
"\n    "
wholeText
: 
"\n    "
[[Prototype]]
: 
Text
length
: 
3
[[Prototype]]
: 
NodeList
entries
: 
ƒ entries()
forEach
: 
ƒ forEach()
item
: 
ƒ item()
keys
: 
ƒ keys()
length
: 
(...)
values
: 
ƒ values()
constructor
: 
ƒ NodeList()
Symbol(Symbol.iterator)
: 
ƒ values()
Symbol(Symbol.toStringTag)
: 
"NodeList"
get length
: 
ƒ length()
[[Prototype]]
: 
Object
children
: 
HTMLCollection(1)
0
: 
div.flex-container
accessKey
: 
""
align
: 
""
anchorElement
: 
null
ariaActiveDescendantElement
: 
null
ariaAtomic
: 
null
ariaAutoComplete
: 
null
ariaBrailleLabel
: 
null
ariaBrailleRoleDescription
: 
null
ariaBusy
: 
null
ariaChecked
: 
null
ariaColCount
: 
null
ariaColIndex
: 
null
ariaColIndexText
: 
null
ariaColSpan
: 
null
ariaControlsElements
: 
null
ariaCurrent
: 
null
ariaDescribedByElements
: 
null
ariaDescription
: 
null
ariaDetailsElements
: 
null
ariaDisabled
: 
null
ariaErrorMessageElements
: 
null
ariaExpanded
: 
null
ariaFlowToElements
: 
null
ariaHasPopup
: 
null
ariaHidden
: 
null
ariaInvalid
: 
null
ariaKeyShortcuts
: 
null
ariaLabel
: 
null
ariaLabelledByElements
: 
null
ariaLevel
: 
null
ariaLive
: 
null
ariaModal
: 
null
ariaMultiLine
: 
null
ariaMultiSelectable
: 
null
ariaOrientation
: 
null
ariaOwnsElements
: 
null
ariaPlaceholder
: 
null
ariaPosInSet
: 
null
ariaPressed
: 
null
ariaReadOnly
: 
null
ariaRelevant
: 
null
ariaRequired
: 
null
ariaRoleDescription
: 
null
ariaRowCount
: 
null
ariaRowIndex
: 
null
ariaRowIndexText
: 
null
ariaRowSpan
: 
null
ariaSelected
: 
null
ariaSetSize
: 
null
ariaSort
: 
null
ariaValueMax
: 
null
ariaValueMin
: 
null
ariaValueNow
: 
null
ariaValueText
: 
null
ariaVirtualContent
: 
null
assignedSlot
: 
null
attributeStyleMap
: 
StylePropertyMap {size: 0}
attributes
: 
NamedNodeMap {0: class, class: class, length: 1}
autocapitalize
: 
""
autofocus
: 
false
baseURI
: 
"chrome://flags/"
childElementCount
: 
2
childNodes
: 
NodeList(5) [text, div.flex.restart-notice, text, div.flex, text]
children
: 
HTMLCollection(2) [div.flex.restart-notice, div.flex]
classList
: 
DOMTokenList ['flex-container', value: 'flex-container']
className
: 
"flex-container"
clientHeight
: 
52
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2657
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex.restart-notice
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
""
inert
: 
false
innerHTML
: 
"\n        <div class=\"flex restart-notice\">Your changes will take effect the next time you relaunch Comet.</div>\n        <div class=\"flex\">\n\n          <cr-button id=\"experiment-restart-button\" class=\"action-button\" disabled=\"\" role=\"button\" tabindex=\"-1\" aria-disabled=\"true\">\n            Relaunch\n          </cr-button>\n\n        </div>\n      "
innerText
: 
"Your changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div.flex
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
52
offsetLeft
: 
16
offsetParent
: 
div#needs-restart
offsetTop
: 
16
offsetWidth
: 
2657
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
length
: 
1
[[Prototype]]
: 
HTMLCollection
classList
: 
DOMTokenList(0)
length
: 
0
value
: 
""
[[Prototype]]
: 
DOMTokenList
className
: 
""
clientHeight
: 
84
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2689
computedName
: 
""
computedRole
: 
"none"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div.flex-container
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"needs-restart"
inert
: 
false
innerHTML
: 
"\n      <div class=\"flex-container\">\n        <div class=\"flex restart-notice\">Your changes will take effect the next time you relaunch Comet.</div>\n        <div class=\"flex\">\n\n          <cr-button id=\"experiment-restart-button\" class=\"action-button\" disabled=\"\" role=\"button\" tabindex=\"-1\" aria-disabled=\"true\">\n            Relaunch\n          </cr-button>\n\n        </div>\n      </div>\n    "
innerText
: 
"Your changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div.flex-container
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
84
offsetLeft
: 
0
offsetParent
: 
null
offsetTop
: 
2025
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
56933
offsetLeft
: 
965
offsetParent
: 
body
offsetTop
: 
59
offsetWidth
: 
740
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
flagsTemplate
: 
div#flagsTemplate
length
: 
1
[[Prototype]]
: 
HTMLCollection
classList
: 
DOMTokenList [value: '']
className
: 
""
clientHeight
: 
2051
clientLeft
: 
0
clientTop
: 
0
clientWidth
: 
2669
computedName
: 
""
computedRole
: 
"generic"
containerTiming
: 
""
containerTimingIgnore
: 
false
contentEditable
: 
"inherit"
currentCSSZoom
: 
1
dataset
: 
DOMStringMap {}
dir
: 
""
draggable
: 
false
editContext
: 
null
elementTiming
: 
""
enterKeyHint
: 
""
firstChild
: 
text
firstElementChild
: 
div#flagsTemplate
focusgroup
: 
""
headingOffset
: 
0
headingReset
: 
false
hidden
: 
false
id
: 
"body-container"
inert
: 
false
innerHTML
: 
"\n  <div id=\"flagsTemplate\">\n    <div class=\"
innerText
: 
"Experiments\n139.1.7258.139\nWARNING: EXPERIMENTAL FEATURES AHEAD! By enabling these features, you could lose browser data or compromise your security or privacy. Enabled features apply to all users of this browser. If you are an enterprise admin you should not be using these flags in production.\n\nInterested in cool new Chrome features? Try our beta channel. Interested in cool new Chrome features? Try our dev channel\n\nYour changes will take effect the next time you relaunch Comet.\nRelaunch"
inputMode
: 
""
isConnected
: 
true
isContentEditable
: 
false
lang
: 
""
lastChild
: 
text
lastElementChild
: 
div#flagsTemplate
localName
: 
"div"
namespaceURI
: 
"http://www.w3.org/1999/xhtml"
nextElementSibling
: 
null
nextSibling
: 
text
nodeName
: 
"DIV"
nodeType
: 
1
nodeValue
: 
null
nonce
: 
""
offsetHeight
: 
2051
offsetLeft
: 
0
offsetParent
: 
body
offsetTop
: 
59
offsetWidth
: 
2689
onabort
: 
null
onanimationend
: 
null
onanimationiteration
: 
null
onanimationstart
: 
null
onauxclick
: 
null
onbeforecopy
: 
null
onbeforecut
: 
null
onbeforeinput
: 
null
onbeforematch
: 
null
onbeforepaste
: 
null
onbeforetoggle
: 
null
onbeforexrselect
: 
null
onblur
: 
null
oncancel
: 
null
oncanplay
: 
null
oncanplaythrough
: 
null
onchange
: 
null
onclick
: 
null
onclose
: 
null
oncommand
: 
null
oncontentvisibilityautostatechange
: 
null
oncontextlost
: 
null
oncontextmenu
: 
null
oncontextrestored
: 
null
oncopy
: 
null
oncuechange
: 
null
oncut
: 
null
ondblclick
: 
null
ondrag
: 
null
ondragend
: 
null
ondragenter
: 
null
ondragleave
: 
null
ondragover
: 
null
ondragstart
: 
null
ondrop
: 
null
ondurationchange
: 
null
onemptied
: 
null
onended
: 
null
onerror
: 
null
onfocus
: 
null
onformdata
: 
null
onfullscreenchange
: 
null
onfullscreenerror
: 
null
ongotpointercapture
: 
null
oninput
: 
null
oninvalid
: 
null
onkeydown
: 
null
onkeypress
: 
null
onkeyup
: 
null
onload
: 
null
onloadeddata
: 
null
onloadedmetadata
: 
null
onloadstart
: 
null
onlostpointercapture
: 
null
onmousedown
: 
null
onmouseenter
: 
null
onmouseleave
: 
null
onmousemove
: 
null
onmouseout
: 
null
onmouseover
: 
null
onmouseup
: 
null
onmousewheel
: 
null
onoverscroll
: 
null
onpaste
: 
null
onpause
: 
null
onplay
: 
null
onplaying
: 
null
onpointercancel
: 
null
onpointerdown
: 
null
onpointerenter
: 
null
onpointerleave
: 
null
onpointermove
: 
null
onpointerout
: 
null
onpointerover
: 
null
onpointerrawupdate
: 
null
onpointerup
: 
null
onprogress
: 
null
onratechange
: 
null
onreset
: 
null
onresize
: 
null
onscroll
: 
null
onscrollend
: 
null
onscrollsnapchange
: 
null
onscrollsnapchanging
: 
null
onsearch
: 
null
onsecuritypolicyviolation
: 
null
onseeked
: 
null
onseeking
: 
null
onselect
: 
null
(...)
scrollTop
: 
0
scrollWidth
: 
0
search
: 
""
shadowRoot
: 
null
shape
: 
""
slot
: 
""
spellcheck
: 
true
style
: 
CSSStyleDeclaration {accentColor: '', additiveSymbols: '', alignContent: '', alignItems: '', alignSelf: '', …}
tabIndex
: 
0
tagName
: 
"A"
target
: 
""
text
: 
"dev channel"
textContent
: 
"dev channel"
title
: 
""
translate
: 
true
type
: 
""
username
: 
""
virtualKeyboardPolicy
: 
""
writingSuggestions
: 
"true"